package com.tr.testcases.ui.ProfileAndSupport.CANADA.MLA;


import com.tr.commons.BaseClass;
import com.tr.commons.ReadProperties;
import com.tr.commons.utils.ExcelReader;
import com.tr.pages.ProfileAndSupport.ProductPage;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.awt.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public class NonproductCase_01_MLA_canada extends BaseClass {
    static String excelFilePath = ReadProperties.getConfig("DATSHEET_PATH_yunus_canada");
    static String masterDataSheetName=ReadProperties.getConfig("PS_MASTERDATA_SHEETNAME");
    static String Executionflag=ReadProperties.getConfig("PS_EXECUTIONFLAG");
    static String testDataSheetName=ReadProperties.getConfig("PS_TESTDATA_SHEETNAME");
    static String Testcasename =ReadProperties.getConfig("PS_NonproductCase_TC01");
    static String Dataset_01 =ReadProperties.getConfig("PS_NonproductCase_TC01_01");
    // static String Dataset_02 =ReadProperties.getConfig("PS_NonproductCase_TC01_02");
    // static String Dataset_03 =ReadProperties.getConfig("PS_NonproductCase_TC01_03");
    static String Operation =ReadProperties.getConfig("PS_NonproductCase_TC01_Operation");
    static String Execution_flag =ReadProperties.getConfig("PS_NonproductCase_TC01_ExecutionFlag");

    @BeforeClass
    public void initTest(ITestContext test) throws Exception{
        initDriver();



    }
    @Test(description = "Non Product Case Creation 01 MLA without attachement CANADA")
    public void Nonproduct_case1_MLA_canada() throws InterruptedException, IOException, AWTException {
        Map<Integer, Map<String, String>> excelFileMap = new HashMap<Integer, Map<String, String>>();
        excelFileMap= ExcelReader.getMasterData(excelFilePath,masterDataSheetName,Executionflag);
        log.info("Size is "+excelFileMap.size());
        log.info("Data is "+excelFileMap);
        Map<String, String> dataMap = null;
        for (Map.Entry<Integer, Map<String, String>> entry : excelFileMap.entrySet()) {
            dataMap = entry.getValue();
        }
        System.out.println(dataMap);
        TC001_Login_MLA_canada login= new TC001_Login_MLA_canada();
       login.LoginPageMLA_canada();
        Map<Integer, Map<String, String>> excelFileMaps = new HashMap<Integer, Map<String, String>>();
        excelFileMaps= ExcelReader.setMapData(excelFilePath,testDataSheetName,Testcasename,Dataset_01,Operation,Execution_flag);
        System.out.println("Sizee is "+excelFileMaps.size());
        Map<String, String> testdataMap=null;
        System.out.println("iam here"+excelFileMaps.size());
        for (Map.Entry<Integer, Map<String, String>> entry : excelFileMaps.entrySet()) {
            testdataMap = entry.getValue();
            System.out.println(testdataMap);

        }
        ProductPage psProductPage=new ProductPage();
        psProductPage.clickOnSupport()
                .clickonSubmitTicket()
                .clickOnTopic(testdataMap.get("ProductName"))
                .clickOnTopicNext()
                .clickOnCategory(testdataMap.get("ProductName"), testdataMap.get("Category"))
                .clickOnCategoryNext()
                .clickOnReason(testdataMap.get("Reason"))
                .clickOnReasonNext()
                .enterTicketSubject()
                .enterTelephone_canada()
                .enterDescription()
                .selectTheFile(testdataMap.get("Attachment needed"))
                .isemailnotificationneeded(testdataMap.get("Receive Email notification"))
                .clickonSubmitTheTicket()
                .updateTelephone()
                .clickonTicketDetails()
                .validatenewstatus()
                //.getTicketNumber()
                .isAttachmentVisible(testdataMap.get("Attachment needed"))
                .getTicketNumber()
                .clickOnSupport()
                .validateticketinopenTickets(psProductPage);

        //  .openSFDCInNewTab(dataMap.get("Integrated application url"))
        //   .loginToSFDC(dataMap.get("SFUN"),dataMap.get("SFPassword"))
        // .openSFDCWBInNewTab();


    }  @AfterClass(alwaysRun=true)
    public void tearDown() {

       closeDriver();
    }}
