package com.tr.testcases.api;

import static io.restassured.RestAssured.given;

import java.time.Instant;
import java.util.HashMap;

import com.tr.commons.ReadProperties;
import com.tr.commons.RequestLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class TC_TokenGeneration {

	private static final Logger log = LogManager.getLogger(TC001_GetGeoInv.class);
	public static String access_token;
	private static Instant expiry_time;
	public static String extension;
	public static Response response;
	

	public static String getToken() {
		// extension = RequestLoader.LoadTheRequest(REQEXT);
		try {
			if (access_token == null || Instant.now().isAfter(expiry_time)) {
				log.info("Renewing Token...");
				response = renewToken();
				access_token = response.path("access_token");
				log.info(access_token);
				int expiryDurationInSeconds = response.path("expires_in");
				expiry_time = Instant.now().plusSeconds(expiryDurationInSeconds - 300);
			} else {
				log.info("Token is still valid and good to use");
			}
		} catch (Exception e) {
			throw new RuntimeException("ABORT !!! Failed to get Token" + e.getMessage());
		}

		return access_token;

	}

	
	private static Response renewToken() throws Exception {

		RestAssured.baseURI = ReadProperties.getConfig("QA_BASE_URL");
		extension = RequestLoader.LoadTheRequest("TOKEN_EXTENSION");

		HashMap<String, String> formParameters = new HashMap<>();
		formParameters.put("grant_type", ReadProperties.getConfig("GRANT_TYPE"));
		formParameters.put("client_id", ReadProperties.getConfig("CLIENT_ID"));
		formParameters.put("client_secret", ReadProperties.getConfig("CLIENT_SECRET"));

		try {
		response = RestAssured.given()
				.contentType(ContentType.URLENC)
				.formParams(formParameters)
				.when().post(extension);
		
		}catch(Exception e) {
			e.printStackTrace();
		}

//		if (response.statusCode() != 200) {
//			throw new RuntimeException("Abort!!! Renewing token failed");
//		}
		return response;
	}

}
