package com.tr.testcases.ui.BillingAndPayment.USL;

import com.tr.commons.BaseClass;
import com.tr.commons.ReadProperties;
import com.tr.commons.utils.ExcelReader;
import com.tr.pages.BillingAndPayment.BillingPage;
import com.tr.pages.BillingAndPayment.Malinator;
import com.tr.testcases.ui.BillingAndPayment.UKI.TC001_Login_UKI;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TC036_FullPaymentBank_USL extends BaseClass {
    static String excelFilePath = ReadProperties.getConfig("DATSHEET_PATH_yunus_BP");
    static String masterDataSheetName=ReadProperties.getConfig("BP_MASTERDATA_SHEETNAME");
    static String Executionflag=ReadProperties.getConfig("BP_EXECUTIONFLAG");
    static String testDataSheetName=ReadProperties.getConfig("BP_TESTDATA_SHEETNAME");
    static String Testcasename =ReadProperties.getConfig("BP_TC002_TestcaseName");
    static String Dataset_01 =ReadProperties.getConfig("BP_TC002_Dataset_01");
    static String Operation =ReadProperties.getConfig("BP_TC002_Operation");
    static String Execution_flag =ReadProperties.getConfig("BP_TC002_ExecutionFlag");
    @BeforeClass
    public void initTest(ITestContext test) throws Exception{
        initDriver();
    }

    @Test(groups = {"tc:866515"},description = "Full payment Bank in USL")
    public void FullPaymentBank_USL() throws InterruptedException, IOException {
        Map<Integer, Map<String, String>> excelFileMap = new HashMap<Integer, Map<String, String>>();
        excelFileMap= ExcelReader.getMasterData(excelFilePath,masterDataSheetName,Executionflag);
        log.info("Size is "+excelFileMap.size());
        log.info("Data is "+excelFileMap);
        Map<String, String> dataMap = null;
        for (Map.Entry<Integer, Map<String, String>> entry : excelFileMap.entrySet()) {
            dataMap = entry.getValue();
        }
        System.out.println(dataMap);
        TC001_Login login = new TC001_Login();
        login.LoginPage_USL();
        Map<Integer, Map<String, String>> excelFileMaps = new HashMap<Integer, Map<String, String>>();
        excelFileMaps= ExcelReader.setMapData(excelFilePath,testDataSheetName,Testcasename,Dataset_01,Operation,Execution_flag);
        System.out.println("Sizee is "+excelFileMaps.size());
        Map<String, String> testdataMap=null;
        for (Map.Entry<Integer, Map<String, String>> entry : excelFileMaps.entrySet()) {
            testdataMap = entry.getValue();
        }
        System.out.println(testdataMap);

        BillingPage billingpage = new BillingPage();
        billingpage.turnOffAutoPayforInvoice().getAccountNumber().SortByStatus().getPastDueInvoice()
               // .SelectPaymentMethod("Add new payment method")
                .SelectPaymentMethod("Add new payment method")
                .RountingNumber()
                .AccountNumber()
                .InvoicePaymentBankUKI()
                .EnrollAutoPayPostInvoicePaymentBank();

        Malinator mailinator=new Malinator();
        mailinator.getEmailID().openMailinatorExisting()
                .openFirstEmailInvoicePayment().verifyEmailInvoicePayment(billingpage).navigateBack()
                .openFirstEmail().verifyEmailBank(billingpage);


    }

    @AfterClass(alwaysRun=true)
    public void tearDown() {

       closeDriver();
    }


}
