package com.tr.testcases.ui.BillingAndPayment.CANADA.CARSAutoPayInprogress;

import com.tr.commons.BaseClass;
import com.tr.commons.ReadProperties;
import com.tr.commons.utils.ExcelReader;
import com.tr.pages.BillingAndPayment.BillingPage;
import com.tr.pages.BillingAndPayment.LoginPage_BP;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TC035_Delete_AutoPayBank_Existing_Acc_AutoPayBankOn extends BaseClass {
    static String excelFilePath = ReadProperties.getConfig("DATSHEET_PATH_BP");
    static String masterDataSheetName=ReadProperties.getConfig("BP_MASTERDATA_SHEETNAME");
    static String Executionflag=ReadProperties.getConfig("BP_EXECUTIONFLAG");
    static String testDataSheetName=ReadProperties.getConfig("BP_TESTDATA_SHEETNAME");
    static String Testcasename =ReadProperties.getConfig("BP_TC013_TestcaseName_AutoPayBankOn");
    static String Dataset_01 =ReadProperties.getConfig("BP_TC013_Dataset_01");
    static String Operation =ReadProperties.getConfig("BP_TC013_Operation");
    static String Execution_flag =ReadProperties.getConfig("BP_TC013_ExecutionFlag");
    @BeforeClass
    public void initTest(ITestContext test) throws Exception{
        initDriver();
    }

    @Test(description = "Delete AutoPayBanking in CAD for Existing Account when autopay bank in progress")
    public void DeleteAutoPayBanking_CAD_AutoPayBankOn() throws InterruptedException, IOException {
        Map<Integer, Map<String, String>> excelFileMap = new HashMap<Integer, Map<String, String>>();
        excelFileMap= ExcelReader.getMasterData(excelFilePath,masterDataSheetName,Executionflag);
        log.info("Size is "+excelFileMap.size());
        log.info("Data is "+excelFileMap);
        Map<String, String> dataMap = null;
        for (Map.Entry<Integer, Map<String, String>> entry : excelFileMap.entrySet()) {
            dataMap = entry.getValue();
        }
        System.out.println(dataMap);

        Map<Integer, Map<String, String>> excelFileMaps = new HashMap<Integer, Map<String, String>>();
        excelFileMaps= ExcelReader.setMapData(excelFilePath,testDataSheetName,Testcasename,Dataset_01,Operation,Execution_flag);
        System.out.println("Sizee is "+excelFileMaps.size());
        Map<String, String> testdataMap=null;
        for (Map.Entry<Integer, Map<String, String>> entry : excelFileMaps.entrySet()) {
            testdataMap = entry.getValue();
        }
        System.out.println(testdataMap);
        LoginPage_BP loginPage = new LoginPage_BP();
        loginPage.openURL(dataMap.get("Application Url"))
                .clickOnAcceptCookies()
                //.clickOnUserNameTextBox(dataMap.get("EmailID")).clickOnGoToAccount()
                .enterEmailIDinAccount(testdataMap.get("Username"),testdataMap.get("EmailID")).enterPasswordinAccount(testdataMap.get("Password"))
                .validateLoginfunctionality();
        BillingPage billingpage = new BillingPage();
        billingpage.DeleteAutoPayExistingBank_CAD();
              /*  clickOnSetUpAutoPay()
               // .AutoPay()
                .ExistingBankAcc()
                //.RountingNumber()
               // .AccountNumber()
                //.NextButton()
              // .CheckBox()
                .clickonNextforsetupautopayBanking()
                //.verifyAutopaybankDetails()
                .verifyExistingAutopayBankDetails()
                .verifyAutopayEnabledBankExistingAcc()
                .verifyStatusOfInvoiceAsPaymentPending()
                .DeleteAutopayEnabledBankExistingAcc()
                .BackToBillingPage()
                .SetUpAutoPayVisible()
                .verifyStatusOfInvoiceNotAsPaymentPending();*/


    }

    @AfterClass(alwaysRun=true)
    public void tearDown() {

     // closeDriver();
    }


}
