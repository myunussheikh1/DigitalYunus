package com.tr.testcases.api;

import com.tr.commons.BaseClass;
import com.tr.commons.ReadJson;
import com.tr.commons.ReadProperties;
import com.tr.commons.RequestLoader;
import com.tr.commons.utils.FakerUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class TC001_GetGeoInv extends BaseClass {

	@BeforeTest
	@Parameters("TESTDATAFILE")
	public void setUp(String testDataFileName) {
		testDataFile = testDataFileName;

	}

	private static final Logger log = LogManager.getLogger(TC001_GetGeoInv.class);
	public static String requestbody, requestId, extension;
	private Response response = null;

	@Parameters({ "REQUEST_BODY", "REQUEST_EXTENSION", "TESTDATAFILE" })

	@Test(priority = 1)
	public void getRequestDetails(String REQBODY, String REQEXT, String testDataFileName) throws Exception {

		RestAssured.baseURI = ReadProperties.getConfig("QA_BASE_URL");
		testDataFile = testDataFileName;
		requestbody = RequestLoader.LoadTheRequest(REQBODY);
		extension = RequestLoader.LoadTheRequest(REQEXT);
		requestId = FakerUtils.generateName();
		requestbody = requestbody.replace("REQUESTID", requestId)
				.replace("LINENUM", ReadJson.getStringValue(testDataFile, "LINENUM"))
				.replace("SITEID", ReadJson.getStringValue(testDataFile, "SITEID"))
				.replace("PRACTICECODE", ReadJson.getStringValue(testDataFile, "PRACTICECODE"))
				.replace("ZIP_CODE", ReadJson.getStringValue(testDataFile, "ZIPCODE"));

		log.info("The API URL is \n" + ReadProperties.getConfig("QA_BASE_URL") + extension
				+ "\nand the request body is\n" + requestbody);
		logger.get().info("The API URL is <br />" + ReadProperties.getConfig("QA_BASE_URL") + extension
				+ "<br />and the request body is<br />" + requestbody);

	}

	@Test(priority = 2)
	public void hitTheRequest() throws Exception {

		try {

			response = RestAssured.given().header("Authorization", "Bearer " + TC_TokenGeneration.getToken())
					.contentType(ContentType.JSON).body(requestbody).when().post(extension);
			log.info(response.asString());

		} catch (Exception e) {
			logger.get().log(Status.FAIL, e.getMessage());
		}

		logger.get().log(response.getStatusCode() == 200 ? Status.PASS : Status.FAIL, "");
	}

	@DataProvider(name = "getDataSet")
	public static Object[] getDataSet() {

		Object[] data = ReadJson.getJsonArrayAsObjectArray(testDataFile, "dataSet");

		return data;
	}

	@Test(dataProvider = "getDataSet")
	public void printData(JSONObject js) {

		System.out.println("username " + (String) js.get("Username"));
		System.out.println("password " + (String) js.get("password"));
		
		Object[] data = ReadJson.getJsonArrayAsObjectArray(testDataFile, "dataSet");

	}

}
