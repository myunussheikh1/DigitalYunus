package com.tr.testcases.ui.BillingAndPayment.UnAuth.LRA;

import com.tr.commons.BaseClass;
import com.tr.commons.ReadProperties;
import com.tr.commons.utils.ExcelReader;
import com.tr.pages.BillingAndPayment.BillingPage;
import com.tr.pages.BillingAndPayment.Home_UnAuth;
import com.tr.pages.BillingAndPayment.Login_UnAuth;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TC002_EnrollAutoPaywithCCWithAnotherAcc_UnAuth_LRA extends BaseClass {
	static String excelFilePath = ReadProperties.getConfig("DATSHEET_PATH_BP");
	static String masterDataSheetName=ReadProperties.getConfig("BP_MASTERDATA_SHEETNAME");
	static String Executionflag=ReadProperties.getConfig("BP_EXECUTIONFLAG");
	static String testDataSheetName=ReadProperties.getConfig("BP_TESTDATA_SHEETNAME");
	static String Testcasename =ReadProperties.getConfig("BP_TC004_TestcaseName_UnAuth");
	static String Dataset_01 =ReadProperties.getConfig("BP_TC004_Dataset_UnAuth");
	static String Operation =ReadProperties.getConfig("BP_TC004_Operation_UnAuth");
	static String Execution_flag =ReadProperties.getConfig("BP_TC004_ExecutionFlag_UnAuth");
	@BeforeClass
	public void initTest(ITestContext test) throws Exception{
		initDriver();
	}
	
	@Test(groups = {"tc:866988"},description = "Enroll AutoPay with CC saved in Different account UnAuth LRA")
	public void AutopayWithCCInDiffAcc_UnAuth_LRA() throws InterruptedException, IOException {
		Map<Integer, Map<String, String>> excelFileMap = new HashMap<Integer, Map<String, String>>();
		excelFileMap= ExcelReader.getMasterData(excelFilePath,masterDataSheetName,Executionflag);
		log.info("Size is "+excelFileMap.size());
		log.info("Data is "+excelFileMap);
		Map<String, String> dataMap = null;
		for (Map.Entry<Integer, Map<String, String>> entry : excelFileMap.entrySet()) {
			 dataMap = entry.getValue();
		}
		System.out.println(dataMap);

		Map<Integer, Map<String, String>> excelFileMaps = new HashMap<Integer, Map<String, String>>();
		excelFileMaps= ExcelReader.setMapData(excelFilePath,testDataSheetName,Testcasename,Dataset_01,Operation,Execution_flag);
		System.out.println("Sizee is "+excelFileMaps.size());
		Map<String, String> testdataMap=null;
		for (Map.Entry<Integer, Map<String, String>> entry : excelFileMaps.entrySet()) {
			testdataMap = entry.getValue();
		}
		System.out.println(testdataMap);

		Login_UnAuth loginPage = new Login_UnAuth();
		loginPage.openURL(dataMap.get("UnAuth URL"))
				.clickOnAcceptCookies()
				.enterAccountNumber(dataMap.get("UnAuth AccountNumber LRA")).enterPostalCode(dataMap.get("UnAuth PostalCode LRA"))
				.clickOnLookUp();

		Home_UnAuth homePage=new Home_UnAuth();
		homePage.HomePageVerification().clickOnSetUpAutoPay();

		BillingPage billingPage=new BillingPage();
		billingPage.enterDetailsUnAuth()
				//.clickOnCreditCard()
				.enterNameOnCard()
				.enterCardNumberFromExcel(testdataMap.get("CreditCard"))
				.SelectMonthAndYear("02","2025")
				.enterSecurityCode().ClickOnConfirmUnAuth_ANZanother().validateCCAccountWarningHeading();


	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() {

		closeDriver();
	}

}
