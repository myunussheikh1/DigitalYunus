package com.tr.testcases.ui.ProfileAndSupport.CANADA;


import com.tr.commons.BaseClass;
import com.tr.commons.ReadProperties;
import com.tr.commons.utils.ExcelReader;
import com.tr.pages.ProfileAndSupport.ProductPage;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.awt.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public class DisputeCase_02_canada extends BaseClass {

    static String excelFilePath = ReadProperties.getConfig("DATSHEET_PATH_yunus_canada");
    static String masterDataSheetName=ReadProperties.getConfig("PS_MASTERDATA_SHEETNAME");
    static String Executionflag=ReadProperties.getConfig("PS_EXECUTIONFLAG");
    static String testDataSheetName=ReadProperties.getConfig("PS_TESTDATA_SHEETNAME");
    static String Testcasename =ReadProperties.getConfig("PS_DisputeCase_TC02");
    static String Dataset_01 =ReadProperties.getConfig("PS_DisputeCase_TC02_Dataset");

    static String Operation =ReadProperties.getConfig("PS_DisputeCase_TC02_Operation");
    static String Execution_flag =ReadProperties.getConfig("PS_DisputeCase_TC02_ExecutionFlag");

    @BeforeClass
    public void initTest(ITestContext test) throws Exception{
        initDriver();



    }
    @Test(description = "Dispute Case Creation 02 CANADA")
    public void Dispute_case2_canada() throws InterruptedException, IOException, AWTException {
        Map<Integer, Map<String, String>> excelFileMap = new HashMap<Integer, Map<String, String>>();
        excelFileMap= ExcelReader.getMasterData(excelFilePath,masterDataSheetName,Executionflag);
        log.info("Size is "+excelFileMap.size());
        log.info("Data is "+excelFileMap);
        Map<String, String> dataMap = null;
        for (Map.Entry<Integer, Map<String, String>> entry : excelFileMap.entrySet()) {
            dataMap = entry.getValue();
        }
        System.out.println(dataMap);
        TC001_Login_canada login= new TC001_Login_canada();
        login.LoginPage_canada();
        Map<Integer, Map<String, String>> excelFileMaps = new HashMap<Integer, Map<String, String>>();
        excelFileMaps= ExcelReader.setMapData(excelFilePath,testDataSheetName,Testcasename,Dataset_01,Operation,Execution_flag);
        System.out.println("Sizee is "+excelFileMaps.size());
        Map<String, String> testdataMap=null;
        System.out.println("iam here"+excelFileMaps.size());
        for (Map.Entry<Integer, Map<String, String>> entry : excelFileMaps.entrySet()) {
            testdataMap = entry.getValue();
            System.out.println(testdataMap);

        }
        ProductPage psProductPage=new ProductPage();
        psProductPage.clickOnBilling()
                .clickOnPaidInvoices()
                .getInvoiceNumber1()
                .clickOnFirstInvoice()
                .reportAProblem()
                .selectAndContinueCharges()
                .enterDescription()
                .enterTelephone_canada()
                .selectTheFile(testdataMap.get("Attachment needed"))
                .isemailnotificationneeded(testdataMap.get("Receive Email notification"))
                .selectTypeOfProblem(testdataMap.get("Category"),testdataMap.get("Reason"))
                .clickonSubmitTheTicket()
                .updateTelephone()
                .clickonTicketDetails()
                .getTicketNumber()
                .isAttachmentVisible(testdataMap.get("Attachment needed"))
                .clickOnSupport()
                .validateticketinopenTickets(psProductPage)
                .openTicket(psProductPage)
                .validatenewstatus().deleteTheAttachmentFromTop()
                .countTheAttachmentNumberAfterDeletingSingleAttachmentFromTop()
                .countTheAttachmentNumberBeforeUploading()
                .uploadDifferenttypesOfAttachment()
                .countTheAttachmentNumberAfterUploading()
                .deleteTheAttachmentFromTop()
                .countTheAttachmentNumberAfterDeletingFromTop()
                .deleteTheAttachmentFromDown()
                .countTheAttachmentNumberAfterDeletingFromDown();
              /*  .closeTicket()
                .MarkAsResolved()
                .enterDescription()

                .clickOnUpload()
                .clickonShowTicketDetails()
                .validatewipstatus()
                .descriptionWhileClosingTicket();*/



    }  @AfterClass(alwaysRun=true)
    public void tearDown() {

          closeDriver();
    }}
