package com.tr.testcases.ui.BillingAndPayment.UnAuth.CARS.AutoPayBankInProgress;

import com.tr.commons.BaseClass;
import com.tr.commons.ReadProperties;
import com.tr.commons.utils.ExcelReader;
import com.tr.pages.BillingAndPayment.*;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TC010_PaymentInvoiceWithBank_UnAuth_CARS_AutoPayBankOn extends BaseClass {
	static String excelFilePath = ReadProperties.getConfig("DATSHEET_PATH_BP");
	static String masterDataSheetName=ReadProperties.getConfig("BP_MASTERDATA_SHEETNAME");
	static String Executionflag=ReadProperties.getConfig("BP_EXECUTIONFLAG");
	static String testDataSheetName=ReadProperties.getConfig("BP_TESTDATA_SHEETNAME");
	static String Testcasename =ReadProperties.getConfig("BP_TC001_TestcaseName");
	static String Dataset_01 =ReadProperties.getConfig("BP_TC001_Dataset_01");
	static String Operation =ReadProperties.getConfig("BP_TC001_Operation");
	static String Execution_flag =ReadProperties.getConfig("BP_TC001_ExecutionFlag");
	@BeforeClass
	public void initTest(ITestContext test) throws Exception{
		initDriver();
	}
	
	@Test(groups = {"tc:867006"},description = "Invoice payment with Bank UnAuth CARS when autopay Bank in progress")
	public void PaymentInvoiceWithBank_UnAuth_CARS_AutoPayBankOn() throws InterruptedException, IOException {
		Map<Integer, Map<String, String>> excelFileMap = new HashMap<Integer, Map<String, String>>();
		excelFileMap= ExcelReader.getMasterData(excelFilePath,masterDataSheetName,Executionflag);
		log.info("Size is "+excelFileMap.size());
		log.info("Data is "+excelFileMap);
		Map<String, String> dataMap = null;
		for (Map.Entry<Integer, Map<String, String>> entry : excelFileMap.entrySet()) {
			 dataMap = entry.getValue();
		}
		System.out.println(dataMap);

		Map<Integer, Map<String, String>> excelFileMaps = new HashMap<Integer, Map<String, String>>();
		excelFileMaps= ExcelReader.setMapData(excelFilePath,testDataSheetName,Testcasename,Dataset_01,Operation,Execution_flag);
		System.out.println("Sizee is "+excelFileMaps.size());
		Map<String, String> testdataMap=null;
		for (Map.Entry<Integer, Map<String, String>> entry : excelFileMaps.entrySet()) {
			testdataMap = entry.getValue();
		}
		System.out.println(testdataMap);

		LoginPage_BP loginPage = new LoginPage_BP();
		loginPage.openURL(dataMap.get("Application Url"))
				.clickOnAcceptCookies()
				//.clickOnUserNameTextBox(dataMap.get("EmailID")).clickOnGoToAccount()
				.enterEmailIDinAccount(dataMap.get("UnAuth Username CARS Invoice Bank_AutoPayBankOn"),testdataMap.get("EmailID")).enterPasswordinAccount(dataMap.get("UnAuth Password CARS Invoice Bank_AutoPayBankOn"))
				.validateLoginfunctionality();

		HomePage homePage=new HomePage();
		homePage.getInvoiceAmount(dataMap.get("Invoice number Bank CARS_AutoPayBankOn")).signout().clearCookies();

		Login_UnAuth loginPage1 = new Login_UnAuth();
		loginPage1.openURL(dataMap.get("UnAuth URL"))
				.clickOnAcceptCookies()
				.enterAccountNumber(dataMap.get("UnAuth AccountNumber CARS Invoice Bank_AutoPayBankOn")).enterPostalCode(dataMap.get("UnAuth PostalCode CARS Invoice Bank_AutoPayBankOn"))
				.clickOnLookUp();

		Home_UnAuth home_unAuth=new Home_UnAuth();
		home_unAuth.clickOnMakeAPayment();

		BillingPage billingPage=new BillingPage();
		billingPage.getInvoiceVerify(homePage,dataMap.get("Invoice number Bank CARS_AutoPayBankOn"))
				.TransitNum_CAN()
				.Institution_CAN()
				.AccountNumber()
				.clickonNextforpaymentUnAuthBank();
/*
		Yopmail yopmail=new Yopmail();
		yopmail.openURL(dataMap.get("EmailURL")).enterEmailID(billingPage).verifyDetailsInvoiceBank(homePage,billingPage,dataMap.get("Invoice number Bank CARS"));
*/
		HomePage homePage1=new HomePage();
		homePage1.clearCookies();

		LoginPage_BP loginPage2 = new LoginPage_BP();
		loginPage2.openURL(dataMap.get("Application Url"))
				.clickOnAcceptCookies()
				//.clickOnUserNameTextBox(dataMap.get("EmailID")).clickOnGoToAccount()
				.enterEmailIDinAccount(dataMap.get("UnAuth Username CARS Invoice Bank_AutoPayBankOn"),testdataMap.get("EmailID")).enterPasswordinAccount(dataMap.get("UnAuth Password CARS Invoice Bank_AutoPayBankOn"))
				.validateLoginfunctionality();

		BillingPage billingPage2=new BillingPage();
		billingPage2.verifyInvoiceStatusUnAuth(dataMap.get("Invoice number Bank CARS_AutoPayBankOn"));



	}
	
	@AfterClass(alwaysRun=true)
	public void tearDown() {

		closeDriver();
	}

}
