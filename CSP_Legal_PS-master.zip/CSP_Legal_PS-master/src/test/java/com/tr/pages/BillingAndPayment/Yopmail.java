package com.tr.pages.BillingAndPayment;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Yopmail extends BasePage_PS
    {
    public Yopmail() {
        super("locatorsDefinition/BillingAndPayment/Yopmail.json");
        PageFactory.initElements(getDriver(), this);
    }
    public Yopmail openURL(String url) throws InterruptedException, IOException {

        driver.get(url);
        ExtentLogger.pass("opening the URL "+url, true);


        return this;
    }

        public Yopmail enterEmailID(BillingPage billingPage) throws InterruptedException, IOException {
            //Thread.sleep(3000);

           waitTillElemenetVisible("EmailIDTextbox");
            clickElement(getElementByXpath("EmailIDTextbox"));
            sendKeysTotheElement("EmailIDTextbox", billingPage.emailIdUnAuth);
            ExtentLogger.pass("Entering the Email id "+billingPage.emailIdUnAuth, true);
            clickElement(getElementByXpath("clickOnGo"));
            Thread.sleep(3000);
            return  this;
    }

        public Yopmail enterEmailIDAutopay(BillingPage billingPage) throws InterruptedException, IOException {
            //Thread.sleep(3000);

            waitTillElemenetVisible("EmailIDTextbox");
            clickElement(getElementByXpath("EmailIDTextbox"));
            sendKeysTotheElement("EmailIDTextbox", billingPage.emailUnAuth);
            ExtentLogger.pass("Entering the Email id "+billingPage.emailIdUnAuth, true);
            clickElement(getElementByXpath("clickOnGo"));
            Thread.sleep(3000);
            return  this;
        }

    public Yopmail verifyDetails(HomePage homePage,BillingPage billingPage) throws InterruptedException, IOException {
        driver.switchTo().frame("ifinbox");
        Thread.sleep(2000);
        waitTillElemenetVisible("clickOnTREmail");
        clickElement(getElementByXpath("clickOnTREmail"));
        driver.switchTo().defaultContent();

        driver.switchTo().frame("ifmail");
        Thread.sleep(2000);
        String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
        ExtentLogger.pass("Payment date is "+value);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDateTime now = LocalDateTime.now();
        String date=dtf.format(now);
        System.out.println(date);
        Assert.assertEquals(value,date);

        value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
        ExtentLogger.pass("Payment amount is "+value,true);
        Assert.assertEquals(value,homePage.pastDueAmount);

        value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
        ExtentLogger.pass("Payment from is "+value,true);
        Assert.assertTrue(value.contains("Bank account") && value.contains(billingPage.lastFourDigitBanking));

        value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
        ExtentLogger.pass("Confirmation number is "+value,true);
        Assert.assertTrue(billingPage.confirmationNumber.contains(value));

        driver.switchTo().defaultContent();



        return  this;
    }
        public Yopmail verifyDetails_USL(Home_UnAuth home_unAuth,BillingPage billingPage) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is "+value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date=dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value,date);

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);
            Assert.assertEquals(value,home_unAuth.pastDueAmountverify);

            value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is "+value,true);
            Assert.assertTrue(value.contains("Bank account") && value.contains(billingPage.lastFourDigitBanking));

            value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is "+value,true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();



            return  this;
        }

        public Yopmail verifyDetailsBank_TA61(BillingPage billingPage) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is "+value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date=dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value,date);

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);
            Assert.assertEquals(value,billingPage.pastDueAmount_TA61);

            value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is "+value,true);
            Assert.assertTrue(value.contains("Bank account") && value.contains(billingPage.lastFourDigitBanking));

            value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is "+value,true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();



            return  this;
        }

        public Yopmail verifyDetailsCC(HomePage homePage,BillingPage billingPage) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value = driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is " + value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date = dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value, date);

            value = driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is " + value, true);
            Assert.assertEquals(value, homePage.pastDueAmount);

            value = driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is " + value, true);
            Assert.assertTrue(value.contains("VISA ending in") && value.contains(billingPage.lastFourDigit));

            value = driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is " + value, true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();


            return this;
        }

        public Yopmail verifyDetailsCCLRA(BillingPage billingPage) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value = driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is " + value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date = dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value, date);

            value = driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is " + value, true);


            value = driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is " + value, true);
            Assert.assertTrue(value.contains("VISA ending in") && value.contains(billingPage.lastFourDigit));

            value = driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is " + value, true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();


            return this;
        }


        public Yopmail verifyDetailsCCTotal(HomePage homePage,BillingPage billingPage) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is "+value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date=dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value,date);

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);
            Assert.assertEquals(value,homePage.totalDueAmount);

            value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is "+value,true);
            Assert.assertTrue(value.contains("VISA ending in") && value.contains(billingPage.lastFourDigit));

            value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is "+value,true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();



            return  this;
        }

        public Yopmail verifyDetailsBankTotal(HomePage homePage,BillingPage billingPage) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            WebDriverWait wait=new WebDriverWait(driver,240);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'donotreply')]/parent::div")));
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is "+value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date=dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value,date);

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);
            Assert.assertEquals(value,homePage.totalDueAmount);

            value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is "+value,true);
            Assert.assertTrue(value.contains("Bank account") && value.contains(billingPage.lastFourDigitBanking));

            value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is "+value,true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();



            return  this;
        }
        public Yopmail verifyDetailsBankTotal_TA61(BillingPage billingPage) throws InterruptedException, IOException {
            waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            WebDriverWait wait=new WebDriverWait(driver,240);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'donotreply')]/parent::div")));
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is "+value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date=dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value,date);

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);
            Assert.assertEquals(value,billingPage.totalDueAmount_TA61);

            value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is "+value,true);
            Assert.assertTrue(value.contains("Bank account") && value.contains(billingPage.lastFourDigitBanking));

            value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is "+value,true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();



            return  this;
        }

        public Yopmail verifyDetailsInvoiceBank(HomePage homePage,BillingPage billingPage,String invoiceNumber) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is "+value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date=dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value,date);

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);
            Assert.assertEquals(value,homePage.invoiceAmount);

            value=driver.findElement(By.xpath("//*[contains(text(),'Invoice number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Invoice number is "+value,true);
            Assert.assertEquals(value,invoiceNumber);

            value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is "+value,true);
            Assert.assertTrue(value.contains("Bank account") && value.contains(billingPage.lastFourDigitBanking));

            value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is "+value,true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();



            return  this;
        }
        public Yopmail verifyDetailsInvoiceBank_TA61(BillingPage billingPage,String invoiceNumber) throws InterruptedException, IOException {
            waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
        driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
          //  driver.navigate().refresh();
           // Thread.sleep(2000);
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);

            String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is "+value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date=dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value,date);

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);
            Assert.assertEquals(value,billingPage.invoiceAmount_TA61);

            value=driver.findElement(By.xpath("//*[contains(text(),'Invoice number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Invoice number is "+value,true);
            Assert.assertEquals(value,invoiceNumber);

            value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is "+value,true);
            Assert.assertTrue(value.contains("Bank account") && value.contains(billingPage.lastFourDigitBanking));

            value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is "+value,true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();



            return  this;
        }


        public Yopmail verifyDetailsInvoiceCC(HomePage homePage,BillingPage billingPage,String invoiceNumber) throws InterruptedException, IOException {

         waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is "+value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date=dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value,date);

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);
            Assert.assertEquals(value,homePage.invoiceAmount);

            value=driver.findElement(By.xpath("//*[contains(text(),'Invoice number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Invoice number is "+value,true);
            Assert.assertEquals(value,invoiceNumber);

            value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is "+value,true);
            Assert.assertTrue(value.contains("VISA ending in") && value.contains(billingPage.lastFourDigit));

            value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is "+value,true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();



            return  this;
        }

        public Yopmail verifyDetailsInvoiceCCLRA(BillingPage billingPage,String invoiceNumber,String amount) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmail");
            clickElement(getElementByXpath("clickOnTREmail"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'Payment date')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment date is "+value);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDateTime now = LocalDateTime.now();
            String date=dtf.format(now);
            System.out.println(date);
            Assert.assertEquals(value,date);

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);
            Assert.assertTrue(value.contains(amount));

            value=driver.findElement(By.xpath("//*[contains(text(),'Payment amount')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment amount is "+value,true);


            value=driver.findElement(By.xpath("//*[contains(text(),'Invoice number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Invoice number is "+value,true);
            Assert.assertEquals(value,invoiceNumber);

            value=driver.findElement(By.xpath("//*[contains(text(),'Paid from')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Payment from is "+value,true);
            Assert.assertTrue(value.contains("VISA ending in") && value.contains(billingPage.lastFourDigit));

            value=driver.findElement(By.xpath("//*[contains(text(),'Confirmation number')]/parent::span/parent::td/parent::tr//td[2]/span")).getText().trim();
            ExtentLogger.pass("Confirmation number is "+value,true);
            Assert.assertTrue(billingPage.confirmationNumber.contains(value));

            driver.switchTo().defaultContent();



            return  this;
        }


        public Yopmail verifyDetailsAutoPayBank(BillingPage billingPage) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmailAutoPay");
            clickElement(getElementByXpath("clickOnTREmailAutoPay"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("window.scrollBy(0,900)");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'Bank account')]")).getText().trim();
            ExtentLogger.pass("Sentence is "+value);

            Assert.assertTrue(value.contains("Bank account") && value.contains(billingPage.lastFourDigitBanking));
            ExtentLogger.pass("Bank account number is present");


            String accountnumberText = getElementTextbyElement(getElementByXpath("AccountnumberText"));
            System.out.println("Account number in mail is "+accountnumberText);
            ExtentLogger.pass("Account number in mail is "+accountnumberText,true);

            Assert.assertEquals(billingPage.accountNumberUI, accountnumberText.trim());

            String accountnameText = getElementTextbyElement(getElementByXpath("AccountnameText"));
            System.out.println("Account name in mail is "+accountnameText);
            ExtentLogger.pass("Account name in mail is "+accountnameText,true);

            Assert.assertFalse(accountnameText.trim().isEmpty());

            String accountaddressText = getElementTextbyElement(getElementByXpath("AccountaddressText"));
            System.out.println("Account address in mail is "+accountaddressText);
            ExtentLogger.pass("Account address in mail is "+accountaddressText,true);

            Assert.assertFalse(accountaddressText.trim().isEmpty());

            driver.switchTo().defaultContent();



            return  this;
        }

        public Yopmail verifyDetailsAutoPayCC(BillingPage billingPage) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");

            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmailAutoPay");
            clickElement(getElementByXpath("clickOnTREmailAutoPay"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("window.scrollBy(0,900)");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'use your')]")).getText().trim();
            ExtentLogger.pass("Sentence is is "+value);

            Assert.assertTrue(value.contains("VISA ending in") && value.contains(billingPage.lastFourDigit));
            ExtentLogger.pass("CC number is present");




            String accountnumberText = getElementTextbyElement(getElementByXpath("AccountnumberText"));
            System.out.println("Account number in mail is "+accountnumberText);
            ExtentLogger.pass("Account number in mail is "+accountnumberText,true);

            Assert.assertEquals(billingPage.accountNumberUI, accountnumberText.trim());

            String accountnameText = getElementTextbyElement(getElementByXpath("AccountnameText"));
            System.out.println("Account name in mail is "+accountnameText);
            ExtentLogger.pass("Account name in mail is "+accountnameText,true);

            Assert.assertFalse(accountnameText.trim().isEmpty());

            String accountaddressText = getElementTextbyElement(getElementByXpath("AccountaddressText"));
            System.out.println("Account address in mail is "+accountaddressText);
            ExtentLogger.pass("Account address in mail is "+accountaddressText,true);

            Assert.assertFalse(accountaddressText.trim().isEmpty());


            driver.switchTo().defaultContent();



            return  this;
        }
        public Yopmail verifyDetailsAutoPayBANK(BillingPage billingPage) throws InterruptedException, IOException {
             waitTillElemenetVisible("mailRefresh");
            clickElement(getElementByXpath("mailRefresh"));
            Thread.sleep(15000);
            clickElement(getElementByXpath("mailRefresh"));
            driver.switchTo().frame("ifinbox");
            Thread.sleep(5000);
            waitTillElemenetVisible("clickOnTREmailAutoPay");
            clickElement(getElementByXpath("clickOnTREmailAutoPay"));
            driver.switchTo().defaultContent();

            driver.switchTo().frame("ifmail");
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("window.scrollBy(0,900)");
            Thread.sleep(2000);
            String value=driver.findElement(By.xpath("//*[contains(text(),'use your')]")).getText().trim();
            ExtentLogger.pass("Sentence is is "+value);

            Assert.assertTrue(value.contains("Bank account") && value.contains(billingPage.lastFourDigit));
            ExtentLogger.pass("CC number is present",true);


            String accountnumberText = getElementTextbyElement(getElementByXpath("AccountnumberText"));
            System.out.println("Account number in mail is "+accountnumberText);
            ExtentLogger.pass("Account number in mail is "+accountnumberText,true);

            Assert.assertEquals(billingPage.accountNumberUI, accountnumberText.trim());

            String accountnameText = getElementTextbyElement(getElementByXpath("AccountnameText"));
            System.out.println("Account name in mail is "+accountnameText);
            ExtentLogger.pass("Account name in mail is "+accountnameText,true);

            Assert.assertFalse(accountnameText.trim().isEmpty());

            String accountaddressText = getElementTextbyElement(getElementByXpath("AccountaddressText"));
            System.out.println("Account address in mail is "+accountaddressText);
            ExtentLogger.pass("Account address in mail is "+accountaddressText,true);

            Assert.assertFalse(accountaddressText.trim().isEmpty());
            driver.switchTo().defaultContent();



            return  this;
        }
    }
