package com.tr.pages.ProfileAndSupport;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.testng.Assert;

public class RegistrationPage extends BasePage_PS {

	public RegistrationPage() {
		super("locatorsDefinition/ProfileAndSupport/RegistrationPage.json");
        PageFactory.initElements(getDriver(), this);
    }

	public RegistrationPage clickOnUserAccess() throws InterruptedException, IOException {
        Thread.sleep(5000);
        waitTillElemenetVisible("userAccessLink");
        clickElement(getElementByXpath("userAccessLink"));
        ExtentLogger.pass("Clicked on the User Access tab", true);
        return this;
    }
	
	public RegistrationPage clickOnAdminsTab() throws InterruptedException, IOException {
		Thread.sleep(5000);
		clickElement(getElementByXpath("adminTab"));
        ExtentLogger.pass("Clicked on the Admins tab", true);
        return this;
    }
	
	public RegistrationPage clickOnInviteUsers() throws InterruptedException, IOException {
        clickElement(getElementByXpath("inviteUsers"));
        ExtentLogger.pass("Clicked on the Invite Users link", true);
        return this;
    }
	
	public RegistrationPage clickOnInviteAdmins() throws InterruptedException, IOException {
        Thread.sleep(2000);
        waitTillElemenetVisible("inviteAdmins");
        Thread.sleep(1000);
        clickElement(getElementByXpath("inviteAdmins"));
        ExtentLogger.pass("Clicked on the Invite Admins link", true);
        return this;
    }
    public RegistrationPage enterfirstName(OnePassPage onepass) throws InterruptedException, IOException {

        waitTillElemenetVisible("firstName");
        clickElement(getElementByXpath("firstName"));
        sendKeysTotheElement("firstName", onepass.firstNameOnepass);
        ExtentLogger.pass("First Name is entered successfully...", true);

        return this;

    }
    public RegistrationPage enterlastName(OnePassPage onepass) throws InterruptedException, IOException {

        waitTillElemenetVisible("lastName");
        clickElement(getElementByXpath("lastName"));
        sendKeysTotheElement("lastName", onepass.lastNameOnepass);
        ExtentLogger.pass("Last Name is entered successfully...", true);

        return this;

    }
    public RegistrationPage enterRegemailID(OnePassPage onepass) throws InterruptedException, IOException {
    	String emailOnepass = onepass.firstNameOnepass.toLowerCase()+onepass.lastNameOnepass.toLowerCase()+"@mailinator.com";
        waitTillElemenetVisible("emailId");
        clickElement(getElementByXpath("emailId"));
        sendKeysTotheElement("emailId", emailOnepass);
        ExtentLogger.pass("Email Id is entered successfully...", true);

        return this;

    }
    
    public RegistrationPage enteremailID(OnePassPage onepass) throws InterruptedException, IOException {
        waitTillElemenetVisible("emailId");
        clickElement(getElementByXpath("emailId"));
        sendKeysTotheElement("emailId", onepass.emailOnepass);
        ExtentLogger.pass("Email Id is entered successfully...", true);

        return this;

    }
    public RegistrationPage selectBillingAndUserPermission() throws InterruptedException, IOException {

        waitTillElemenetVisible("choosePermission");
        clickElement(getElementByXpath("choosePermission"));
        waitTillElemenetVisible("BillingPermission");
        clickElement(getElementByXpath("BillingPermission"));
        clickElement(getElementByXpath("UserPermission"));
        ExtentLogger.pass("Billing and User access are selected successfully...", true);

        return this;

    }
    public RegistrationPage selectBillingPermission() throws InterruptedException, IOException {

        waitTillElemenetVisible("choosePermission");
        clickElement(getElementByXpath("choosePermission"));
        waitTillElemenetVisible("BillingPermission");
        clickElement(getElementByXpath("BillingPermission"));

        ExtentLogger.pass("Billing  is selected successfully...", true);

        return this;

    }

    public RegistrationPage selectUserPermission() throws InterruptedException, IOException {

        waitTillElemenetVisible("choosePermission");
        clickElement(getElementByXpath("choosePermission"));
        waitTillElemenetVisible("BillingPermission");

        clickElement(getElementByXpath("UserPermission"));
        ExtentLogger.pass("User access is selected successfully...", true);

        return this;

    }
    public RegistrationPage verifyContiueIsDisabled() throws InterruptedException, IOException {

        String value=driver.findElement(By.xpath("//span[text()='Continue']/parent::a")).getAttribute("aria-disabled");
        Assert.assertTrue(value.contains("true"));
        ExtentLogger.pass("Continue button is disabled", true);

        return this;

    }
    public RegistrationPage clickOnConitue() throws InterruptedException, IOException {

        waitTillElemenetVisible("continueButton");
        clickElement(getElementByXpath("continueButton"));

        ExtentLogger.pass("Clicked on conitue button  successfully...", true);

        return this;

    }
    public RegistrationPage verifyNameRegistration(OnePassPage onepass) throws InterruptedException, IOException {

        waitTillElemenetVisible("inviteAdmins");
        String name = getElementText(getElementByXpath("RegisteredName"));
        Boolean b = name.contains(onepass.firstNameOnepass) && name.contains(onepass.lastNameOnepass);
        Assert.assertTrue(b);
        ExtentLogger.pass("Name is successfully validated", true);

        return this;

    }
    public RegistrationPage verifyPermissionRegistrationBillingAndUser() throws InterruptedException, IOException {

        waitTillElemenetVisible("inviteAdmins");
        String name = getElementText(getElementByXpath("RegisteredPermission"));
        Boolean b = name.contains("Billing, User Access");
        Assert.assertTrue(b);
        ExtentLogger.pass("Permission is successfully validated", true);

        return this;

    }
    public RegistrationPage verifyPermissionRegistrationBilling() throws InterruptedException, IOException {

        waitTillElemenetVisible("inviteAdmins");
        String name = getElementText(getElementByXpath("RegisteredPermission"));
        Boolean b = name.contains("Billing");
        Assert.assertTrue(b);
        ExtentLogger.pass("Permission is successfully validated", true);

        return this;

    }
    public RegistrationPage verifyPermissionRegistrationUser() throws InterruptedException, IOException {

        waitTillElemenetVisible("inviteAdmins");
        String name = getElementText(getElementByXpath("RegisteredPermission"));
        Boolean b = name.contains("User Access");
        Assert.assertTrue(b);
        ExtentLogger.pass("Permission is successfully validated", true);

        return this;

    }
    public RegistrationPage verifyEmailRegistration(OnePassPage onepass) throws InterruptedException, IOException {

        waitTillElemenetVisible("inviteAdmins");
        String name = getElementText(getElementByXpath("RegisteredEmail"));
        Boolean b = name.contains(onepass.emailOnepass);
        Assert.assertTrue(b);
        ExtentLogger.pass("Email ID is successfully validated", true);

        return this;

    }

    public RegistrationPage BackToUserAccess() throws InterruptedException, IOException {
        Thread.sleep(2000);
        waitTillElemenetVisible("BackToUserAccess");
        clickElement(getElementByXpath("BackToUserAccess"));
        ExtentLogger.pass("Clicked on the back To user access link", true);
        return this;
    }
    public RegistrationPage Signout() throws InterruptedException, IOException {


        Thread.sleep(5000);
        waitTillElemenetVisible("Profile");
        clickElement(getElementByXpath("Profile"));
        ExtentLogger.pass("Clicking on Profile", true);
        Thread.sleep(5000);
        waitTillElemenetVisible("Signout");
        clickElement(getElementByXpath("Signout"));
        ExtentLogger.pass("Clicking on Signout", true);
       // Boolean a=driver.findElement(By.xpath("//strong[text()='You’re signed out']")).isDisplayed();
       // Assert.assertTrue(a);
        ExtentLogger.pass("User has successfully signed out!!", true);
       // clickElement(getElementByXpath("Signinagain"));

        return this;

    }
    public RegistrationPage AdminAddedPopup() throws InterruptedException, IOException {
        Thread.sleep(2000);
        waitTillElemenetVisible("AdminAddedpopup");
        boolean AdminAddedpopup=IsElementdisplayed(getElementByXpath("AdminAddedpopup"));
        Assert.assertTrue(AdminAddedpopup);
        ExtentLogger.pass("Admin added pop up is displayed", true);
        clickElement(getElementByXpath("DismissPopup"));
        ExtentLogger.pass("Dismissed the pop up",true);
        return this;
    }

    public RegistrationPage deleteCookies() throws InterruptedException, IOException {
        driver.manage().deleteAllCookies();
        Thread.sleep(3000);
        return this;
    }
    public RegistrationPage openNewTab(int n) throws InterruptedException, IOException {

        ((JavascriptExecutor) driver).executeScript("window.open()");
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(n));
        return this;
    }
    public RegistrationPage openIncognitomode() throws InterruptedException, IOException {

        ChromeOptions options = new ChromeOptions();
        options.addArguments("incognito");
        DesiredCapabilities cap = DesiredCapabilities.chrome();
        cap.setCapability(ChromeOptions.CAPABILITY, options);
        driver = new ChromeDriver(cap);

        return this;
    }
    
}
