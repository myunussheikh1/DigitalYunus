package com.tr.pages.ProfileAndSupport;

import com.github.javafaker.Faker;
import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.ArrayList;

public class Mailinator extends BasePage_PS {
    Faker fake = new Faker();
	public Mailinator() {
		super("locatorsDefinition/ProfileAndSupport/Mailinator.json");
        PageFactory.initElements(getDriver(), this);
    }

    public Mailinator openURL(String url) throws InterruptedException {

        driver.get(url);

        return this;
    }

	public Mailinator IsWelComeMailDisplayed() throws InterruptedException, IOException {

        waitTillElemenetVisible("WelcomeMail");
        Thread.sleep(12000);
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("WelcomeMail")));
        ExtentLogger.pass("Welcome to One Pass email is present", true);
        return this;
    }
	
    public Mailinator clickonCompleteRegistration(OnePassPage onePassPage) throws InterruptedException, IOException {
        Thread.sleep(17000);
        waitTillElemenetVisible("CompleteRegistration");
        clickElement(getElementByXpath("CompleteRegistration"));
       // WebElement element = driver.findElement(By.id("elementId"));
        Thread.sleep(2000);
        ExtentLogger.pass("Clicked on Welcome to Complete Registrations email", true);
        String toaddress = getElementText(getElementByXpath("ToAddess"));
        toaddress=toaddress.trim();
        System.out.println(toaddress);
        onePassPage.firstNameOnepass=onePassPage.firstNameOnepass.toLowerCase();
        onePassPage.lastNameOnepass=onePassPage.lastNameOnepass.toLowerCase();
        System.out.println(onePassPage.firstNameOnepass);
        System.out.println(onePassPage.lastNameOnepass);
        System.out.println("To address "+toaddress);
        boolean result=toaddress.contains(onePassPage.firstNameOnepass) && toaddress.contains(onePassPage.lastNameOnepass);
        Assert.assertTrue(result);
        ExtentLogger.pass("To address is correct", true);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,950)");
        Thread.sleep(2000);
        //clickElement(getElementByXpath("ChangeText"));
        WebElement ele=driver.findElement(By.xpath("//iframe[@id='html_msg_body']"));
        driver.switchTo().frame(ele);
        Thread.sleep(1000);
        waitTillElemenetVisible("CompleteRegistrationLink");
        clickElement(getElementByXpath("CompleteRegistrationLink"));
        ExtentLogger.pass("Clicking on registration link", true);
        return this;
    }
    public Mailinator clickonCompleteRegistrationUKI(OnePassPage onePassPage) throws InterruptedException, IOException {
        Thread.sleep(17000);
        waitTillElemenetVisible("CompleteRegistration");
        clickElement(getElementByXpath("CompleteRegistration"));
        ExtentLogger.pass("Clicked on Welcome to Complete Registrations email", true);
        String toaddress = getElementText(getElementByXpath("ToAddess"));
        toaddress=toaddress.trim();
        System.out.println(toaddress);
        onePassPage.firstNameOnepass=onePassPage.firstNameOnepass.toLowerCase();
        onePassPage.lastNameOnepass=onePassPage.lastNameOnepass.toLowerCase();
        System.out.println(onePassPage.firstNameOnepass);
        System.out.println(onePassPage.lastNameOnepass);
        boolean result=toaddress.contains(onePassPage.firstNameOnepass) && toaddress.contains(onePassPage.lastNameOnepass);
        Assert.assertTrue(result);
        ExtentLogger.pass("To address is correct", true);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,950)");
        Thread.sleep(2000);
        //clickElement(getElementByXpath("ChangeText"));
        WebElement ele=driver.findElement(By.xpath("//iframe[@id='html_msg_body']"));
        driver.switchTo().frame(ele);
        Thread.sleep(1000);
        waitTillElemenetVisible("CompleteRegistrationLinkUKI");
        clickElement(getElementByXpath("CompleteRegistrationLinkUKI"));
        ExtentLogger.pass("Clicking on registration link", true);
        return this;
    }

    public Mailinator switchToWindow(int n) throws InterruptedException, IOException {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(n));
        return this;
    }
    public Mailinator clickOnGo() throws InterruptedException, IOException {

        waitTillElemenetVisible("GoButton");
        clickElement(getElementByXpath("GoButton"));
        ExtentLogger.pass("Clicked on the Go button", true);
        return this;
    }

    public Mailinator enterRegEmailID(OnePassPage onePassPage) throws InterruptedException, IOException {
    	String emailOnepass = onePassPage.firstNameOnepass+onePassPage.lastNameOnepass+"@mailinator.com";
        waitTillElemenetVisible("EmailIDTextBox");
        clickElement(getElementByXpath("EmailIDTextBox"));
        sendKeysTotheElement("EmailIDTextBox", emailOnepass);
        ExtentLogger.pass("Email ID is entered successfully...", true);

        return this;

    }
    
public Mailinator enterEmailID(OnePassPage onePassPage) throws InterruptedException, IOException {
        waitTillElemenetVisible("EmailIDTextBox");
        clickElement(getElementByXpath("EmailIDTextBox"));
        sendKeysTotheElement("EmailIDTextBox", onePassPage.emailOnepass);
        ExtentLogger.pass("Email ID is entered successfully...", true);

        return this;

    }
    
    
    public Mailinator IsTRMailDisplayed() throws InterruptedException, IOException {
        Thread.sleep(16000);
        waitTillElemenetVisible("TRMail");
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("TRMail")));
        ExtentLogger.pass("TR email is present", true);
        return this;
    }
}
