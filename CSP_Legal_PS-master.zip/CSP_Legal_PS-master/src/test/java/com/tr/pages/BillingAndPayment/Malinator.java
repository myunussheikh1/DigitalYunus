package com.tr.pages.BillingAndPayment;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Malinator extends BasePage_PS {
	public Malinator() {
		super("locatorsDefinition/BillingAndPayment/Mailinator.json");
		PageFactory.initElements(getDriver(), this);
			
	}

	public Malinator openMailinator() throws InterruptedException, IOException {

		((JavascriptExecutor) driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(2));
		driver.get("https://www.mailinator.com/");
		ExtentLogger.pass("Opening mailinator", true);
		//Thread.sleep(600);
		waitTillElemenetVisible("enterMailID");
		sendKeysTotheElement("enterMailID", emailId);
		ExtentLogger.pass("Enter the email ID " +emailId, true);
		clickElement(getElementByXpath("ClickOnGO"));
		ExtentLogger.pass("Click on Go", true);
		return this;
	}

	public Malinator openMailinatorExisting() throws InterruptedException, IOException {

		((JavascriptExecutor) driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		driver.get("https://www.mailinator.com/");
		ExtentLogger.pass("Opening mailinator", true);
		//Thread.sleep(600);
		waitTillElemenetVisible("enterMailID");
		sendKeysTotheElement("enterMailID", emailId);
		ExtentLogger.pass("Enter the email ID " +emailId, true);
		clickElement(getElementByXpath("ClickOnGO"));
		ExtentLogger.pass("Click on Go", true);
		return this;
	}
	String emailId="";
	public Malinator getEmailID()  throws InterruptedException, IOException {
		waitTillElemenetVisible("ProfileHeader");
		clickElement(getElementByXpath("ProfileHeader"));

		waitTillElemenetVisible("ProfileButton");
		ExtentLogger.pass("Click on Profile", true);
		clickElement(getElementByXpath("ProfileButton"));
		waitTillElemenetVisible("EmailIDbox");
		emailId=getElementTextbyElement(getElementByXpath("EmailIDbox"));
		ExtentLogger.pass("Email ID is "+emailId, true);
		return  this;
	}
	public Malinator getEmailIDForInvoicePayemnt()  throws InterruptedException, IOException {

		waitTillElemenetVisible("GetEmailIDInovicePayment");
		emailId=getElementTextbyElement(getElementByXpath("GetEmailIDInovicePayment"));
		ExtentLogger.pass("Email ID is "+emailId, true);
		return  this;
	}

	public Malinator openFirstEmail() throws InterruptedException, IOException {

		Thread.sleep(20000);
		waitTillElemenetVisible("FirstEmail");
		clickElement(getElementByXpath("FirstEmail"));
		ExtentLogger.pass("Opening first Email", true);
		return this;
	}

	public Malinator openFirstEmailInvoicePayment() throws InterruptedException, IOException {

		Thread.sleep(20000);
		waitTillElemenetVisible("FirstEmailInvoicePayment");
		clickElement(getElementByXpath("FirstEmailInvoicePayment"));
		ExtentLogger.pass("Opening first Email", true);
		return this;
	}
	public Malinator openFirstEmailForAddProduct() throws InterruptedException, IOException {

		Thread.sleep(60000);
		Thread.sleep(60000);
		Thread.sleep(60000);
		Thread.sleep(60000);
		waitTillElemenetVisible("FirstEmail");
		clickElement(getElementByXpath("FirstEmail"));
		ExtentLogger.pass("Opening first Email", true);
		return this;
	}
	public Malinator openFirstEmailAdminAdd() throws InterruptedException, IOException {

		Thread.sleep(40000);
		waitTillElemenetVisible("FirstEmailAddAdmin");
		clickElement(getElementByXpath("FirstEmailAddAdmin"));
		ExtentLogger.pass("Opening first Email", true);
		return this;
	}


	public Malinator verifyEmail(BillingPage billingpage) throws InterruptedException, IOException {

		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		boolean value=driver.findElement(By.xpath("//*[text()='Autopay is enabled']")).isDisplayed();
		Assert.assertTrue(value);
		ExtentLogger.pass("Autopay is enabled is present in email", true);
		value=driver.findElement(By.xpath("//span[contains(text(),'use your VISA ending in "+billingpage.lastFourDigit+" to pay this account')]")).isDisplayed();
		Assert.assertTrue(value);
		ExtentLogger.pass(billingpage.lastFourDigit+" is present in email", true);
		//verifyAccountDetailsInEmail(accNumber);
		String accountnumberText = getElementTextbyElement(getElementByXpath("AccountnumberText"));
		System.out.println("Account number in mail is "+accountnumberText);
		ExtentLogger.pass("Account number in mail is "+accountnumberText,true);

		org.testng.Assert.assertEquals(billingpage.accountNumberUI, accountnumberText.trim());

		String accountnameText = getElementTextbyElement(getElementByXpath("AccountnameText"));
		System.out.println("Account name in mail is "+accountnameText);
		ExtentLogger.pass("Account name in mail is "+accountnameText,true);

		org.testng.Assert.assertFalse(accountnameText.trim().isEmpty());

		String accountaddressText = getElementTextbyElement(getElementByXpath("AccountaddressText"));
		System.out.println("Account address in mail is "+accountaddressText);
		ExtentLogger.pass("Account address in mail is "+accountaddressText,true);

		org.testng.Assert.assertFalse(accountaddressText.trim().isEmpty());
		driver.switchTo().defaultContent();
		return this;
	}
	public Malinator verifyAccountDetailsInEmail(String accountNumberFromExcel) throws InterruptedException, IOException {
		String accountNumberFromExcelNumber=accountNumberFromExcel.replaceAll("[^0-9]","");
		System.out.println("Account number is "+accountNumberFromExcelNumber);
		ExtentLogger.pass("Account number is "+accountNumberFromExcelNumber);

		String accountnumberText = getElementTextbyElement(getElementByXpath("AccountnumberText"));
		System.out.println("Account number in mail is "+accountnumberText);
		ExtentLogger.pass("Account number in mail is "+accountnumberText);

		Assert.assertEquals(accountNumberFromExcelNumber, accountnumberText.trim());

		String accountnameText = getElementTextbyElement(getElementByXpath("AccountnameText"));
		System.out.println("Account name in mail is "+accountnameText);
		ExtentLogger.pass("Account name in mail is "+accountnameText);

		Assert.assertFalse(accountnameText.trim().isEmpty());

		String accountaddressText = getElementTextbyElement(getElementByXpath("AccountaddressText"));
		System.out.println("Account address in mail is "+accountaddressText);
		ExtentLogger.pass("Account address in mail is "+accountaddressText);

		Assert.assertFalse(accountaddressText.trim().isEmpty());
		return this;
	}

	public Malinator verifyEmailBank(BillingPage billingpage) throws InterruptedException, IOException {


		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		boolean value=driver.findElement(By.xpath("//*[text()='Your autopay enrolment is in progress']")).isDisplayed();
		Assert.assertTrue(value);
		ExtentLogger.pass("Your autopay enrolment is in progress is present in email", true);
		value=driver.findElement(By.xpath("//b[contains(text(),'Bank account ending in "+billingpage.lastFourDigitBanking+"')]")).isDisplayed();
		Assert.assertTrue(value);
		ExtentLogger.pass(billingpage.lastFourDigitBanking+" is present in email", true);
		//verifyAccountDetailsInEmail(accNumber);
		String accountnumberText = getElementTextbyElement(getElementByXpath("AccountnumberText"));
		System.out.println("Account number in mail is "+accountnumberText);
		ExtentLogger.pass("Account number in mail is "+accountnumberText,true);

		org.testng.Assert.assertEquals(billingpage.accountNumberUI, accountnumberText.trim());

		String accountnameText = getElementTextbyElement(getElementByXpath("AccountnameText"));
		System.out.println("Account name in mail is "+accountnameText);
		ExtentLogger.pass("Account name in mail is "+accountnameText,true);

		org.testng.Assert.assertFalse(accountnameText.trim().isEmpty());

		String accountaddressText = getElementTextbyElement(getElementByXpath("AccountaddressText"));
		System.out.println("Account address in mail is "+accountaddressText);
		ExtentLogger.pass("Account address in mail is "+accountaddressText,true);

		org.testng.Assert.assertFalse(accountaddressText.trim().isEmpty());
		driver.switchTo().defaultContent();
		return this;
	}
	public Malinator verifyEmailBankCAD(BillingPage billingpage) throws InterruptedException, IOException {


		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		/*boolean value=driver.findElement(By.xpath("//*[text()='Your autopay enrolment is in progress']")).isDisplayed();
		Assert.assertTrue(value);
		ExtentLogger.pass("Your autopay enrolment is in progress is present in email", true);*/
		String value=driver.findElement(By.xpath("//span[contains(text(),'Bank account')] ")).getText();
		Assert.assertTrue(value.contains(billingpage.lastFourDigitBanking));
		ExtentLogger.pass(billingpage.lastFourDigitBanking+" is present in email", true);
		//verifyAccountDetailsInEmail(accNumber);
		String accountnumberText = getElementTextbyElement(getElementByXpath("AccountnumberText"));
		System.out.println("Account number in mail is "+accountnumberText);
		ExtentLogger.pass("Account number in mail is "+accountnumberText,true);

		org.testng.Assert.assertEquals(billingpage.accountNumberUI, accountnumberText.trim());

		String accountnameText = getElementTextbyElement(getElementByXpath("AccountnameText"));
		System.out.println("Account name in mail is "+accountnameText);
		ExtentLogger.pass("Account name in mail is "+accountnameText,true);

		org.testng.Assert.assertFalse(accountnameText.trim().isEmpty());

		String accountaddressText = getElementTextbyElement(getElementByXpath("AccountaddressText"));
		System.out.println("Account address in mail is "+accountaddressText);
		ExtentLogger.pass("Account address in mail is "+accountaddressText,true);

		org.testng.Assert.assertFalse(accountaddressText.trim().isEmpty());
		driver.switchTo().defaultContent();
		return this;
	}

	public Malinator verifyEmailExistingBank(BillingPage billingpage) throws InterruptedException, IOException {


		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		boolean value=driver.findElement(By.xpath("//*[text()='Your autopay enrolment is in progress']")).isDisplayed();
		Assert.assertTrue(value);
		ExtentLogger.pass("Your autopay enrolment is in progress is present in email", true);
		value=driver.findElement(By.xpath("//b[contains(text(),'Bank account ending in "+billingpage.ExistingCCFourDigitBank+"')]")).isDisplayed();
		Assert.assertTrue(value);
		ExtentLogger.pass(billingpage.ExistingCCFourDigitBank+" is present in email", true);
		//verifyAccountDetailsInEmail(accNumber);
		String accountnumberText = getElementTextbyElement(getElementByXpath("AccountnumberText"));
		System.out.println("Account number in mail is "+accountnumberText);
		ExtentLogger.pass("Account number in mail is "+accountnumberText,true);

		org.testng.Assert.assertEquals(billingpage.accountNumberUI, accountnumberText.trim());

		String accountnameText = getElementTextbyElement(getElementByXpath("AccountnameText"));
		System.out.println("Account name in mail is "+accountnameText);
		ExtentLogger.pass("Account name in mail is "+accountnameText,true);

		org.testng.Assert.assertFalse(accountnameText.trim().isEmpty());

		String accountaddressText = getElementTextbyElement(getElementByXpath("AccountaddressText"));
		System.out.println("Account address in mail is "+accountaddressText);
		ExtentLogger.pass("Account address in mail is "+accountaddressText,true);

		org.testng.Assert.assertFalse(accountaddressText.trim().isEmpty());
		driver.switchTo().defaultContent();
		return this;
	}



	public Malinator verifyEmailInvoicePayment(BillingPage billingpage) throws InterruptedException, IOException {


		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		boolean value=driver.findElement(By.xpath("//span[contains(text(),'Thanks for making a payment. Here')]")).isDisplayed();
		Assert.assertTrue(value);

		String text=getElementText("InvoiceNumberinMail");
		Assert.assertEquals(text,billingpage.pastDueInvoiceNumber);
		ExtentLogger.pass(billingpage.pastDueInvoiceNumber+" is present in email", true);

		text=getElementText("ConfirmationNumberinMail");
		Assert.assertEquals(text,billingpage.confirmationNumberInvoicePayment);
		ExtentLogger.pass(billingpage.confirmationNumberInvoicePayment+" is present in email", true);
		driver.switchTo().defaultContent();
		return this;
	}

	public Malinator verifyEmailExisting(BillingPage billingpage) throws InterruptedException, IOException {


		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		boolean value=driver.findElement(By.xpath("//*[text()='Autopay is enabled']")).isDisplayed();
		Assert.assertTrue(value);
		ExtentLogger.pass("Autopay is enabled is present in email", true);
		value=driver.findElement(By.xpath("//span[contains(text(),'use your VISA ending in "+billingpage.ExistingCCFourDigit+" to pay this account')]")).isDisplayed();
		Assert.assertTrue(value);
		ExtentLogger.pass(billingpage.ExistingCCFourDigit+" is present in email", true);
		//verifyAccountDetailsInEmail(accNumber);
		String accountnumberText = getElementTextbyElement(getElementByXpath("AccountnumberText"));
		System.out.println("Account number in mail is "+accountnumberText);
		ExtentLogger.pass("Account number in mail is "+accountnumberText,true);

		org.testng.Assert.assertEquals(billingpage.accountNumberUI, accountnumberText.trim());

		String accountnameText = getElementTextbyElement(getElementByXpath("AccountnameText"));
		System.out.println("Account name in mail is "+accountnameText);
		ExtentLogger.pass("Account name in mail is "+accountnameText,true);

		org.testng.Assert.assertFalse(accountnameText.trim().isEmpty());

		String accountaddressText = getElementTextbyElement(getElementByXpath("AccountaddressText"));
		System.out.println("Account address in mail is "+accountaddressText);
		ExtentLogger.pass("Account address in mail is "+accountaddressText,true);

		org.testng.Assert.assertFalse(accountaddressText.trim().isEmpty());
		return this;
	}

	public Malinator navigateBack() throws InterruptedException, IOException {
		driver.navigate().back();
		waitForPageLoad();

		return this;
	}

	public Malinator verifyUserAddProduct(String username) throws InterruptedException, IOException {


		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		String name=driver.findElement(By.xpath("//span[contains(text(),'Welcome')]/parent::div/preceding-sibling::div/b")).getText();
		Assert.assertTrue(StringUtils.containsIgnoreCase(name,username));
		ExtentLogger.pass("First name is present in email", true);
		return this;
	}

	
	public Malinator verifyUserAddProduct_2(String username) throws InterruptedException, IOException {
		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		String name=driver.findElement(By.xpath("//span[contains(text(),'Welcome')]/parent::div/preceding-sibling::div/b")).getText();
		Assert.assertTrue(StringUtils.containsIgnoreCase(name,username));
		ExtentLogger.pass("First name is present in email", true);
		return this;
	}


	public Malinator verifyUserAdmin(String username) throws InterruptedException, IOException {



		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");

		String name=driver.findElement(By.xpath("//span[contains(text(),'Welcome')]/parent::div/preceding-sibling::div/b")).getText();
		Assert.assertTrue(StringUtils.containsIgnoreCase(name,username));
		ExtentLogger.pass("First name is present in email", true);
		return this;
	}
	
	public Malinator verifyUserAddProduct_3(String username) throws InterruptedException, IOException {

		List<WebElement> ele=driver.findElements(By.xpath("//td[contains(text(),'"+username+"')]"));
		Assert.assertEquals(ele.size(),1);
		ExtentLogger.pass("Name is present in email", true);
		return this;
	}

	public Malinator verifyUserAddProductAdmin(String username) throws InterruptedException, IOException {



		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,900)");
		String name=driver.findElement(By.xpath("//b[contains(text(),'ADDPROD USA1')]")).getText();
		Assert.assertTrue(StringUtils.containsIgnoreCase(name,username));
		ExtentLogger.pass("First name is present in email", true);
		return this;
	}
	
	public Malinator verifyUserAddProduct_4(String username) throws InterruptedException, IOException {


		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,900)");
		String name=driver.findElement(By.xpath("//b[contains(text(),'ADDPRODUCTUSER UNCHECKINGMLA')]")).getText();
		Assert.assertTrue(StringUtils.containsIgnoreCase(name,username));
		ExtentLogger.pass("First name is present in email", true);
		return this;
	}
	
	
	public Malinator verifyUserRemoveProduct(String username) throws InterruptedException, IOException {


		Thread.sleep(3000);
		driver.switchTo().frame("html_msg_body");
		String name=driver.findElement(By.xpath("//td[contains(text(),'Usa, Removeprod')]")).getText();
		Assert.assertTrue(StringUtils.containsIgnoreCase(name,username));
		ExtentLogger.pass("First name is present in email", true);
		return this;

	
		/*
		 * List<WebElement>
		 * ele=driver.findElements(By.xpath("//b[contains(text(),'"+username+"')]"));
		 * Assert.assertEquals(ele.size(),1);
		 * ExtentLogger.pass("First name is present in email", true); return this;
		 */
	}
}


