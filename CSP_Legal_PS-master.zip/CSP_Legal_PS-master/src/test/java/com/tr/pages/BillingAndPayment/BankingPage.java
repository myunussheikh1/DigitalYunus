package com.tr.pages.BillingAndPayment;

import com.github.javafaker.Faker;
import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.io.IOException;
import java.util.ArrayList;

public class BankingPage extends BasePage_PS {
    JavascriptExecutor js = (JavascriptExecutor) driver;
    public BankingPage() {
        super("locatorsDefinition/BillingAndPayment/BillingPage.json");
        PageFactory.initElements(getDriver(), this);
    }

    public BankingPage clickOnManagePaymentsMethod() throws InterruptedException, IOException {
        waitForPageLoad();
        //Thread.sleep(10000);
        //driver.navigate().refresh();
        waitUntilVisible("ManagePaymentMethod","xpath",30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        System.out.println("Manage Payments methods clicked successfully");
        ExtentLogger.pass("Clicking on Manage Payments methods", true);
        return this;
    }
    public BankingPage clickOnAddPaymentMethod() throws InterruptedException, IOException {

        waitUntilVisible("AddPaymentMethod","xpath",30);
        clickElement(getElementByXpath("AddPaymentMethod"));
        System.out.println("AddPaymentMethod is clicked successfully!!");
        ExtentLogger.pass("Clicking on Add Payment method", true);
        Thread.sleep(1000);
        return this;

    }


    Faker fake = new Faker();
    String CardName = "";





    public BankingPage clickOnAdd() throws InterruptedException, IOException {
       // driver.switchTo().defaultContent();
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        ExtentLogger.pass("Clicking on Add Payment method", true);
        waitTillElemenetVisible("Add");
        clickElement(getElementByXpath("Add"));
        Thread.sleep(3000);
        //waitTillElemenetVisible("ClickOnClose");
        //ExtentLogger.pass("Credit card saved", true);
       // clickElement(getElementByXpath("ClickOnClose"));
        //Thread.sleep(3000);
        return this;

    }



    public BankingPage switchToWindow(int n) throws InterruptedException, IOException {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(n));
        ExtentLogger.pass("Switching the window", true);
        return this;
    }
    public BankingPage openURL(String url) throws InterruptedException, IOException {


        driver.get(url);
        ExtentLogger.pass("opening the url", true);
        return this;
    }

    public BankingPage openNewTab() throws InterruptedException, IOException {

        ((JavascriptExecutor) driver).executeScript("window.open()");
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        ExtentLogger.pass("Opening and switching to new tab", true);
        return this;
    }

    public BankingPage clickOnBankAccount() throws InterruptedException, IOException {
        waitForPageLoad();
        //Thread.sleep(10000);
        //driver.navigate().refresh();
        driver.switchTo().frame(driver.findElement(By.xpath("//div[@class='tr-ManagePaymentAddDialog-dialogContent']")));
        waitTillElemenetVisibleByxpath("Bank-account");
        clickElement(getElementByXpath("Bank-account"));
        System.out.println("Bank Account is clicked successfully");
        ExtentLogger.pass("Clicking Bank Account", true);
        return this;
    }
    String description1 = fake.regexify("[1-9]{9}");
    public BankingPage RountingNumber() throws InterruptedException, IOException {
        waitForPageLoad();
        //waitUntilVisible("BankAccount", "xpath", 30);
        //driver.switchTo().frame(driver.findElement(By.cssSelector(".tr-ManagePaymentAddDialog-dialogContent")));

        waitTillElemenetVisible("RoutingNumber");
       clickElement(getElementByXpath("RoutingNumber"));
        sendKeysTotheElement("RoutingNumber",description1);

        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }String description2 = fake.regexify("[1-9]{11}");
    public BankingPage AccountNumber() throws InterruptedException, IOException {
        waitForPageLoad();

        waitTillElemenetVisible("AccountNumber");
        clickElement(getElementByXpath("AccountNumber"));
        sendKeysTotheElement("AccountNumber", description2);
        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }
    String lastFourDigitBanking="";
    public BankingPage closeButtonBank() throws InterruptedException, IOException {

                waitUntilVisible("CloseButton","xpath",45);
                if (isElementDisplayed(getElementByXpath("CloseButton"))) {
                    boolean res = isElementDisplayed(getElementByXpath("BankAccountSaved"));
                    Assert.assertTrue(res);
                    String cardSavedMessage = getElementText(getElementByXpath("BankAccountSavedNumber"));
                    lastFourDigitBanking = description2;
                    lastFourDigitBanking = lastFourDigitBanking.substring(lastFourDigitBanking.length() - 4);
                    System.out.println("Last 4 digit number is " + lastFourDigitBanking);
                    Boolean b = cardSavedMessage.contains("Your bank account ending in " + lastFourDigitBanking + " has been saved.");
                    Assert.assertTrue(b);
                    ExtentLogger.pass("Pop up is visible with correct message and last 4 digit " + lastFourDigitBanking, true);
                    clickElement(getElementByXpath("CloseButton"));
                    ExtentLogger.pass("Clicking on close button", true);

                }




        return  this;

    }
    public BankingPage TransitNumDuplicateCAN(BillingPage TransitNum_CAN) throws InterruptedException, IOException {
        waitForPageLoad();
        //waitUntilVisible("BankAccount", "xpath", 30);
        //driver.switchTo().frame(driver.findElement(By.cssSelector(".tr-ManagePaymentAddDialog-dialogContent")));

        waitTillElemenetVisible("TransitNum");
        clickElement(getElementByXpath("TransitNum"));
        sendKeysTotheElement("TransitNum", TransitNum_CAN.descriptionCAN);
       // sendKeysTotheElement("RoutingNumber",Tran);

        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }
    public BankingPage InstitutionNumDuplicateCAN1(BillingPage  Institution_CAN) throws InterruptedException, IOException {
        waitForPageLoad();

        waitTillElemenetVisible("InstitutionNum");
        clickElement(getElementByXpath("InstitutionNum"));
        sendKeysTotheElement("InstitutionNum", Institution_CAN.descriptionCAN1);


        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }



}

