package com.tr.pages.BillingAndPayment;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.IOException;

public class LoginPage_BP extends BasePage_PS {

	public LoginPage_BP() {
		super("locatorsDefinition/BillingAndPayment/LoginPage.json");
		PageFactory.initElements(getDriver(), this);
	}
	public LoginPage_BP openURL(String url) throws InterruptedException, IOException {

		driver.get(url);
		ExtentLogger.pass("opening the URL "+url, true);

		return this;
	}
	public LoginPage_BP clickOnUserNameTextBox(String emailID) throws InterruptedException, IOException {
		//Thread.sleep(3000);
try {
	waitTillElemenetVisible_login("EmailTextBox");
	clickElement(getElementByXpath("EmailTextBox"));
	sendKeysTotheElement("EmailTextBox", emailID);
	ExtentLogger.pass("Entering the username", true);
	clickOnGoToAccount();
	validateInvalidEmailID();
}
catch(Exception e)
{
	//ExtentLogger.pass("UI is updated hence this usecase is invalid" , true);
}
		return this;
	}
	


	public LoginPage_BP clickOnAcceptCookies() throws InterruptedException {
			try {
				Thread.sleep(3000);
				clickElement(getElementByXpath("AcceptCookies"));
				ExtentLogger.pass("Click on Accept Cookies", true);
				return this;
			}
			catch(Exception e){

				return this;

		}
	}
	public LoginPage_BP clickOnAcceptCookiesUC() throws InterruptedException, IOException {
		waitUntilVisible("AcceptCookies", "xpath",60);
		clickElement(getElementByXpath("AcceptCookies"));
		ExtentLogger.pass("Click on Accept Cookies", true);
	return  this;
	}


	public LoginPage_BP clickOnGoToAccount() throws InterruptedException, IOException {

		clickElement(getElementByXpath("AccountSIgnInButton"));
		ExtentLogger.pass("Click on Go to Account", true);
		return this;
	}
	
	public LoginPage_BP clickOnTaxLink() throws InterruptedException, IOException {
		Thread.sleep(3000);
		try {
			if (getElementByXpath("SignintoTaxNewXpath").isDisplayed()) {

				clickElement(getElementByXpath("SignintoTaxNewXpath"));
				ExtentLogger.pass("Clicked tax link successfully", true);
			}
		}
		catch(Exception e){
			log.info(e.getMessage());
		}
		return this;
	}
	public LoginPage_BP clickOnLegalLink() throws InterruptedException, IOException {
		Thread.sleep(3000);
		try {
			if (getElementByXpath("LegalLink").isDisplayed()) {

				clickElement(getElementByXpath("LegalLink"));
				ExtentLogger.pass("Clicked Legal link successfully", true);
			}
		}
		catch(Exception e){
			log.info(e.getMessage());
		}
		return this;
	}

	public LoginPage_BP validateInvalidEmailID() throws InterruptedException, IOException {
 try {
	 String warning = getElementText(getElementByXpath("InvalidEmailIDWarning"));
	 Boolean b = warning.equalsIgnoreCase("Enter a valid email.");
	 Assert.assertTrue(b);
	 ExtentLogger.pass("Login with invalid Email id is validated", true);
	 log.info("The obtained warning is "+warning);
 }
 catch(Exception e)
 {
	 //ExtentLogger.pass("Login with invalid Email id is failed", true);
	 log.error(e);
 }
		return this;
	}


	public LoginPage_BP validateInvalidUsername() throws InterruptedException, IOException {
		try {
			String warning = getElementText(getElementByXpath("InvalidUsername"));
			Boolean b = warning.contains("Enter your email address, formatted as name@example.com.");
			Assert.assertTrue(b);
			ExtentLogger.pass("Login with invalid username is validated", true);
			log.info("The obtained warning is "+warning);
		}
		catch(Exception e)
		{
			ExtentLogger.pass("Login with invalid Username is failed", true);
			log.error(e);
		}
		return this;
	}
	public LoginPage_BP validateInvalidPassword() throws InterruptedException, IOException {
		try {
			String warning = getElementText(getElementByXpath("InvalidUsername"));
			Boolean b = warning.contains("Check to make sure your email and password are correct.");
			Assert.assertTrue(b);
			ExtentLogger.pass("Login with invalid Password is validated", true);
			log.info("The obtained warning is "+warning);
		}
		catch(Exception e)
		{
			ExtentLogger.pass("Login with invalid Password is failed", true);
			log.error(e);
		}
		return this;
	}
/*
	public LoginPage enterEmailIDinAccount(String username, String emailID) throws InterruptedException, IOException {


		try{
			waitTillElemenetVisible("SignintoTaxNewXpath");
			clickElement(getElementByXpath("SignintoTaxNewXpath"));

			ExtentLogger.pass("Sign into tax link was  available", true);
		}
		catch(Exception e)
		{
			ExtentLogger.pass("New UI is not available", true);
		}
		try{
			clickOnUserNameTextBox(emailID).clickOnGoToAccount();
			waitTillElemenetVisible("SignintoTax");
			clickElement(getElementByXpath("SignintoTax"));
			ExtentLogger.pass("Sign into tax link was  available", true);
		}
		catch(Exception e)
		{
			ExtentLogger.pass("Old UI is not available", true);
		}
		waitTillElemenetVisible("UserNameEmail");
		clickElement(getElementByXpath("UserNameEmail"));
		sendKeysTotheElement("UserNameEmail", username);
		clickElement(getElementByXpath("Continue"));
		ExtentLogger.pass("Enter the username", true);

		return this;

	}*/
	public LoginPage_BP enterEmailIDinAccount(String username, String emailID) throws InterruptedException, IOException {


		try{
			waitTillElemenetVisible_login("SignintoTaxNewXpath");
			clickElement(getElementByXpath("SignintoTaxNewXpath"));
			ExtentLogger.pass("Sign into tax link was  available", true);
		}
		catch(Exception e)
		{
			ExtentLogger.pass("New UI is not available", true);
		}
		try{
			clickOnUserNameTextBox(emailID).clickOnGoToAccount();
			waitTillElemenetVisible_login("LegalLink");
			clickElement(getElementByXpath("LegalLink"));
			ExtentLogger.pass("Sign into Legal link was  available", true);
		}
		catch(Exception e)
		{
			ExtentLogger.pass("Old UI is not available", true);
		}
		try{
		waitTillElemenetVisible_login("LegalLink");
		clickElement(getElementByXpath("LegalLink"));
		}
		catch(Exception e)
		{
			ExtentLogger.pass("Links is not available", true);
		}
		waitTillElemenetVisible_login("UserNameEmail");
		clickElement(getElementByXpath("UserNameEmail"));
		sendKeysTotheElement("UserNameEmail", username);
		//clickElement(getElementByXpath("Continue"));
		ExtentLogger.pass("Enter the username" +username, true);
		return this;

	}


	public void waitTillElemenetVisible_login(String locator) {

		Wait<WebDriver> wait = new WebDriverWait(driver, 10);
		String locatorId = getLocator(locator, "xpath");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locatorId)));
	}


	public LoginPage_BP validateLoginfunctionality() throws InterruptedException, IOException {
		try {
			waitTillElemenetVisible("SupportTab");
			Boolean b = driver.findElement(By.xpath("//a[@aria-label='Support page']")).isDisplayed();
			Assert.assertTrue(b);
			ExtentLogger.pass("Login functionality is validated", true);

		}
		catch(Exception e)
		{
			ExtentLogger.pass("Login functionality validation failed", true);
			log.error(e);
		}
		return this;
	}
	public LoginPage_BP enterPasswordinAccount(String password) throws InterruptedException, IOException {

		waitTillElemenetVisible("PasswordBP");
		clickElement(getElementByXpath("PasswordBP"));
		sendKeysTotheElement("PasswordBP",password);
		clickElement(getElementByXpath("Continue"));
		//ExtentLogger.pass("Enter the password", true);
		return this;

	}public LoginPage_BP MLAAccount() throws InterruptedException, IOException {

		waitTillElemenetVisible("MLAAccount");
		clickElement(getElementByXpath("MLAAccount"));

		return this;

	}
	public LoginPage_BP MLAAccount2() throws InterruptedException, IOException {

		waitTillElemenetVisible("MLAAccount2");
		clickElement(getElementByXpath("MLAAccount2"));

		return this;

	}

	public LoginPage_BP enterOnepassUsername(String username) throws InterruptedException, IOException {

		waitTillElemenetVisible("OnePassUsername");
		sendKeysTotheElement("OnePassUsername",username);
		ExtentLogger.pass("enter the username "+username,true);

		return this;

	}
	public LoginPage_BP enterOnepassPassword(String username) throws InterruptedException, IOException {

		waitTillElemenetVisible("OnePassPassword");
		sendKeysTotheElement("OnePassPassword",username);

		return this;

	}
	public LoginPage_BP clickOnOnepassSignIn() throws InterruptedException, IOException {

		waitTillElemenetVisible("OnePassSignInButton");
		clickElement(getElementByXpath("OnePassSignInButton"));

		return this;

	}
	public LoginPage_BP enterUsernameUC(String username) throws InterruptedException, IOException {

		waitTillElemenetVisible("UsernameUC");
		sendKeysTotheElement("UsernameUC",username);
		ExtentLogger.pass("enter the username "+username,true);

		return this;

	}
	
}
