package com.tr.pages.BillingAndPayment;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.List;

public class HomePage extends BasePage_PS
    {
    public HomePage() {
        super("locatorsDefinition/BillingAndPayment/HomePage.json");
        PageFactory.initElements(getDriver(), this);
    }


        String pastDueAmount="";
        public HomePage getPastDue() throws InterruptedException, IOException {
            waitForPageLoad();
            Thread.sleep(5000);
            String text = driver.findElement(By.xpath("//*[contains(text(),'Includes a past due amount of')]")).getText();
            pastDueAmount = text.split("of")[1].trim();

            System.out.println(pastDueAmount);
            ExtentLogger.pass("Past due amount is "+pastDueAmount, true);
            return this;
        }

        String totalDueAmount="";
        public HomePage totalDue() throws InterruptedException, IOException {
            waitForPageLoad();
            Thread.sleep(5000);
            String text = driver.findElement(By.xpath("//*[@id='total-due-formatted-amount']")).getText();
            totalDueAmount = text.trim();

            System.out.println(totalDueAmount);
            ExtentLogger.pass("Total due amount is "+totalDueAmount, true);
            return this;
        }
        public HomePage signout() throws InterruptedException, IOException {



            waitTillElemenetVisible("Profile");
            clickElement(getElementByXpath("Profile"));
            ExtentLogger.pass("Clicking on Profile", true);
            Thread.sleep(5000);
            waitTillElemenetVisible("Signout");
            clickElement(getElementByXpath("Signout"));
            ExtentLogger.pass("Clicking on Signout", true);
            Thread.sleep(2000);
            Boolean a=driver.findElement(By.xpath("//strong[text()='You’re signed out']")).isDisplayed();
            Assert.assertTrue(a);
            ExtentLogger.pass("User has successfully signed out!!", true);


            return this;

        }

        public HomePage clearCookies() throws InterruptedException, IOException {
            driver.manage().deleteAllCookies();
            Thread.sleep(2000);
            ExtentLogger.pass("Deleting the cookies", true);
            return this;

        }


        String invoiceAmount="";
        public HomePage getInvoiceAmount(String invoiceNumber) throws InterruptedException, IOException {
            waitForPageLoad();
            waitTillElemenetVisible("InvoicesTable");
            Thread.sleep(5000);
            boolean a = true;
            while (a) {
              try {
                  String value = driver.findElement(By.xpath("//a[text()='" + invoiceNumber + "']/parent::th/parent::tr//p")).getText().trim();
                  invoiceAmount=value;
                  System.out.println("Invoice amount for invoice number "+invoiceNumber+" is "+invoiceAmount);
                  ExtentLogger.pass("Invoice amount for invoice number "+invoiceNumber+" is "+invoiceAmount,true);
                  break;
              }
              catch(NoSuchElementException ex) {
                  System.out.println("Invoice number is not present in first page");
                  ExtentLogger.pass("Invoice number is not present in first page",true);
                  try {
                      if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")) {
                          break;
                      } else {
                          driver.findElement(By.xpath("//span[text()='Next']")).click();
                      }
                  } catch (NoSuchElementException e) {
                      System.out.println("next button is not visible " + e.getMessage());
                      break;
                  }
              }
            }
            return this;
        }
        public HomePage clickOncreateNewAdmin() throws InterruptedException, IOException {
            waitForPageLoad();
            waitUntilVisible("CreateNewAdmin","xpath",60);
            ExtentLogger.pass("Click on Create a new Admin", true);
            clickElement(getElementByXpath("CreateNewAdmin"));

            return this;
        }
        public HomePage createNewAdmin(String username,String lastname, String BU, String permission) throws InterruptedException, IOException {
            waitForPageLoad();
            waitUntilVisible("NewAdminFirstName","xpath",60);
            sendKeysTotheElement("NewAdminFirstName",username+lastname);
            sendKeysTotheElement("NewAdminLastName",username+lastname);
            sendKeysTotheElement("NewAdminEmail",username+lastname+"@mailinator.com");
            ExtentLogger.pass("Details are entered for new Admin", true);
            clickElement(getElementByXpath("CreateNewAdminButton"));
            waitUntilVisible("AssignAccountButton","xpath",60);
            ExtentLogger.pass("Clicking on Assign Account Button", true);
            clickElement(getElementByXpath("AssignAccountButton"));
            waitUntilVisible("BUDropDown","xpath",60);
            clickElement(getElementByXpath("BUDropDown"));
            Thread.sleep(1000);
            ExtentLogger.pass("Clicking BU drop down Button", true);
            driver.findElement(By.xpath("//span[text()='"+BU+"']/ancestor::li")).click();
            sendKeysTotheElement("ParentNumber",username);
            clickElement(getElementByXpath("ChoosePermission"));
            ExtentLogger.pass("Clicking on Choose Permission drop down Button", true);
            String permissions[]=permission.split(",");
            for(int i=0;i<permissions.length;i++){
                driver.findElement(By.xpath("//div[text()='"+permissions[i].trim()+"']/ancestor::label")).click();
            }

            clickElement(getElementByXpath("ParentNumber"));
            ExtentLogger.pass("Selected the permission", true);
            clickElement(getElementByXpath("Assignparent"));
            Thread.sleep(3000);
            waitUntilVisible("UserDetialsBreadCrum","xpath",60);
            ExtentLogger.pass("Clicking on User Details BreadCrum", true);
            clickElement(getElementByXpath("UserDetialsBreadCrum"));
            waitUntilVisible("ActionButton","xpath",60);
            ExtentLogger.pass("Clicking on Action Button", true);
            clickElement(getElementByXpath("ActionButton"));
            waitUntilVisible("SendInviteButton","xpath",60);
            ExtentLogger.pass("Clicking on Send Invite Button", true);
            clickElement(getElementByXpath("SendInviteButton"));




            return this;
        }

        }
