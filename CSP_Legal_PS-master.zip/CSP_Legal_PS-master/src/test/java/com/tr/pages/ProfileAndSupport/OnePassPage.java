package com.tr.pages.ProfileAndSupport;

import com.github.javafaker.Faker;
import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.ArrayList;

public class OnePassPage extends BasePage_PS {
    Faker fake = new Faker();
	public OnePassPage() {
		super("locatorsDefinition/ProfileAndSupport/OnePassPage.json");
        PageFactory.initElements(getDriver(), this);
    }

    public OnePassPage openURL(String url) throws InterruptedException {

        driver.get(url);

        return this;
    }

	public OnePassPage clickOnCreateOnePassProfile() throws InterruptedException, IOException {

        waitTillElemenetVisible("CreateOnePassProfile");
        clickElement(getElementByXpath("CreateOnePassProfile"));
        ExtentLogger.pass("Clicked on the create One pass profile link", true);
        return this;
    }
    public OnePassPage clickOnContinue() throws InterruptedException, IOException {

        waitTillElemenetVisible("OnePassContinue");
        clickElement(getElementByXpath("OnePassContinue"));
        ExtentLogger.pass("Clicked on the continue button", true);
        return this;
    }
    String emailOnepass="";
    public OnePassPage enterEmailID() throws InterruptedException, IOException {
        firstNameOnepass=firstNameOnepass.toLowerCase();
        lastNameOnepass=lastNameOnepass.toLowerCase();
        emailOnepass = firstNameOnepass+lastNameOnepass+"@mailinator.com";
        waitTillElemenetVisible("EmailID");
        clickElement(getElementByXpath("EmailID"));
        sendKeysTotheElement("EmailID", emailOnepass);
        ExtentLogger.pass("Email ID is entered successfully...", true);

        return this;

    }
    String firstNameOnepass=fake.name().firstName();
    public OnePassPage enterfirstName() throws InterruptedException, IOException {
        waitTillElemenetVisible("FirstName");
        clickElement(getElementByXpath("FirstName"));
        sendKeysTotheElement("FirstName", firstNameOnepass);
        ExtentLogger.pass("First Name is entered successfully...", true);

        return this;

    }
    String lastNameOnepass=fake.name().lastName();
    public OnePassPage enterlastName() throws InterruptedException, IOException {
        waitTillElemenetVisible("LastName");
        clickElement(getElementByXpath("LastName"));
        sendKeysTotheElement("LastName", lastNameOnepass);
        ExtentLogger.pass("Last Name is entered successfully...", true);

        return this;

    }

    public OnePassPage enterconfirmedEmailId() throws InterruptedException, IOException {

        waitTillElemenetVisible("ConfirmEmailAddress");
        clickElement(getElementByXpath("ConfirmEmailAddress"));
        sendKeysTotheElement("ConfirmEmailAddress", emailOnepass);
        ExtentLogger.pass("Confirmed Email ID is entered successfully...", true);
        return this;
    }
    
    public OnePassPage enterUsername() throws InterruptedException, IOException {

        waitTillElemenetVisible("Username");
        clickElement(getElementByXpath("Username"));
        Thread.sleep(1000);
        sendKeysTotheElement("Username", emailOnepass);
        ExtentLogger.pass("Username is entered successfully...", true);
        return this;
    }
    public OnePassPage enterUsername(OnePassPage onePassPage) throws InterruptedException, IOException {
    	Thread.sleep(1000);
        waitTillElemenetVisible("Username");
        clickElement(getElementByXpath("Username"));
        Thread.sleep(1000);
        sendKeysTotheElement("Username", onePassPage.emailOnepass);
        ExtentLogger.pass("Username is entered successfully...", true);
        return this;
    }

    String passwordOnePass="Test@369";
    public OnePassPage enterPassword() throws InterruptedException, IOException {

        waitTillElemenetVisible("Password");
        clickElement(getElementByXpath("Password"));
        sendKeysTotheElement("Password", passwordOnePass);
        ExtentLogger.pass("Password is entered successfully...", true);

        return this;

    }
    public OnePassPage clickSignIn() throws InterruptedException, IOException {

        waitTillElemenetVisible("SignInbutton");
        clickElement(getElementByXpath("SignInbutton"));

        ExtentLogger.pass("Sign in is successfully...", true);

        return this;

    }
    public OnePassPage enterConfirmPassword() throws InterruptedException, IOException {

        waitTillElemenetVisible("ConfirmPassword");
        clickElement(getElementByXpath("ConfirmPassword"));
        sendKeysTotheElement("ConfirmPassword", passwordOnePass);
        ExtentLogger.pass("Confirm Password is entered successfully...", true);

        return this;

    }
    public OnePassPage selectSecurityQuestion() throws InterruptedException, IOException {

        waitTillElemenetVisible("SecurityQuestion");
        selectValueInDropdown("SecurityQuestion","0");

        ExtentLogger.pass("What is your city of birth? is selected in security question", true);

        return this;

    }
    public OnePassPage enterSecurityAnswer() throws InterruptedException, IOException {

        waitTillElemenetVisible("SecurityAnswer");
        clickElement(getElementByXpath("SecurityAnswer"));
        sendKeysTotheElement("SecurityAnswer", "test");
        ExtentLogger.pass("Security Answer is entered successfully...", true);

        return this;

    }
    public OnePassPage clickOnCreateOnePass() throws InterruptedException, IOException {

        waitTillElemenetVisible("CreateOnePass");
        clickElement(getElementByXpath("CreateOnePass"));
        ExtentLogger.pass("Clicked on the Create OnePass button", true);
        return this;
    }
    public OnePassPage openNewTab() throws InterruptedException, IOException {

        ((JavascriptExecutor) driver).executeScript("window.open()");
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        return this;
    }
    
    public OnePassPage verifyOnePassFirstName(OnePassPage onepass) throws InterruptedException, IOException {
        Thread.sleep(1000);
    	waitTillElemenetVisible("FirstName");
    	String name = getElementByXpath("FirstName").getAttribute("value");
        Boolean b = name.equalsIgnoreCase(onepass.firstNameOnepass);
        Assert.assertTrue(b);
        ExtentLogger.pass("FirstName is successfully validated", true);
        return this;
    }

    public OnePassPage verifyOnePassLastName(OnePassPage onepass) throws InterruptedException, IOException {
        String name = getElementByXpath("LastName").getAttribute("value");
        Boolean b = name.equalsIgnoreCase(onepass.lastNameOnepass);
        Assert.assertTrue(b);
        ExtentLogger.pass("LastName is successfully validated", true);
        return this;

    }
    
    public OnePassPage verifyOnePassEmailId(OnePassPage onepass) throws InterruptedException, IOException {
        String emailId = getElementByXpath("EmailID").getAttribute("value");
        Boolean b = emailId.equalsIgnoreCase(onepass.firstNameOnepass.toLowerCase()+onepass.lastNameOnepass.toLowerCase()+"@mailinator.com");
        Assert.assertTrue(b);
        ExtentLogger.pass("Email Id is successfully validated", true);
        return this;

    }
    
    public OnePassPage clickOnContinueToAccount() throws InterruptedException, IOException {
    	Thread.sleep(1000);
        waitTillElemenetVisible("RegistrationComplete");
        clickElement(getElementByXpath("ContinueToAccount"));
        Thread.sleep(10000);
        ExtentLogger.pass("Clicked on the Continue To Account button", true);
        return this;
    }
    
    
    public OnePassPage enterRegconfirmedEmailId(OnePassPage onepass) throws InterruptedException, IOException {
    	String emailIdOnepass = onepass.firstNameOnepass.toLowerCase()+onepass.lastNameOnepass.toLowerCase()+"@mailinator.com";
    	waitTillElemenetVisible("ConfirmEmailAddress");
        clickElement(getElementByXpath("ConfirmEmailAddress"));
        sendKeysTotheElement("ConfirmEmailAddress", emailIdOnepass);
        ExtentLogger.pass("Confirmed Email ID is entered successfully...", true);
        return this;
    }


    public OnePassPage enterRegUsername(OnePassPage onepass) throws InterruptedException, IOException {
    	String emailIdOnepass = onepass.firstNameOnepass.toLowerCase()+onepass.lastNameOnepass.toLowerCase()+"@mailinator.com";
    	Thread.sleep(1000);
        waitTillElemenetVisible("Username");
        clickElement(getElementByXpath("Username"));
        Thread.sleep(1000);
        sendKeysTotheElement("Username", emailIdOnepass);
        ExtentLogger.pass("Username is entered successfully...", true);
        return this;
    }
}
