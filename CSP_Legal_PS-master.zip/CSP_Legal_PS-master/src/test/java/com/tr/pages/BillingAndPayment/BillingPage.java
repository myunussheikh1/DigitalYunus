package com.tr.pages.BillingAndPayment;

import com.github.javafaker.CreditCardType;
import com.github.javafaker.Faker;
import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;

import org.openqa.selenium.*;

import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.io.IOException;
import java.util.ArrayList;

import java.util.List;


public class BillingPage extends BasePage_PS {
    JavascriptExecutor js = (JavascriptExecutor) driver;

    public BillingPage() {
        super("locatorsDefinition/BillingAndPayment/BillingPage.json");
        PageFactory.initElements(getDriver(), this);
    }
    Faker fake = new Faker();
    String currency="";
    public BillingPage checkCurrencyUKI() throws InterruptedException, IOException {
        waitForPageLoad();
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(2000);
        waitTillElemenetVisible("currencyUnit");
        currency= getElementTextbyElement(getElementByXpath("currencyUnit"));
        currency = currency.substring(currency.indexOf("(")+1, currency.indexOf(")"));
        System.out.println("Currency is "+currency);
        ExtentLogger.pass("Currency is "+currency, true);
        return this;
    }
    String accountNumberUI="";
    public BillingPage getAccountNumber() throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("AccountNumberAuth");
        accountNumberUI= getElementTextbyElement(getElementByXpath("AccountNumberAuth"));
        System.out.println("account number in UI "+accountNumberUI);
        accountNumberUI=accountNumberUI.replaceAll("[^0-9]","");
        System.out.println("Account number is "+accountNumberUI);
        ExtentLogger.pass("Account number is "+accountNumberUI, true);
       /* if(!containsInteger(accountNumberUI)){

        }else{
            accountNumberUI= getElementTextbyElement(getElementByXpath("AccountNumberUnAuthNew"));
            System.out.println("Account number is "+accountNumberUI);
            ExtentLogger.pass("Account number is "+accountNumberUI, true);
        }*/

        return this;
    }
    public boolean containsInteger(String text1){
        try{
            Integer.parseInt(text1.replaceAll("[^0-9]+",""));
            return true;
        }catch(Exception ex){
            return false;
        }
    }

    public BillingPage DeleteCC(String card1) throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("VerifyCardName");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        System.out.println("Card number is "+card1);
        ExtentLogger.pass("Card number is "+card1,true);
        lastFourDigit = card1.substring(card1.length() - 4);
        List<WebElement> list = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));
        if (list.isEmpty()) {
            ExtentLogger.pass("Card is not present", true);
            System.out.println("Card is not present");
            clickElement(getElementByXpath("BackToBillingfromAddPaymentMethod"));
            waitForPageLoad();
            return this;

        }
        System.out.println("size is " + list.size());
        int i = 1;
        boolean flag = false;
        for (WebElement ele : list) {
           // String name = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            //String expirationDate = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

                flag = true;
                ExtentLogger.pass("Card details are verified", true);
                driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-SavedPaymentMethod-tileBodyWrapper']//button[text()='Delete']")).click();
                waitTillElemenetVisible("DeleteButtonConfirmation");
                clickElement(getElementByXpath("DeleteButtonConfirmation"));
                waitTillElemenetVisible("CreditCardRemovedMessage");
                String value = getElementTextbyElement(getElementByXpath("CreditCardRemovedMessage"));
                boolean res = value.contains("Credit card removed");
                Assert.assertTrue(res);

                value = getElementTextbyElement(getElementByXpath("CreditCardRemovedNumberMessage"));
                res = value.contains("Your credit card ending in " + lastFourDigit + " has been removed.");
                Assert.assertTrue(res);

                clickElement(getElementByXpath("CloseButton"));
                Thread.sleep(3000);


                flag = true;
                i++;
                break;



        }
        if (flag == true) {
            ExtentLogger.pass("Clicked on credit card delete button successfully", true);
        }
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int j = 1;
        boolean creditCardDeletionflag = true;
        if (list1.size() == 0) {
            ExtentLogger.pass("Card is deleted successfully", true);
            creditCardDeletionflag = true;
        }
        for (WebElement ele1 : list1) {
           // String name1 = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + j + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate1 = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + j + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();


                ExtentLogger.pass("Credit card is not deleted", true);
                creditCardDeletionflag = false;
            j++;
                break;


        }

        if (creditCardDeletionflag = true) {
            Thread.sleep(2000);
            clickElement(getElementByXpath("BackToBillingfromAddPaymentMethod"));
            waitForPageLoad();
            ExtentLogger.pass("Credit card deleted successfully", true);
        } else {
            ExtentLogger.pass("Credit card deletion failed", true);
            Assert.assertTrue(false);

        }


        return this;
    }

    public BillingPage validateCurrencyAsGBPAndAutoPay() throws InterruptedException, IOException {
        Assert.assertEquals(currency,"GBP");
        Assert.assertTrue(driver.findElement(By.xpath("//*[contains(text(),'Bank account ending in')]")).isDisplayed());
        String text=driver.findElement(By.xpath("//*[contains(text(),'Bank account ending in')]")).getText();
        lastFourDigitBanking = text.split("ending in")[1].trim();
        //lastFourDigit = cardnumber;
        //lastFourDigit = lastFourDigit.substring(lastFourDigit.length() - 4);
        System.out.println(lastFourDigitBanking);
        ExtentLogger.pass("Currency is GBP and autopay is turned on with bank whose last 4 digits is "+lastFourDigitBanking, true);


        return this;
    }


    public BillingPage turnOffAutoPayforInvoice() throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisibleByxpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]");
        String text=driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText();
        if(text.contains("Manage autopay")){
            waitForPageLoad();
            waitTillElemenetVisible("ManageAutoPay1");
            clickElement(getElementByXpath("ManageAutoPay1"));
            System.out.println("Manage autopay is clicked successfully!!");
            ExtentLogger.pass("Clicking on manage AutoPay", true);
            Thread.sleep(1000);
            waitTillElemenetVisible("TurnOffAutoPay");
            clickElement(getElementByXpath("TurnOffAutoPay"));
            Reason_Autopay();
            verifyAutopayOFF();
            backtobillingFromAutopay();
            waitForPageLoad();
            ExtentLogger.pass("Turned off autopay before proceeding with invoice payment", true);
            Thread.sleep(2000);
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(3000);
            text=driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText();
            if(text.contains("Manage autopay")){
                Assert.fail();
            }
        }

        return this;
    }

    public BillingPage SortByStatus() throws InterruptedException, IOException {
        waitForPageLoad();
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(3000);
        for(int i=1;i<=3;i++){
            clickElement(getElementByXpath("StatusSort"));
            if(getElementText("GetStatusText").contains("Past due"))
                break;
        }
        ExtentLogger.pass("Sorted status by Past due", true);

        return this;
    }

    String pastDueInvoiceNumber="";
    public BillingPage getPastDueInvoice() throws InterruptedException, IOException {
        pastDueInvoiceNumber=getElementText("GetPastDueInvoice");
        clickElement(getElementByXpath("GetPastDueInvoice"));
        waitForPageLoad();
        System.out.println("Past Due invoice number is "+pastDueInvoiceNumber);
        ExtentLogger.pass("Past Due invoice number is "+pastDueInvoiceNumber, true);
        waitUntilVisible("PayAmountButton", "xpath", 30);
        clickElement(getElementByXpath("PayAmountButton"));
        ExtentLogger.pass("Click on Pay Amount button", true);
        return this;
    }

    public BillingPage clickOnManagePaymentsMethod() throws InterruptedException, IOException {
        waitForPageLoad();
        //Thread.sleep(10000);
        //driver.navigate().refresh();
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        System.out.println("Manage Payments methods clicked successfully");
        ExtentLogger.pass("Clicking on Manage Payments methods", true);
        return this;
    }

    public BillingPage clickOnAddPaymentMethod() throws InterruptedException, IOException {

        waitUntilVisible("AddPaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("AddPaymentMethod"));
        System.out.println("AddPaymentMethod is clicked successfully!!");
        ExtentLogger.pass("Clicking on Add Payment method", true);
        Thread.sleep(1000);
        return this;

    }

    public BillingPage clickOnCreditCardorBank() throws InterruptedException, IOException {
        waitForPageLoad();
        if(currency.equals("GBP")){
            System.out.println("Currency is equal to GBP");
            boolean res = isElementDisplayed(getElementByXpath("BankAccountHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberTextBox"));
            Assert.assertTrue(res);
           boolean val= driver.findElement(By.xpath("//div[@class='tr-Grid-items']/div[@class='tr-Grid-item']/div[@class='tr-FormInput']/div/input[@id='Service User Number' or @id='serviceUserNumber' and @value='283036']")).isEnabled();
           Assert.assertFalse(val);
            res = isElementDisplayed(getElementByXpath("SortCodeHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("SortCodeTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("AccountNumberHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("AccountNumberTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("BankImage"));
            Assert.assertTrue(res);
            ExtentLogger.pass("All the textboxes in Add payment method for BANK is visible", true);
            clickOnCreditCard();

        }else{

         //   clickOnCreditCard();
        }
        return this;
    }

    public BillingPage clickOnCreditCardorBankUnAuth(BillingPage b) throws InterruptedException, IOException {
        waitForPageLoad();
        if(b.currency.equals("GBP")){
            System.out.println("Currency is equal to GBP");
            boolean res = isElementDisplayed(getElementByXpath("BankAccountHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberTextBox"));
            Assert.assertTrue(res);
            boolean val= driver.findElement(By.xpath("//div[@class='tr-Grid-items']/div[@class='tr-Grid-item']/div[@class='tr-FormInput']/div/input[@name='serviceUserNumber' and @value='283036']")).isEnabled();
            Assert.assertFalse(val);
            res = isElementDisplayed(getElementByXpath("SortCodeHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("SortCodeTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("AccountNumberHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("AccountNumberTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("BankImage"));
            Assert.assertTrue(res);
            ExtentLogger.pass("All the textboxes in Add payment method for BANK is visible", true);
            clickOnCreditCard();

        }else{

            //   clickOnCreditCard();
        }
        return this;
    }
    public BillingPage clickOnAcceptCookies() throws InterruptedException {
        try {
            Thread.sleep(3000);
            waitTillElemenetVisible("AcceptCookies");
            clickElement(getElementByXpath("AcceptCookies"));
            ExtentLogger.pass("Click on Accept Cookies", true);
            return this;
        }
        catch(Exception e){
            System.out.println(e.getMessage());

            return this;

        }
    }
    String sortCode = fake.regexify("[1-9]{6}");
    String accountNumber = fake.regexify("[1-9]{8}");
    public BillingPage clickOnBankUKI() throws InterruptedException, IOException {
        waitForPageLoad();
        if(currency.equals("GBP")){
            System.out.println("Currency is equal to GBP");
            waitTillElemenetVisible("BankAccountHeading");
            boolean res = isElementDisplayed(getElementByXpath("BankAccountHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberTextBox"));
            Assert.assertTrue(res);
            boolean val= driver.findElement(By.xpath("//div[@class='tr-Grid-items']/div[@class='tr-Grid-item']/div[@class='tr-FormInput']/div/input[@name='serviceUserNumber' and @value='283036']")).isEnabled();
            Assert.assertFalse(val);
            res = isElementDisplayed(getElementByXpath("SortCodeHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("SortCodeTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("AccountNumberHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("AccountNumberTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("BankImage"));
            Assert.assertTrue(res);
            ExtentLogger.pass("All the textboxes in Add payment method for BANK is visible", true);
            sendKeysTotheElement("SortCodeTextBox",sortCode);
            sendKeysTotheElement("AccountNumberTextBox",accountNumber);
            lastFourDigitBanking = accountNumber.substring(accountNumber.length() - 4);
            ExtentLogger.pass("Entered Sort code "+sortCode, true);
            ExtentLogger.pass("Entered Account number "+accountNumber, true);
            ExtentLogger.pass("Entered Account number last 4 digits are "+lastFourDigitBanking, true);


        }else{

            System.out.println("Currency is not equal to GBP");
        }
        return this;
    }

    public BillingPage clickOnBankUKIUnAuth(BillingPage b) throws InterruptedException, IOException {
        waitForPageLoad();
        if(b.currency.equals("GBP")){
            System.out.println("Currency is equal to GBP");
            boolean res = isElementDisplayed(getElementByXpath("BankAccountHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("ServiceUserNumberTextBox"));
            Assert.assertTrue(res);
            boolean val= driver.findElement(By.xpath("//div[@class='tr-Grid-items']/div[@class='tr-Grid-item']/div[@class='tr-FormInput']/div/input[@name='serviceUserNumber' and @value='283036']")).isEnabled();
            Assert.assertFalse(val);
            res = isElementDisplayed(getElementByXpath("SortCodeHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("SortCodeTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("AccountNumberHeading"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("AccountNumberTextBox"));
            Assert.assertTrue(res);
            res = isElementDisplayed(getElementByXpath("BankImage"));
            Assert.assertTrue(res);
            ExtentLogger.pass("All the textboxes in Add payment method for BANK is visible", true);
            sendKeysTotheElement("SortCodeTextBox",sortCode);
            sendKeysTotheElement("AccountNumberTextBox",accountNumber);
            lastFourDigitBanking = accountNumber.substring(accountNumber.length() - 4);
            ExtentLogger.pass("Entered Sort code "+sortCode, true);
            ExtentLogger.pass("Entered Account number "+accountNumber, true);
            ExtentLogger.pass("Entered Account number last 4 digits are "+lastFourDigitBanking, true);


        }else{

            System.out.println("Currency is not equal to GBP");
        }
        return this;
    }


    public BillingPage closeButtonBankUKI() throws InterruptedException, IOException {

        waitUntilVisible("CloseButton", "xpath", 45);
        boolean res = isElementDisplayed(getElementByXpath("BankAccountSaved"));
        Assert.assertTrue(res);
        String cardSavedMessage = getElementText(getElementByXpath("BankAccountSavedNumber"));
        Boolean b = cardSavedMessage.contains("Your bank account ending in " + lastFourDigitBanking + " has been saved.");
        Assert.assertTrue(b);
        ExtentLogger.pass("Pop up is visible with correct message and last 4 digit " + lastFourDigitBanking, true);
        clickElement(getElementByXpath("CloseButton"));
        ExtentLogger.pass("Clicking on close button", true);
        return  this;
    }




    public BillingPage clickOnCreditCard() throws InterruptedException, IOException {
        waitForPageLoad();
        //Thread.sleep(10000);
        //driver.navigate().refresh();
        waitUntilVisible("CreditCard", "xpath", 30);
        clickElement(getElementByXpath("CreditCard"));
        System.out.println("Credit card is clicked successfully");
        ExtentLogger.pass("Clicking on Credit card", true);
        return this;
    }


    String CardName = "";

    public BillingPage enterNameOnCard() throws InterruptedException, IOException {
        Thread.sleep(3000);

        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        waitUntilVisible("NameOnCard", "xpath", 30);
        clickElement(getElementByXpath("NameOnCard"));
        CardName = fake.name().firstName();
        sendKeysTotheElement("NameOnCard", CardName);
        System.out.println("Name on card is " + CardName);
        driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage generateCreditCard() throws InterruptedException, IOException {
        cardnumber=fake.finance().creditCard(CreditCardType.VISA);
        cardnumber=cardnumber.replace("-","");
        System.out.println("Generated Visa Card Number: " + cardnumber);
        ExtentLogger.pass("Generated Visa Card Number: "+cardnumber,true);
    return this;
    }


    public BillingPage enterCardNumber() throws InterruptedException, IOException {

        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
       // String CardNumber = "45323388893023269222";
        waitTillElemenetVisible("CardNumber");
        clickElement(getElementByXpath("CardNumber"));

       // cardnumber="411111111111111";

        sendKeysTotheElement("CardNumber", cardnumber);
        driver.switchTo().defaultContent();
        return this;
    }
    public BillingPage enterCardNumber1() throws InterruptedException, IOException {

        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        // String CardNumber = "45323388893023269222";
        waitTillElemenetVisible("CardNumber");
        clickElement(getElementByXpath("CardNumber"));

          cardnumber="4080092476541121";

        sendKeysTotheElement("CardNumber", cardnumber);
        driver.switchTo().defaultContent();
        return this;
    }

    public BillingPage enterCardNumberforPaymentofInvoice() throws InterruptedException, IOException {

        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        // String CardNumber = "45323388893023269222";
        waitTillElemenetVisible("CardNumber");
        clickElement(getElementByXpath("CardNumber"));
        // cardnumber="4032031698092029";
        sendKeysTotheElement("CardNumber", cardnumber);
        driver.switchTo().defaultContent();
        return this;
    }
    public BillingPage enterCardNumberFromExcel(String number) throws InterruptedException, IOException {
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        // String CardNumber = "4532333023269222";
        waitTillElemenetVisible("CardNumber");
        clickElement(getElementByXpath("CardNumber"));
        sendKeysTotheElement("CardNumber", number);
        driver.switchTo().defaultContent();
        return this;

    }
    public BillingPage enterCardNumberFromExcelUKI(String number) throws InterruptedException, IOException {
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        // String CardNumber = "4532333023269222";
        waitTillElemenetVisible("CardNumber");
        clickElement(getElementByXpath("CardNumber"));
        cardnumber=number;
        System.out.println("Cardnumber is "+cardnumber);
        ExtentLogger.pass("Cardnumber is "+cardnumber,true);
        sendKeysTotheElement("CardNumber", number);
        driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage SelectMonthAndYear(String futuremonth, String futureyear) throws InterruptedException, IOException {
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        WebElement month = driver.findElement(By.xpath("//select[@id='selectCardMonth']"));
        Select drp = new Select(month);
        selectValue(month, futuremonth);
        //drp.selectByVisibleText(futuremonth);
        Thread.sleep(1000);

        WebElement year = driver.findElement(By.xpath("//select[@name='selectCardYear']"));
        Select drp1 = new Select(year);
        selectValue(year, futureyear);
        driver.switchTo().defaultContent();
        // drp1.selectByValue(futureyear);
        return this;

    }

    public BillingPage enterSecurityCode() throws InterruptedException, IOException {
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        String code = "123";
        waitTillElemenetVisible("SecurityCode");
        clickElement(getElementByXpath("SecurityCode"));
        sendKeysTotheElement("SecurityCode", code);
        driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage clickOnAdd() throws InterruptedException, IOException {
        // driver.switchTo().defaultContent();
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        ExtentLogger.pass("Clicking on Add Payment method", true);
        waitTillElemenetVisible("Add");
        clickElement(getElementByXpath("Add"));
        Thread.sleep(3000);
        //waitTillElemenetVisible("ClickOnClose");
        //ExtentLogger.pass("Credit card saved", true);
        // clickElement(getElementByXpath("ClickOnClose"));
        //Thread.sleep(3000);
        return this;

    }

    public BillingPage clickOnAddUKI() throws InterruptedException, IOException {
        // driver.switchTo().defaultContent();
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        ExtentLogger.pass("Clicking on Add Payment method", true);
        waitTillElemenetVisible("Add");
        clickElement(getElementByXpath("Add"));
        Thread.sleep(3000);
        Thread.sleep(7000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("creditCardIframe");
        System.out.println("inside creditCardIframe ");
        ExtentLogger.pass("inside creditCardIframe ", true);
        System.out.println("1st frame");
        try{
            driver.switchTo().frame("challengeFrame");
            System.out.println("inside challengeFrame ");
            ExtentLogger.pass("inside challengeFrame ", true);
        }
        catch (NoSuchFrameException e){
            driver.switchTo().frame("redirectTo3ds1Frame");
            System.out.println("inside redirectTo3ds1Frame ");
            ExtentLogger.pass("inside redirectTo3ds1Frame ", true);
        }
        System.out.println("2nd frame");
        Thread.sleep(3000);
        ExtentLogger.pass("Clicking on the pop up", true);
        WebElement subm=driver.findElement(By.xpath("//input[@value='Submit']"));
        js.executeScript("arguments[0].click();",subm);
        driver.switchTo().defaultContent();
        //waitTillElemenetVisible("ClickOnClose");
        //ExtentLogger.pass("Credit card saved", true);
        // clickElement(getElementByXpath("ClickOnClose"));
        //Thread.sleep(3000);
        return this;

    }


    public BillingPage clickOnAdd_UKI() throws InterruptedException, IOException {
        // driver.switchTo().defaultContent();
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(1000);
        ExtentLogger.pass("Clicking on Add Payment method", true);
        waitTillElemenetVisible("Add");
        clickElement(getElementByXpath("Add"));
        Thread.sleep(9000);


        int eles = driver.findElements(By.tagName("iframe")).size();

        System.out.println(eles);

       /* for(int i=0;i<=eles;i++){

            System.out.println(i);

            driver.switchTo().frame(i);
            Thread.sleep(3000);
            int a=driver.findElements(By.xpath("//input[@value='Submit']")).size();
            System.out.println(a);
               // System.out.println(ele);
                driver.switchTo().defaultContent();


        }*/
        // WebElement subm=driver.findElement(By.xpath("//input[@value='Submit']"));
        // js.executeScript("arguments[0].click();",subm);
        driver.findElement(By.xpath("//span[normalize-space()='Add']")).click();
        //  driver.switchTo().frame(4);
        Thread.sleep(3000);
        // WebElement subm=driver.findElement(By.xpath("//input[@value='Submit']"));
        // js.executeScript("arguments[0].click();",subm);
        //waitTillElemenetVisible("SubmitUKI");
        // clickElement(getElementByXpath("SubmitUKI"));
        // driver.switchTo().defaultContent();
        //waitTillElemenetVisible("ClickOnClose");
        //ExtentLogger.pass("Credit card saved", true);
        // clickElement(getElementByXpath("ClickOnClose"));
        //Thread.sleep(3000);
        return this;

    }

    public BillingPage clickOngenrate() throws InterruptedException, IOException {
        // driver.switchTo().defaultContent();
        waitTillElemenetVisible("Generate");

        driver.navigate().refresh();
        waitForPageLoad();
        waitTillElemenetVisible("Generate");
        ExtentLogger.pass("Clicking on Generate", true);

        return this;

    }

    String cardnumber = "";

    public BillingPage CreditCardNumber() throws InterruptedException, IOException {
        waitTillElemenetVisible("Title");
        cardnumber = getElementTextbyElement(getElementByXpath("VisaNumber"));
        //cardnumber="4539537616480367";
        //wrong credit card cardnumber="4929007121332188";
        cardnumber = cardnumber.trim();
        System.out.println("Card number is " + cardnumber);
        ExtentLogger.pass("Got the credit card number " + cardnumber, true);
        //driver.close();
        Thread.sleep(2000);
        return this;
    }

    public BillingPage switchToWindow(int n) throws InterruptedException, IOException {
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(n));
        ExtentLogger.pass("Switching the window", true);
        return this;
    }

    public BillingPage openURL(String url) throws InterruptedException, IOException {


        driver.get(url);
        ExtentLogger.pass("opening the url", true);
        return this;
    }

    String lastFourDigit = "";

    public BillingPage closeButton() throws InterruptedException, IOException {
        int i = 1;
        while (i < 4) {
            try {
                waitUntilVisible("CloseButton", "xpath", 60);
                if (isElementDisplayed(getElementByXpath("CloseButton"))) {
                    boolean res = isElementDisplayed(getElementByXpath("CreditCardSave"));
                    Assert.assertTrue(res);
                    String cardSavedMessage = getElementText(getElementByXpath("CreditCardSaveNumber"));
                    lastFourDigit = cardnumber;
                    lastFourDigit = lastFourDigit.substring(lastFourDigit.length() - 4);
                    System.out.println("Last 4 digit number is " + lastFourDigit);
                    Boolean b = cardSavedMessage.contains("Your credit card ending in " + lastFourDigit + " has been saved.");
                    Assert.assertTrue(b);
                    ExtentLogger.pass("Pop up is visible with correct message and last 4 digit " + lastFourDigit, true);
                    clickElement(getElementByXpath("CloseButton"));
                    ExtentLogger.pass("Clicking on close button", true);
                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
               /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber().clickOnAdd();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 4) {
            ExtentLogger.pass("Could not add credit card!!", true);
            Assert.assertTrue(false);
        }
        return this;
    }


    public BillingPage closeButtonUKI() throws InterruptedException, IOException {
        int i = 1;
        while (i < 4) {
            try {
                Thread.sleep(7000);
                driver.switchTo().defaultContent();
                driver.switchTo().frame("creditCardIframe");
                System.out.println("1st frame");
                driver.switchTo().frame("redirectTo3ds1Frame");
                System.out.println("2nd frame");
                Thread.sleep(3000);
                ExtentLogger.pass("Clicking on the pop up", true);
                driver.findElement(By.xpath("//input[@value='Submit']")).click();
                driver.switchTo().defaultContent();
                waitUntilVisible("CloseButton", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CloseButton"))) {
                    boolean res = isElementDisplayed(getElementByXpath("CreditCardSave"));
                    Assert.assertTrue(res);
                    String cardSavedMessage = getElementText(getElementByXpath("CreditCardSaveNumber"));
                    lastFourDigit = cardnumber;
                    lastFourDigit = lastFourDigit.substring(lastFourDigit.length() - 4);
                    System.out.println("Last 4 digit number is " + lastFourDigit);
                    Boolean b = cardSavedMessage.contains("Your credit card ending in " + lastFourDigit + " has been saved.");
                    Assert.assertTrue(b);
                    ExtentLogger.pass("Pop up is visible with correct message and last 4 digit " + lastFourDigit, true);
                    clickElement(getElementByXpath("CloseButton"));
                    ExtentLogger.pass("Clicking on close button", true);
                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
              /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber().clickOnAdd();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 4) {
            ExtentLogger.pass("Could not add credit card!!", true);
            Assert.assertTrue(false);
        }
        return this;
    }


    public BillingPage openNewTab() throws InterruptedException, IOException {

        ((JavascriptExecutor) driver).executeScript("window.open()");
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        ExtentLogger.pass("Opening and switching to new tab", true);
        return this;
    }

    public BillingPage validateCCLast4Digit() throws InterruptedException, IOException {

        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(1000);
        String last4Digit = driver.findElement(By.xpath("(//p/strong)[3]")).getText();
        System.out.println(last4Digit);
        String actualLast4digit = "9222";
        Assert.assertEquals(actualLast4digit, last4Digit);
        System.out.println("Credit card last digit validation successful");
        return this;

    }

    public BillingPage generateCreditCardNumber() throws InterruptedException, IOException {
        driver.get("https://cardguru.io/");
        waitTillElemenetVisible("GenerateCreditCardNumber");
        clickElement(getElementByXpath("GenerateCreditCardNumber"));
        Thread.sleep(1000);

        return this;
    }

    public BillingPage validDateWarining() throws InterruptedException, IOException {
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        waitTillElemenetVisible("WrongExpiryDateWarning");
        boolean warning = isElementDisplayed(getElementByXpath("WrongExpiryDateWarning"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning for wrong Expiration date is visible", true);
        driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage validCardNumberWarning() throws InterruptedException, IOException {
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        waitTillElemenetVisible("EmptyCardWarning");
        boolean warning = isElementDisplayed(getElementByXpath("EmptyCardWarning"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning for empty credit card number is visible", true);
        driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage validDateWarningHeading() throws InterruptedException, IOException {
        waitTillElemenetVisible("WrongExpiryDateWarningHeading");
        boolean warning = isElementDisplayed(getElementByXpath("WrongExpiryDateWarningHeading"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning at the top for wrong Expiration date is visible", true);
        js.executeScript("window.scrollBy(0,-500)");
        //clickElement(getElementByXpath("CloseHeaderWarning"));
        Thread.sleep(1000);
        //driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage validCCAccountWarningHeading() throws InterruptedException, IOException {
        waitTillElemenetVisible("SameCCAccountWarningHeading");
        boolean warning = isElementDisplayed(getElementByXpath("SameCCAccountWarningHeading"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning at the top for same credit card in another account is visible", true);
        //clickElement(getElementByXpath("CloseHeaderWarning"));
        Thread.sleep(1000);
        //driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage validSameCCWarningHeading() throws InterruptedException, IOException {
        waitTillElemenetVisible("WrongSameCCWarningHeading");
        boolean warning = isElementDisplayed(getElementByXpath("WrongSameCCWarningHeading"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning at the top for Same CC is visible", true);
        //clickElement(getElementByXpath("CloseHeaderWarning"));
        WebElement ele=driver.findElement(By.xpath("//button[@aria-label='Close']/span"));
        js.executeScript("arguments[0].click();", ele);
        Thread.sleep(1000);
        //driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage validDateWarning() throws InterruptedException, IOException {
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        waitTillElemenetVisible("EmptyDateWarning");
        boolean warning = isElementDisplayed(getElementByXpath("EmptyDateWarning"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning for empty date is visible", true);
        driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage validNameWarning() throws InterruptedException, IOException {
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        waitTillElemenetVisible("EmptyNameWarning");
        boolean warning = isElementDisplayed(getElementByXpath("EmptyNameWarning"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning for empty name is visible", true);
        driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage validcodeWarning() throws InterruptedException, IOException {
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        waitTillElemenetVisible("EmptyCodeWarning");
        boolean warning = isElementDisplayed(getElementByXpath("EmptyCodeWarning"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning for empty Security code is visible", true);
        driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage verifyCardDetails(String month, String year) throws IOException, InterruptedException {
        waitTillElemenetVisible("VerifyCardName");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(5000);
       /* try{
        if (isElementDisplayed(getElementByXpath("AUtoPayEnabledbank"))){
            String value = getElementTextbyElement(getElementByXpath("VerifyCardName"));
            boolean res = value.contains(CardName);
            Assert.assertTrue(res);

            value = getElementTextbyElement(getElementByXpath("VerifyNumber"));
            res = value.contains(lastFourDigit);
            Assert.assertTrue(res);

            value = getElementTextbyElement(getElementByXpath("VerifyDate"));
            res = value.contains(month + "/" + year);
            Assert.assertTrue(res);
            ExtentLogger.pass("Details are verified and autopay is enabled for bank in this page", true);

        }
        }catch(NoSuchElementException e) {


            String value = getElementTextbyElement(getElementByXpath("VerifyCardName"));
            boolean res = value.contains(CardName);
            Assert.assertTrue(res);

            value = getElementTextbyElement(getElementByXpath("VerifyNumber"));
            res = value.contains(lastFourDigit);
            Assert.assertTrue(res);

            value = getElementTextbyElement(getElementByXpath("VerifyDate"));
            res = value.contains(month + "/" + year);
            Assert.assertTrue(res);
            ExtentLogger.pass("Details are verified", true);
        }*/
        List<WebElement> list = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int i = 1;
        boolean flag = false;
        for (WebElement ele : list) {
            String name = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name.equalsIgnoreCase(CardName) && expirationDate.contains(month + "/" + year)) {
                flag = true;
                ExtentLogger.pass("Card details are verified", true);
            }
            i++;
        }
        if (flag == true) {
            ExtentLogger.pass("Card details are found in Manage payment method screen", true);
        } else {
            ExtentLogger.pass("Card details are not found in Manage payment method screen", true);

            Assert.assertTrue(false);

        }
        return this;
    }

    public BillingPage clickOnBankAccount() throws InterruptedException, IOException {
        waitForPageLoad();
        //Thread.sleep(10000);
        //driver.navigate().refresh();
        driver.switchTo().frame(driver.findElement(By.xpath("//div[@class='tr-ManagePaymentAddDialog-dialogContent']")));
        waitTillElemenetVisibleByxpath("Bank-account");
        clickElement(getElementByXpath("Bank-account"));
        System.out.println("Bank Account is clicked successfully");
        ExtentLogger.pass("Clicking Bank Account", true);
        return this;
    }

    String description1 = fake.regexify("[1-9]{9}");
    String RountingNumDuplicate = "";

    public BillingPage RountingNumber() throws InterruptedException, IOException {
        waitForPageLoad();
        //waitUntilVisible("BankAccount", "xpath", 30);
        //driver.switchTo().frame(driver.findElement(By.cssSelector(".tr-ManagePaymentAddDialog-dialogContent")));

        waitTillElemenetVisible("RoutingNumber");
        clickElement(getElementByXpath("RoutingNumber"));
        sendKeysTotheElement("RoutingNumber", description1);
        System.out.println("RountingNum=" + description1);
        RountingNumDuplicate = description1;

        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }
    String descriptionCAN = fake.regexify("[1-9]{5}");
    String TransitNumDuplicateCAN = "";
    public BillingPage TransitNum_CAN() throws InterruptedException, IOException {
        waitForPageLoad();
        //waitUntilVisible("BankAccount", "xpath", 30);
        //driver.switchTo().frame(driver.findElement(By.cssSelector(".tr-ManagePaymentAddDialog-dialogContent")));

        waitTillElemenetVisible("TransitNum");
        clickElement(getElementByXpath("TransitNum"));
        sendKeysTotheElement("TransitNum", descriptionCAN);
        System.out.println("TransitNum=" + descriptionCAN);
        TransitNumDuplicateCAN = descriptionCAN;

        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    } String descriptionCAN1 = fake.regexify("[1-9]{3}");
    String InstitutionNumDuplicateCAN1 = "";
    public BillingPage Institution_CAN() throws InterruptedException, IOException {
        waitForPageLoad();

        waitTillElemenetVisible("InstitutionNum");
        clickElement(getElementByXpath("InstitutionNum"));
        sendKeysTotheElement("InstitutionNum", descriptionCAN1);
        System.out.println("InstitutionNum=" + descriptionCAN1);
        InstitutionNumDuplicateCAN1 = descriptionCAN1;

        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }

    String description2 = fake.regexify("[1-9]{11}");
    String lastFourDigitBanking = "";
    String AccNumDuplicate = "";

    public BillingPage AccountNumber() throws InterruptedException, IOException {
        waitForPageLoad();

        waitTillElemenetVisible("AccountNumber");
        clickElement(getElementByXpath("AccountNumber"));
        sendKeysTotheElement("AccountNumber", description2);
        System.out.println("AccountNum=" + description2);
        AccNumDuplicate = description2;
        lastFourDigitBanking = description2;
        lastFourDigitBanking = lastFourDigitBanking.substring(lastFourDigitBanking.length() - 4);
        System.out.println("Last 4 digit number is " + lastFourDigitBanking);

        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }

    public BillingPage closeButtonBank() throws InterruptedException, IOException {

        waitUntilVisible("CloseButton", "xpath", 45);
        if (isElementDisplayed(getElementByXpath("CloseButton"))) {
            boolean res = isElementDisplayed(getElementByXpath("BankAccountSaved"));
            Assert.assertTrue(res);
            String cardSavedMessage = getElementText(getElementByXpath("BankAccountSavedNumber"));
            lastFourDigitBanking = description2;
            lastFourDigitBanking = lastFourDigitBanking.substring(lastFourDigitBanking.length() - 4);
            System.out.println("Last 4 digit number is " + lastFourDigitBanking);
            Boolean b = cardSavedMessage.contains("Your bank account ending in " + lastFourDigitBanking + " has been saved.");
            Assert.assertTrue(b);
            ExtentLogger.pass("Pop up is visible with correct message and last 4 digit " + lastFourDigitBanking, true);
            clickElement(getElementByXpath("CloseButton"));
            ExtentLogger.pass("Clicking on close button", true);

        }


        return this;
    }
    public BillingPage clickonNextforsetupautopay_USL_Prod() throws InterruptedException, IOException {


        ExtentLogger.pass("Autopay details entered", true);
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(3000);
        waitUntilVisible("ClickOnNext", "xpath", 30);
        clickElement(getElementByXpath("ClickOnNext"));
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        waitUntilVisible("CheckTnC", "xpath", 45);

        clickElement(getElementByXpath("CheckTnC"));
        ExtentLogger.pass("Agree terms and conditions", true);
        Thread.sleep(1000);
        waitUntilVisible("Confirm", "xpath", 45);

        return this;
    }

    public BillingPage RountingNumberDuplicate(BankingPage RountingNumber) throws InterruptedException, IOException {
        waitForPageLoad();
        //waitUntilVisible("BankAccount", "xpath", 30);
        //driver.switchTo().frame(driver.findElement(By.cssSelector(".tr-ManagePaymentAddDialog-dialogContent")));

        waitTillElemenetVisible("RoutingNumber");
        clickElement(getElementByXpath("RoutingNumber"));
        sendKeysTotheElement("RoutingNumber", RountingNumber.description1);

        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }



    public BillingPage AccountNumberDuplicate(BankingPage AccountNumber) throws InterruptedException, IOException {
        waitForPageLoad();

        waitTillElemenetVisible("AccountNumber");
        clickElement(getElementByXpath("AccountNumber"));
        sendKeysTotheElement("AccountNumber", AccountNumber.description2);
        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }

    public BillingPage validDateWarningHeadingBanking() throws InterruptedException, IOException {
        waitTillElemenetVisible("WrongExpiryDateWarningHeadingBank");
        boolean warning = isElementDisplayed(getElementByXpath("WrongExpiryDateWarningHeadingBank"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning at the top for wrong Expiration date is visible", true);
        //System.out.println(driver.findElement(By.xpath("WrongExpiryDateWarningHeadingBank")).getText());
        String warnigmsg = getElementText("WrongExpiryDateWarningHeadingBank");
        System.out.println(warning);
        boolean warningbanking = warnigmsg.contains("That bank account is already saved. Try a new payment method.");
        Assert.assertTrue(warningbanking);
        ExtentLogger.pass("Pop up is visible with correct message", true);
        Thread.sleep(1000);
        //driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage deleteCardDetails(String month, String year) throws IOException, InterruptedException {
        waitTillElemenetVisible("VerifyCardName");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int i = 1;
        boolean flag = false;
        for (WebElement ele : list) {
            String name = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name.equalsIgnoreCase(CardName) && expirationDate.contains(month + "/" + year)) {
                flag = true;
                ExtentLogger.pass("Card details are verified", true);
                driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-SavedPaymentMethod-tileBodyWrapper']//button[text()='Delete']")).click();
                waitTillElemenetVisible("DeleteButtonConfirmation");
                clickElement(getElementByXpath("DeleteButtonConfirmation"));
                waitTillElemenetVisible("CreditCardRemovedMessage");
                String value = getElementTextbyElement(getElementByXpath("CreditCardRemovedMessage"));
                boolean res = value.contains("Credit card removed");
                Assert.assertTrue(res);

                value = getElementTextbyElement(getElementByXpath("CreditCardRemovedNumberMessage"));
                res = value.contains("Your credit card ending in " + lastFourDigit + " has been removed.");
                Assert.assertTrue(res);

                clickElement(getElementByXpath("CloseButton"));
                Thread.sleep(3000);


                flag = true;
                break;

            }
            i++;
        }
        if (flag == true) {
            ExtentLogger.pass("Clicked on credit card delete button successfully", true);
        } else {
            ExtentLogger.pass("Clicked on credit card delete button failed", true);
            Assert.assertTrue(false);

        }
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int j = 1;
        boolean creditCardDeletionflag = true;
        if (list1.size() == 0) {
            ExtentLogger.pass("Card is deleted successfully", true);
            creditCardDeletionflag = true;
        }
        for (WebElement ele1 : list1) {
            String name1 = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + j + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate1 = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + j + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name1.contains(CardName) && expirationDate1.contains(month + "/" + year)) {
                ExtentLogger.pass("Credit card is not deleted", true);
                creditCardDeletionflag = false;
                break;
            }
            j++;
        }

        if (creditCardDeletionflag = true) {
            ExtentLogger.pass("Credit card deleted successfully", true);
        } else {
            ExtentLogger.pass("Credit card deletion failed", true);
            Assert.assertTrue(false);

        }


        return this;
    }

    public BillingPage updateCreditCardDetails(String month, String year, String newmonth, String newyear) throws IOException, InterruptedException {

        waitTillElemenetVisible("VerifyCardName");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int i = 1;
        boolean flag = false;
        for (WebElement ele : list) {
            String name = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name.equalsIgnoreCase(CardName) && expirationDate.contains(month + "/" + year)) {
                flag = true;
                ExtentLogger.pass("Card details are verified", true);
                driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-SavedPaymentMethod-tileBodyWrapper']//button[text()='Update']")).click();
                waitTillElemenetVisible("UpdateCardPopUp");
                Thread.sleep(3000);
                enterNameOnCard();
                SelectMonthAndYear(newmonth, newyear);
                enterSecurityCode();
                ExtentLogger.pass("Updating the card details", true);
                clickElement(getElementByXpath("UpdateCardPopUp"));

                waitTillElemenetVisible("CreditCardUpdatedMessage");
                String value = getElementTextbyElement(getElementByXpath("CreditCardUpdatedMessage"));
                boolean res = value.contains("Credit card updated");
                Assert.assertTrue(res);

                value = getElementTextbyElement(getElementByXpath("CreditCardRemovedNumberMessage"));
                res = value.contains("Your credit card ending in " + lastFourDigit + " has been updated.");
                Assert.assertTrue(res);

                clickElement(getElementByXpath("CloseButton"));
                Thread.sleep(3000);


                flag = true;
                break;

            }
            i++;
        }
        if (flag == true) {
            ExtentLogger.pass("Clicked on credit card update button successfully", true);
        } else {
            ExtentLogger.pass("Clicked on credit card update button failed", true);
            Assert.assertTrue(false);

        }
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int j = 1;
        boolean creditCardUpdationflag = false;
        if (list1.size() == 0) {
            ExtentLogger.pass("Card is not updated", true);
            creditCardUpdationflag = false;
        }
        for (WebElement ele1 : list1) {
            String name1 = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + j + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate1 = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + j + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name1.contains(CardName) && expirationDate1.contains(newmonth + "/" + newyear)) {
                ExtentLogger.pass("Credit card is updated", true);
                creditCardUpdationflag = true;
                break;
            }
            j++;
        }

        if (creditCardUpdationflag = true) {
            ExtentLogger.pass("Credit card updated successfully", true);
        } else {
            ExtentLogger.pass("Credit card not updated", true);
            Assert.assertTrue(false);

        }


        return this;
    }


    public BillingPage updateCreditCardDetailsnew(String month, String year, String newmonth, String newyear) throws IOException, InterruptedException {

        waitTillElemenetVisible("VerifyCardName");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int i = 1;
        boolean flag = false;
        for (WebElement ele : list) {
            String name = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name.equalsIgnoreCase(CardName) && expirationDate.contains(month + "/" + year)) {
                flag = true;
                ExtentLogger.pass("Card details are verified", true);
                driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-SavedPaymentMethod-tileBodyWrapper']//button[text()='Update']")).click();
                waitTillElemenetVisible("UpdateCardPopUp");
                Thread.sleep(3000);
                enterNameOnCard();
                SelectMonthAndYear(newmonth, newyear);
                enterSecurityCode();
                ExtentLogger.pass("Updating the card details", true);
                clickElement(getElementByXpath("UpdateCardPopUp"));
                Thread.sleep(9000);


                driver.switchTo().defaultContent();
                driver.switchTo().frame("creditCardIframe");
                System.out.println("1st frame");
                driver.switchTo().frame("redirectTo3ds1Frame");
                System.out.println("2nd frame");
                Thread.sleep(3000);
                ExtentLogger.pass("Clicking on the pop up", true);
                driver.findElement(By.xpath("//input[@value='Submit']")).click();
                Thread.sleep(5000);
                driver.switchTo().defaultContent();



                waitTillElemenetVisible("CreditCardUpdatedMessage");
                String value = getElementTextbyElement(getElementByXpath("CreditCardUpdatedMessage"));
                boolean res = value.contains("Credit card updated");
                Assert.assertTrue(res);

                value = getElementTextbyElement(getElementByXpath("CreditCardRemovedNumberMessage"));
                res = value.contains("Your credit card ending in " + lastFourDigit + " has been updated.");
                Assert.assertTrue(res);

                clickElement(getElementByXpath("CloseButton"));
                Thread.sleep(3000);


                flag = true;
                break;

            }
            i++;
        }
        if (flag == true) {
            ExtentLogger.pass("Clicked on credit card update button successfully", true);
        } else {
            ExtentLogger.pass("Clicked on credit card update button failed", true);
            Assert.assertTrue(false);

        }
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int j = 1;
        boolean creditCardUpdationflag = false;
        if (list1.size() == 0) {
            ExtentLogger.pass("Card is not updated", true);
            creditCardUpdationflag = false;
        }
        for (WebElement ele1 : list1) {
            String name1 = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + j + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate1 = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + j + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name1.contains(CardName) && expirationDate1.contains(newmonth + "/" + newyear)) {
                ExtentLogger.pass("Credit card is updated", true);
                creditCardUpdationflag = true;
                break;
            }
            j++;
        }

        if (creditCardUpdationflag = true) {
            ExtentLogger.pass("Credit card updated successfully", true);
        } else {
            ExtentLogger.pass("Credit card not updated", true);
            Assert.assertTrue(false);

        }


        return this;
    }


    public BillingPage updateCreditCardDetailsAutopay(String month, String year, String newmonth, String newyear) throws IOException, InterruptedException {

        waitTillElemenetVisible("VerifyCardName");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int i = 1;
        boolean flag = false;
        for (WebElement ele : list) {
            String name = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name.equalsIgnoreCase(CardName) && expirationDate.contains(month + "/" + year)) {
                flag = true;
                ExtentLogger.pass("Card details are verified", true);
                driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-SavedPaymentMethod-tileBodyWrapper']//button[text()='Update']")).click();
                waitTillElemenetVisible("UpdateCardPopUp");
                Thread.sleep(3000);
                enterNameOnCard();
                SelectMonthAndYear(newmonth, newyear);
                enterSecurityCode();
                ExtentLogger.pass("Updating the card details", true);
                clickElement(getElementByXpath("UpdateCardPopUp"));

                waitTillElemenetVisible("CreditCardUpdatedMessage");
                String value = getElementTextbyElement(getElementByXpath("CreditCardUpdatedMessage"));
                boolean res = value.contains("Credit card updated");
                Assert.assertTrue(res);

                value = getElementTextbyElement(getElementByXpath("CreditCardRemovedNumberMessage"));
                res = value.contains("Your credit card ending in " + lastFourDigit + " has been updated.");
                Assert.assertTrue(res);

                clickElement(getElementByXpath("CloseButton"));
                Thread.sleep(3000);


                flag = true;
                break;

            }
            i++;
        }
        if (flag == true) {
            ExtentLogger.pass("Clicked on credit card update button successfully", true);
        } else {
            ExtentLogger.pass("Clicked on credit card update button failed", true);
            Assert.assertTrue(false);

        }
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int j = 1;
        boolean creditCardUpdationflag = false;
        if (list1.size() == 0) {
            ExtentLogger.pass("Card is not updated", true);
            creditCardUpdationflag = false;
        }
        for (WebElement ele1 : list1) {
            String name1 = driver.findElement(By.xpath("//div[text()='Autopay enabled']/ancestor::div[@class='tr-FlexGrid-row']/parent::div/following-sibling::div//div[@class='tr-FlexGrid-row']//*[text()='" + lastFourDigit + "'][" + j + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate1 = driver.findElement(By.xpath("//div[text()='Autopay enabled']/ancestor::div[@class='tr-FlexGrid-row']/parent::div/following-sibling::div//div[@class='tr-FlexGrid-row']//*[text()='" + lastFourDigit + "'][" + j + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name1.contains(CardName) && expirationDate1.contains(newmonth + "/" + newyear)) {
                ExtentLogger.pass("Credit card is updated", true);
                creditCardUpdationflag = true;
                break;
            }
            j++;
        }

        if (creditCardUpdationflag = true) {
            ExtentLogger.pass("Credit card updated successfully", true);
        } else {
            ExtentLogger.pass("Credit card not updated", true);
            Assert.assertTrue(false);

        }


        return this;
    }

    public BillingPage updateCreditCardDetailsAutopayExisting(String month, String year, String newmonth, String newyear) throws IOException, InterruptedException {

        waitTillElemenetVisible("VerifyCardName");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int i = 1;
        boolean flag = false;
        for (WebElement ele : list) {
            String name = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name.equalsIgnoreCase(CardName) && expirationDate.contains(month + "/" + year)) {
                flag = true;
                ExtentLogger.pass("Card details are verified", true);
                driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])[" + i + "]/ancestor::div[@class='tr-SavedPaymentMethod-tileBodyWrapper']//button[text()='Update']")).click();
                waitTillElemenetVisible("UpdateCardPopUp");
                Thread.sleep(3000);
                enterNameOnCard();
                SelectMonthAndYear(newmonth, newyear);
                enterSecurityCode();
                ExtentLogger.pass("Updating the card details", true);
                clickElement(getElementByXpath("UpdateCardPopUp"));


                Thread.sleep(7000);
                driver.switchTo().defaultContent();
                driver.switchTo().frame("creditCardIframe");
                System.out.println("1st frame");
                driver.switchTo().frame("redirectTo3ds1Frame");
                System.out.println("2nd frame");
                Thread.sleep(3000);
                ExtentLogger.pass("Clicking on the pop up", true);
                driver.findElement(By.xpath("//input[@value='Submit']")).click();
                Thread.sleep(3000);
                driver.switchTo().defaultContent();


                waitTillElemenetVisible("CreditCardUpdatedMessage");
                String value = getElementTextbyElement(getElementByXpath("CreditCardUpdatedMessage"));
                boolean res = value.contains("Credit card updated");
                Assert.assertTrue(res);

                value = getElementTextbyElement(getElementByXpath("CreditCardRemovedNumberMessage"));
                res = value.contains("Your credit card ending in " + lastFourDigit + " has been updated.");
                Assert.assertTrue(res);

                clickElement(getElementByXpath("CloseButton"));
                Thread.sleep(3000);


                flag = true;
                break;

            }
            i++;
        }
        if (flag == true) {
            ExtentLogger.pass("Clicked on credit card update button successfully", true);
        } else {
            ExtentLogger.pass("Clicked on credit card update button failed", true);
            Assert.assertTrue(false);

        }
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));

        System.out.println("size is " + list.size());
        int j = 1;
        boolean creditCardUpdationflag = false;
        if (list1.size() == 0) {
            ExtentLogger.pass("Card is not updated", true);
            creditCardUpdationflag = false;
        }
        for (WebElement ele1 : list1) {
            String name1 = driver.findElement(By.xpath("//div[text()='Autopay enabled']/ancestor::div[@class='tr-FlexGrid-row']/parent::div/following-sibling::div//div[@class='tr-FlexGrid-row']//*[text()='" + lastFourDigit + "'][" + j + "]/ancestor::div[@class='tr-FlexGrid-row']/preceding-sibling::div//span/p/strong")).getText();
            String expirationDate1 = driver.findElement(By.xpath("//div[text()='Autopay enabled']/ancestor::div[@class='tr-FlexGrid-row']/parent::div/following-sibling::div//div[@class='tr-FlexGrid-row']//*[text()='" + lastFourDigit + "'][" + j + "]/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();

            if (name1.contains(CardName) && expirationDate1.contains(newmonth + "/" + newyear)) {
                ExtentLogger.pass("Credit card is updated", true);
                creditCardUpdationflag = true;
                break;
            }
            j++;
        }

        if (creditCardUpdationflag = true) {
            ExtentLogger.pass("Credit card updated successfully", true);
        } else {
            ExtentLogger.pass("Credit card not updated", true);
            Assert.assertTrue(false);

        }


        return this;
    }

    public BillingPage verifyAccountNum() throws IOException, InterruptedException {
       /* waitTillElemenetVisible("VerifyAccountNum");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(5000);
      // String obtain= getElementText((WebElement) driver.findElements(By.xpath("//span[@id='id-0']//strong[contains(text(),='"+lastFourDigitBanking+"']")));
        //String obtain = getElementText("VerifyAccountNum");
        //String achulval= lastFourDigitBanking;
        //System.out.println("size is "+list.size());

            //Assert.assertEquals(achulval,obtain);
         isElementDisplayed(getElementByXpath("VerifyAccountNum"));
            String value = getElementTextbyElement(getElementByXpath("VerifyAccountNum"));
            boolean res  = value.contains(lastFourDigitBanking);
            Assert.assertTrue(res);
        System.out.println(value);
        System.out.println(lastFourDigitBanking);*/

        waitTillElemenetVisible("VerifyCardName");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        String actual = driver.findElement(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong[text()='" + lastFourDigitBanking + "']")).getText();
        Assert.assertEquals(actual, lastFourDigitBanking);
        ExtentLogger.pass("Bank details are verified", true);
        System.out.println(lastFourDigitBanking);


        //  ExtentLogger.pass("Account details are found in Manage payment method screen", true);
      /* if (Assert.assertTrue();
            ExtentLogger.pass("Card details are not found in Manage payment method screen",true);

            Assert.assertTrue(false);*/


        return this;
    }

    public BillingPage ManageAutoPay() throws InterruptedException, IOException {
        waitForPageLoad();

        //Thread.sleep(10000);
        driver.navigate().refresh();
        //  js.executeScript("window.scrollBy(0,-700)");
        //driver.switchTo().frame(driver.findElement(By.xpath("//div[@class='tr-ManagePaymentAddDialog-dialogContent']")));
        // isElementDisplayed(getElementByXpath("Billing")))
        waitForPageLoad();
        waitTillElemenetVisible("ManageAutoPay1");
       /* Thread.sleep(1000);
        String actual=driver.findElement(By.xpath("//strong[normalize-space()='Bank account ending in "+lastFourDigitBanking+"]")).getText();
        Assert.assertEquals(actual,lastFourDigitBanking);
        ExtentLogger.pass("Bank details are verified",true);
        System.out.println(lastFourDigitBanking);*/
        clickElement(getElementByXpath("ManageAutoPay1"));
        System.out.println("Manage autopay is clicked successfully!!");
        ExtentLogger.pass("Clicking on manage AutoPay", true);
        Thread.sleep(1000);
        waitTillElemenetVisible("TurnOffAutoPay");
        //clickOnElement(String.valueOf(getElementByXpath("TurnOffAutoPay")));
        clickElement(getElementByXpath("TurnOffAutoPay"));
        Reason_Autopay();
        verifyAutopayOFF();


        /*waitTillElemenetVisible("TurnOff");
        clickElement(getElementByXpath("TurnOff"));
        System.out.println("ManageAutoPay is clicked successfully");
        ExtentLogger.pass("Clicking ManageAutoPay", true);*/


        return this;
    }

    public BillingPage AutoPay() throws InterruptedException, IOException {
        waitForPageLoad();
        //waitTillElemenetVisibleByxpath("Billing");
        js.executeScript("window.scrollBy(0,400)");
        Thread.sleep(5000);
        clickElement(getElementByXpath("SetUpAutoPay"));
        System.out.println("SetAutoPay is clicked successfully");
        ExtentLogger.pass("Clicking AutoPay", true);


        return this;
    }
    public BillingPage Reason_Autopay() throws InterruptedException, IOException {
        waitForPageLoad();
        Thread.sleep(7000);
       // waitTillElemenetVisibleByxpath("ReasonAutopay");
       String Reason= driver.findElement(By.xpath("//strong[normalize-space()='Reason for turning off autopay']")).getText();
       System.out.println(Reason);
        clickElement(getElementByXpath("MyPayment"));
        System.out.println("MyPayment is clicked successfully");
        clickElement(getElementByXpath("Experiencing"));
        System.out.println("Experiecing is clicked successfully");
        clickElement(getElementByXpath("NoLonger"));
        System.out.println("Nolonger is clicked successfully");
        ExtentLogger.pass("Clicking on all the checkbox for turnoff autopay", true);
       // Thread.sleep(3000);
       // js.executeScript("window.scrollBy(0,300)");
       // waitTillElemenetVisible("OtherReason");
       // clickElement(getElementByXpath("OtherReason"));
        WebElement element = driver.findElement(By.xpath("//label[@for='Other reason']/div"));
        //JavascriptExecutor executor = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].click();", element);
        System.out.println("OtherReason is clicked successfully");
        ExtentLogger.pass("Clicking on other checkbox for turnoff autopay", true);
        //Thread.sleep(3000);
        waitTillElemenetVisible("Commentbox");
        //clickElement(getElementByXpath("Commentbox"));
        sendKeysTotheElement("Commentbox","text");
        ExtentLogger.pass("Sending text to comment box for turnoff autopay", true);
        System.out.println("textbox is clicked successfully");
        ExtentLogger.pass("Clicking AutoPay", true);
        waitTillElemenetVisible("NextTurnOffAutopay");
       // driver.findElement(By.xpath("//span[normalize-space()='Next']")).click();
        clickElement(getElementByXpath("NextTurnOffAutopay"));
        System.out.println("Next button is clicked successfully");
        ExtentLogger.pass("Clicking on next button for turnoff autopay", true);
        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(1000);
        waitTillElemenetVisible("TurnOFFAutopay");
        clickElement(getElementByXpath("TurnOFFAutopay"));
        ExtentLogger.pass("Clicking on turnoff autopay button", true);


        return this;
    }

    public BillingPage AddNewBankAcc() throws InterruptedException, IOException {
        waitForPageLoad();
        js.executeScript("window.scrollBy(0,400)");
        Thread.sleep(3000);
        Select drpCountry = new Select(driver.findElement(By.xpath("//select[@id='payment-method-select']")));
        drpCountry.selectByVisibleText("Add new payment method");
        clickElement(getElementByXpath("Next"));
        ExtentLogger.pass("Add new payment", true);
        return this;
    }

    public BillingPage NextButton() throws InterruptedException, IOException {
        waitForPageLoad();
        // waitTillElemenetVisibleByxpath("BackToBilling");
        clickElement(getElementByXpath("Next"));
        return this;
    }

    public BillingPage CheckBox() throws InterruptedException, IOException {
        waitForPageLoad();
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        Thread.sleep(2000);
        clickElement(getElementByXpath("CheckBox"));
        Thread.sleep(2000);
        //waitTillElemenetVisibleByxpath("Confirm");
        clickElement(getElementByXpath("Confirm"));
        ExtentLogger.pass("Clicking AutoPay confirm", true);
        return this;
    }

    public BillingPage BackToBilling() throws InterruptedException, IOException {
        waitForPageLoad();
        Thread.sleep(6000);
        waitTillElemenetVisibleByxpath("BackToBilling");
        //getElementText("Thanksforsettingupautopay");
        Thread.sleep(3000);
        clickElement(getElementByXpath("BackToBilling"));

        // Thread.sleep(2000);
        //waitTillElemenetVisibleByxpath("Confirm");
        // clickElement(getElementByXpath("Confirm"));
        return this;

    }

    public BillingPage deleteBankDetails() throws IOException, InterruptedException {
        waitTillElemenetVisible("VerifyCardName");
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        String actual = driver.findElement(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong[text()='" + lastFourDigitBanking + "']")).getText();
        Assert.assertEquals(actual, lastFourDigitBanking);
        ExtentLogger.pass("Bank details are verified", true);
        System.out.println(lastFourDigitBanking);
/*
        List<WebElement> list=driver.findElements(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong"));
        System.out.println(list.size());
        for(int i=1;i<=list.size();i++)
        {
            String last4Digit = driver.findElements(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong")).get(i).getText();
            System.out.println(last4Digit);
            if(last4Digit.equalsIgnoreCase(lastFourDigitBanking))
            {
                WebElement delete  = driver.findElements(By.xpath("//button[text()='Delete']")).get(i);
                clickElement(delete);
                break;
            }
        }
*/
        driver.findElement(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong[text()='" + lastFourDigitBanking + "']/ancestor::div[@class='tr-SavedPaymentMethod-tileBodyWrapper']//button[text()='Delete']")).click();
        Thread.sleep(2000);
        ExtentLogger.pass("Click on delete button of Bank ending with " + lastFourDigitBanking, true);
        waitTillElemenetVisible("DeleteButtonConfirmation");
        clickElement(getElementByXpath("DeleteButtonConfirmation"));

        waitTillElemenetVisible("BankAccountRemovedMessage");
        String value = getElementTextbyElement(getElementByXpath("BankAccountRemovedMessage"));
        boolean res = value.contains("Bank account removed");
        Assert.assertTrue(res);
        boolean flag = false;
        value = getElementTextbyElement(getElementByXpath("BankAccountNumberRemovedMessage"));
        res = value.contains("Your bank account ending in " + lastFourDigitBanking + " has been removed.");
        Assert.assertTrue(res);
        Thread.sleep(2000);
        ExtentLogger.pass("Pop up validation of Bank account deleted successfully", true);
        clickElement(getElementByXpath("CloseButton"));
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(1000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong[text()='" + lastFourDigitBanking + "']"));
        if (list1.size() == 0) {
            ExtentLogger.pass("Bank Account number deleted successfully", true);
        } else {
            ExtentLogger.pass("Bank Account number deletion failed and bank account number still exist in the account", true);
            Assert.assertTrue(false);
        }

        return this;

    }

    public BillingPage SetUpAutoPayVisible() throws InterruptedException, IOException {

        driver.navigate().refresh();
        waitForPageLoad();
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(3000);
        waitUntilVisible("SetUpAutoPay", "xpath", 30);
        boolean a = isElementDisplayed(getElementByXpath("SetUpAutoPay"));
        Assert.assertTrue(a);
        System.out.println("SetUp AutoPay is visible successfully!!");
        ExtentLogger.pass("SetUP AutoPay is visible", true);
        Thread.sleep(1000);
        return this;
    }

    public BillingPage clickOnSetUpAutoPay() throws InterruptedException, IOException {
        Thread.sleep(3000);
        try {
            waitUntilVisible("AutoPayButton", "xpath", 30);
            clickElement(getElementByXpath("AutoPayButton"));
            System.out.println("AutoPay is clicked successfully!!");
            ExtentLogger.pass("Clicking on AutoPay", true);
            Thread.sleep(1000);
        } catch (TimeoutException e) {
            try{ clickElement(getElementByXpath("TurnOnAutopay"));
                System.out.println("Manage autopay is clicked successfully!!");
                ExtentLogger.pass("Clicking on manage AutoPay", true);
                Thread.sleep(1000);

            }catch (NoSuchElementException e1) {
                clickElement(getElementByXpath("ManageAutoPay"));
                System.out.println("Manage autopay is clicked successfully!!");
                ExtentLogger.pass("Clicking on manage AutoPay", true);
                Thread.sleep(1000);

                return this;
            }

            }

        return this;
    }

    public BillingPage clickOnSetUpAutoPayNew() throws InterruptedException, IOException {

try{
            waitUntilVisible("AutoPayButton", "xpath", 30);
            clickElement(getElementByXpath("AutoPayButton"));
            System.out.println("AutoPay is clicked successfully!!");
            ExtentLogger.pass("Clicking on AutoPay", true);
            Thread.sleep(1000);
} catch (TimeoutException e) {
    clickElement(getElementByXpath("ManageAutoPay"));
    System.out.println("Manage autopay is clicked successfully!!");
    ExtentLogger.pass("Clicking on manage AutoPay", true);
    Thread.sleep(1000);
}

return this;
    }

    public BillingPage clickOnSetUpAutoPayNewExisting() throws InterruptedException, IOException {
        waitForPageLoad();
        Thread.sleep(5000);
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Manage autopay")) {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
        }
        try{
            waitUntilVisible("AutoPayButton", "xpath", 15);
            clickElement(getElementByXpath("AutoPayButton"));
            System.out.println("AutoPay is clicked successfully!!");
            ExtentLogger.pass("Clicking on AutoPay", true);
            Thread.sleep(1000);
        } catch (TimeoutException e) {
            clickElement(getElementByXpath("ManageAutoPay"));
            System.out.println("Manage autopay is clicked successfully!!");
            ExtentLogger.pass("Clicking on manage AutoPay", true);
            Thread.sleep(1000);
        }

        return this;
    }

    public BillingPage SelectPaymentMethod(String paymentMethod) throws InterruptedException, IOException {
        waitUntilVisible("ChoosePaymentMethod", "xpath", 30);

        WebElement method = driver.findElement(By.xpath("//select[@id='payment-method-select']"));
        Select drp = new Select(method);
        drp.selectByVisibleText("Add new payment method");
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,500)");
        return this;
    }

    public BillingPage clickonNextforsetupautopay() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToBilling", "xpath", 80);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically on or after the invoice date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
               /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }
    public BillingPage clickonNextforsetupautopay_USL() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToBilling", "xpath", 80);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
               /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }public BillingPage clickonNextforsetupautopay_CAND() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToBilling", "xpath", 80);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically by the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));
                    ExtentLogger.pass("Clicking on Back to billing", true);


                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
               /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage clickonNextforsetupautopay_UKI() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToBilling", "xpath", 80);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }try {
                       driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();
                    }catch (NoSuchElementException e) {
                         driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically by the due date.') ]")).isDisplayed();
                    }
                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                   // Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
               /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }
    public BillingPage clickonNextforsetupautopay_CAN() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToBilling", "xpath", 80);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically by the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    String confirmationNumberInvoicePayment="";

    public BillingPage InvoicePaymentUKI() throws InterruptedException, IOException {
        ExtentLogger.pass("Details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext"));
        ExtentLogger.pass("Click on next", true);
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(7000);
                driver.switchTo().defaultContent();
                driver.switchTo().frame("creditCardIframe");
                System.out.println("1st frame");
                try{
                    driver.switchTo().frame("redirectTo3ds1Frame");
                }
                catch(NoSuchFrameException n){
                    driver.switchTo().frame("challengeFrame");
                }
                System.out.println("2nd frame");
                Thread.sleep(3000);
                ExtentLogger.pass("Clicking on the pop up", true);
                driver.findElement(By.xpath("//input[@value='Submit']")).click();
        ExtentLogger.pass("Click on Submit button of popup", true);
                Thread.sleep(3000);
                driver.switchTo().defaultContent();
                js.executeScript("window.scrollBy(0,1500)");
                Thread.sleep(3000);
        clickElement(getElementByXpath("PayButton"));
        ExtentLogger.pass("Click on Pay button", true);

        waitUntilVisible("PaymentConfirmationInvoice", "xpath", 45);
        confirmationNumberInvoicePayment=getElementText("confirmationNumberInvoicePayment");
        String text=getElementText("PaymentConfirmationInvoiceMessage");
        Assert.assertTrue(text.contains("A confirmation email is on its way to "));
        Assert.assertTrue(text.contains(". Remember, it may take up to 2 business days to process a payment."));
        ExtentLogger.pass("Payment confirmation messages are validated and confirmation number is "+confirmationNumberInvoicePayment, true);
        return  this;
    }
    public BillingPage InvoicePaymentUSL() throws InterruptedException, IOException {
        ExtentLogger.pass("Details entered", true);
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(3000);
        waitUntilVisible("ClickOnNext", "xpath", 30);
        clickElement(getElementByXpath("ClickOnNext"));
        ExtentLogger.pass("Click on next", true);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        clickElement(getElementByXpath("PayButton"));
        ExtentLogger.pass("Click on Pay button", true);

        waitUntilVisible("PaymentConfirmationInvoice", "xpath", 45);
        confirmationNumberInvoicePayment=getElementText("confirmationNumberInvoicePayment");
        String text=getElementText("PaymentConfirmationInvoiceMessage");
        Assert.assertTrue(text.contains("A confirmation email is on its way to "));
        Assert.assertTrue(text.contains(". Remember, it may take up to 2 business days to process a payment."));
        ExtentLogger.pass("Payment confirmation messages are validated and confirmation number is "+confirmationNumberInvoicePayment, true);
        return  this;
    }


    public BillingPage InvoicePaymentCAD() throws InterruptedException, IOException {
        ExtentLogger.pass("Details entered", true);
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(3000);
        waitUntilVisible("ClickOnNext", "xpath", 30);
        clickElement(getElementByXpath("ClickOnNext"));
        ExtentLogger.pass("Click on next", true);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(7000);
       /* driver.switchTo().defaultContent();
        driver.switchTo().frame("creditCardIframe");
        System.out.println("1st frame");
        try{
            driver.switchTo().frame("redirectTo3ds1Frame");
        }
        catch(NoSuchFrameException n){
            driver.switchTo().frame("challengeFrame");
        }
        System.out.println("2nd frame");
        Thread.sleep(3000);
        ExtentLogger.pass("Clicking on the pop up", true);
        driver.findElement(By.xpath("//input[@value='Submit']")).click();
        ExtentLogger.pass("Click on Submit button of popup", true);
        Thread.sleep(3000);
        driver.switchTo().defaultContent();
        js.executeScript("window.scrollBy(0,1500)");
        Thread.sleep(3000);*/
        clickElement(getElementByXpath("PayButton"));
        ExtentLogger.pass("Click on Pay button", true);

        waitUntilVisible("PaymentConfirmationInvoice", "xpath", 45);
        confirmationNumberInvoicePayment=getElementText("confirmationNumberInvoicePayment");
        String text=getElementText("PaymentConfirmationInvoiceMessage");
        Assert.assertTrue(text.contains("A confirmation email is on its way to "));
        Assert.assertTrue(text.contains(". Remember, it may take up to 2 business days to process a payment."));
        ExtentLogger.pass("Payment confirmation messages are validated and confirmation number is "+confirmationNumberInvoicePayment, true);
        return  this;
    }

    public BillingPage InvoicePaymentBankUKI() throws InterruptedException, IOException {
        ExtentLogger.pass("Details entered", true);
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(3000);
        waitUntilVisible("ClickOnNext", "xpath", 30);
        clickElement(getElementByXpath("ClickOnNext"));
        ExtentLogger.pass("Click on next", true);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(7000);
        clickElement(getElementByXpath("PayButton"));
        ExtentLogger.pass("Click on Pay button", true);

        waitUntilVisible("PaymentConfirmationInvoice", "xpath", 45);
        confirmationNumberInvoicePayment=getElementText("confirmationNumberInvoicePayment");
        String text=getElementText("PaymentConfirmationInvoiceMessage");
        Assert.assertTrue(text.contains("A confirmation email is on its way to "));
        Assert.assertTrue(text.contains(". Remember, it may take up to 2 business days to process a payment."));
        ExtentLogger.pass("Payment confirmation messages are validated and confirmation number is "+confirmationNumberInvoicePayment, true);
        return  this;
    }
    public BillingPage EnrollAutoPayPostInvoicePayment() throws InterruptedException, IOException {
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(2000);
        waitUntilVisible("EnrollAutoPayInvoicePayment", "xpath", 45);
        clickElement(getElementByXpath("EnrollAutoPayInvoicePayment"));
        ExtentLogger.pass("Click on Enroll now button", true);
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(2000);
        waitTillElemenetVisible("CheckTnC");
        clickElement(getElementByXpath("CheckTnC"));
        ExtentLogger.pass("Agree terms and conditions", true);
        Thread.sleep(1000);
        waitTillElemenetVisible("EnrollInAutopay");
        clickElement(getElementByXpath("EnrollInAutopay"));
        ExtentLogger.pass("Clicking on enroll in autopay button", true);
        waitTillElemenetVisible("SetupautopayMessage");
        boolean ConfirmationMessage1 = driver.findElement(By.xpath("//div//*[contains(text(),'Thank you for signing up for autopay') ]")).isDisplayed();
        Assert.assertTrue(ConfirmationMessage1);
        ConfirmationMessage1 = driver.findElement(By.xpath("//div//*[contains(text(),'Future invoices for enrolled products will be paid automatically on or after the invoice date using ') ]")).isDisplayed();
        Assert.assertTrue(ConfirmationMessage1);
        WebElement ele=driver.findElement(By.xpath("//div//*[contains(text(),'Future invoices for enrolled products will be paid automatically on or after the invoice date using ') ]/strong"));
        lastFourDigit = cardnumber;
        lastFourDigit = lastFourDigit.substring(lastFourDigit.length() - 4);
        String text=getElementTextbyElement(ele);
        ExtentLogger.pass("Confirmation message is present", true);
        Assert.assertTrue(text.contains(lastFourDigit));
        ExtentLogger.pass("Last 4 digit is present "+lastFourDigit, true);
        waitUntilVisible("BackToBilling", "xpath", 30);
        Thread.sleep(3000);
        clickElement(getElementByXpath("BackToBilling"));
        waitForPageLoad();


        return this;
    }

    public BillingPage EnrollAutoPayPostInvoicePaymentBank() throws InterruptedException, IOException {
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(20000);
        waitUntilVisible("EnrollAutoPayInvoicePayment", "xpath", 45);
        clickElement(getElementByXpath("EnrollAutoPayInvoicePayment"));
        ExtentLogger.pass("Click on Enroll now button", true);
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(2000);
        waitTillElemenetVisible("CheckTnC");
        clickElement(getElementByXpath("CheckTnC"));
        ExtentLogger.pass("Agree terms and conditions", true);
        Thread.sleep(1000);
        waitTillElemenetVisible("EnrollInAutopay");
        clickElement(getElementByXpath("EnrollInAutopay"));
        ExtentLogger.pass("Clicking on enroll in autopay button", true);
        waitTillElemenetVisible("SetupautopayMessage");
        boolean ConfirmationMessage1 = driver.findElement(By.xpath("//div//*[contains(text(),'Thank you for signing up for autopay') ]")).isDisplayed();
        Assert.assertTrue(ConfirmationMessage1);
        ConfirmationMessage1 = driver.findElement(By.xpath("//div//*[contains(text(),'Future invoices for enrolled products will be paid automatically on or after the invoice date using ') ]")).isDisplayed();
        Assert.assertTrue(ConfirmationMessage1);
        WebElement ele=driver.findElement(By.xpath("//div//*[contains(text(),'Future invoices for enrolled products will be paid automatically on or after the invoice date using ') ]/strong"));
        String text=getElementTextbyElement(ele);
        ExtentLogger.pass("Confirmation message is present", true);
        Assert.assertTrue(text.contains(lastFourDigitBanking));
        ExtentLogger.pass("Last 4 digit is present "+lastFourDigitBanking, true);
        waitUntilVisible("BackToBilling", "xpath", 30);
        Thread.sleep(3000);
        clickElement(getElementByXpath("BackToBilling"));
        waitForPageLoad();


        return this;
    }


    public BillingPage clickonNextforsetupautopayUKI() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(7000);
                driver.switchTo().defaultContent();
                driver.switchTo().frame("creditCardIframe");
                System.out.println("1st frame");
                driver.switchTo().frame("redirectTo3ds1Frame");
                System.out.println("2nd frame");
                Thread.sleep(3000);
                ExtentLogger.pass("Clicking on the pop up", true);
                driver.findElement(By.xpath("//input[@value='Submit']")).click();
                Thread.sleep(3000);
                driver.switchTo().defaultContent();
                js.executeScript("window.scrollBy(0,1500)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToBilling", "xpath", 80);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage clickonNextforsetupautopayUKIUnAuth() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext2", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext2"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(7000);
                driver.switchTo().defaultContent();
                driver.switchTo().frame("creditCardIframe");
                System.out.println("1st frame");
                driver.switchTo().frame("redirectTo3ds1Frame");
                System.out.println("2nd frame");
                Thread.sleep(3000);
                ExtentLogger.pass("Clicking on the pop up", true);
                driver.findElement(By.xpath("//input[@value='Submit']")).click();
                Thread.sleep(3000);
                driver.switchTo().defaultContent();
                js.executeScript("window.scrollBy(0,1500)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    ExtentLogger.pass("Clicking on confirm button", true);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(13000);
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();

                    } catch (NoSuchElementException e) {
                        System.out.println(e.getMessage());
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.fail();

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage clickonNextforsetupautopayUKIUnAuthbank() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext2", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext2"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(7000);
                js.executeScript("window.scrollBy(0,1500)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    ExtentLogger.pass("Clicking on confirm button", true);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(13000);
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();

                    } catch (NoSuchElementException e) {
                        System.out.println(e.getMessage());
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.fail();

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }


    public BillingPage clickonNextforsetupautopayUKIBank() throws InterruptedException, IOException {


                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                js.executeScript("window.scrollBy(0,1500)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);

                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToBilling", "xpath", 80);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
        Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));



        return this;

    }

    public BillingPage clickonNextforsetupautopayUKIExisting() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("ClickOnNext", "xpath", 30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,800)");
                Thread.sleep(2000);

                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToBilling", "xpath", 80);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }
    public BillingPage clickOnIagree() throws InterruptedException, IOException {
        Thread.sleep(4000);
        waitTillElemenetVisible("Iagreebutton");
        clickElement(getElementByXpath("Iagreebutton"));


        ExtentLogger.pass("Clicking on I agree button in T&C", true);
        return this;
    }


    public BillingPage verifyAutopayCCDetails() throws InterruptedException, IOException {
        waitForPageLoad();
        Thread.sleep(5000);
        String text = driver.findElement(By.xpath("//*[contains(text(),'Visa ending in')]")).getText();
        String actual = text.split("ending in")[1].trim();
        lastFourDigit = cardnumber;
        lastFourDigit = lastFourDigit.substring(lastFourDigit.length() - 4);
        System.out.println(lastFourDigit);
        ExtentLogger.pass("Last four digit is " + lastFourDigit, true);

        System.out.println(actual);
        if (actual.equalsIgnoreCase(lastFourDigit)) {
            ExtentLogger.pass("Autopay credit card details are verified", true);

        } else {
            ExtentLogger.pass("Autopay credit card details verification failed ", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage verifyAutopaybankDetails() throws InterruptedException, IOException {

        Thread.sleep(10000);
        String text = driver.findElement(By.xpath("//div//span[@id='id-0']")).getText();
        String actual = text.split("ending in")[1].trim();
        //lastFourDigit = cardnumber;
        //lastFourDigit = lastFourDigit.substring(lastFourDigit.length() - 4);
        System.out.println(lastFourDigitBanking);
        System.out.println(actual);
        if (actual.equalsIgnoreCase(lastFourDigitBanking)) {
            ExtentLogger.pass("Autopay Bank account details are verified", true);

        } else {
            ExtentLogger.pass("Autopay bank account details verification failed ", true);
            Assert.assertTrue(false);
        }


        return this;

    } public BillingPage verifyAutopaybankDetails_CAND() throws InterruptedException, IOException {

        Thread.sleep(10000);
        String text = driver.findElement(By.xpath("//span[@id='id-0']")).getText();
        String actual = text.split("ending in")[1].trim();
        //lastFourDigit = cardnumber;
        //lastFourDigit = lastFourDigit.substring(lastFourDigit.length() - 4);
        System.out.println(lastFourDigitBanking);
        System.out.println(actual);
        if (actual.equalsIgnoreCase(lastFourDigitBanking)) {
            ExtentLogger.pass("Autopay Bank account details are verified", true);

        } else {
            ExtentLogger.pass("Autopay bank account details verification failed ", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage verifyAutopayBankDetails() throws InterruptedException, IOException {

        Thread.sleep(3000);
        String text = driver.findElement(By.xpath("//*[contains(text(),'Bank account ending in')]")).getText();
        String actual = text.split("ending in")[1].trim();
        lastFourDigitBanking = description2;
        lastFourDigitBanking = lastFourDigitBanking.substring(lastFourDigitBanking.length() - 4);
        System.out.println(lastFourDigitBanking);
        System.out.println(actual);
        if (actual.equalsIgnoreCase(lastFourDigitBanking)) {
            ExtentLogger.pass("Autopay bank account details are verified", true);

        } else {
            ExtentLogger.pass("Autopay bank account details verification failed ", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage verifyAutopayEnabled() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledCardNumber"));
        Assert.assertEquals(actual, lastFourDigit);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }

    public BillingPage clickOnBillingTab() throws InterruptedException, IOException {
        ExtentLogger.pass("Clicked on Billing tab ", true);
        clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;
    }

    public BillingPage verifyAutopayEnabledExisting() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledCardNumber"));
        Assert.assertEquals(actual, ExistingCCFourDigit);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }

    public BillingPage verifyAutopayEnabledBank() throws InterruptedException, IOException {
      //  waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        //clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledBankNumber"));
        Assert.assertEquals(actual, lastFourDigitBanking);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }
    public BillingPage ManagePayment() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        return this;
    }
    public BillingPage verifyAutopayEnabledBank_CAND() throws InterruptedException, IOException {
       /*waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledBankNumber"));
        Assert.assertEquals(actual, lastFourDigitBanking);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);*/
        clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }

    public BillingPage verifyStatusOfInvoiceAsPaymentPending() throws InterruptedException, IOException {
        waitForPageLoad();
       // NoPaymentDue();
        Thread.sleep(4000);
        //String color = driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color");
        // System.out.println(color);
        boolean a = true;
        while (a) {
            List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
            int i = 1;
            for (WebElement e : list1) {
                if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                    System.out.println("Status is Payment pending");
                    ExtentLogger.pass("Status is Payment pending", true);

                } else {
                    System.out.println("Status is not Payment pending");
                    ExtentLogger.pass("Status is not Payment pending", true);
                    Assert.assertTrue(false);

                }

                i++;

            }
            try {
                 if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {   break;
                } else {
                    driver.findElement(By.xpath("//span[text()='Next']")).click();
                }
            } catch (NoSuchElementException e) {
                System.out.println("next button is not visible " + e.getMessage());
                break;
            }
        }
        return this;

    }

    public BillingPage verifyStatusOfInvoiceAsPaymentPendingAtleastOneUKI() throws InterruptedException, IOException {
        waitForPageLoad();
       // NoPaymentDue();
        Thread.sleep(4000);
        int count=0;
        //String color = driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color");
        // System.out.println(color);
        boolean a = true;
        while (a) {
            List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
            int i = 1;
            for (WebElement e : list1) {
                if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                    System.out.println("Status is Payment pending");
                    ExtentLogger.pass("Status is Payment pending", true);

                } else {
                    System.out.println("Status is not Payment pending");
                    ExtentLogger.pass("Status is not Payment pending", true);
                   count++;

                }

                i++;

            }
            try {
                 if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {   break;
                } else {
                    driver.findElement(By.xpath("//span[text()='Next']")).click();
                }
            } catch (NoSuchElementException e) {
                System.out.println("next button is not visible " + e.getMessage());
                break;
            }
        }
        if(count>0){
            System.out.println("Status is not Payment pending");
            ExtentLogger.pass("Status is not Payment pending", true);
        }
        else{
            System.out.println("Status is Payment pending");
            ExtentLogger.pass("Status is Payment pending", true);
            Assert.fail();
        }
        return this;

    }

    public BillingPage verifyStatusOfInvoiceNotAsPaymentPending() throws InterruptedException, IOException {
        driver.navigate().refresh();
        waitForPageLoad();
        Thread.sleep(4000);
        // String color = driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color");
        //System.out.println(color);
        boolean a = true;
        while (a) {
            List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
            int i = 1;
            for (WebElement e : list1) {
                if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                    System.out.println("Status is not Payment pending");
                    ExtentLogger.pass("Status is not Payment pending", true);

                } else {
                    System.out.println("Status is  Payment pending");
                    ExtentLogger.pass("Status is  Payment pending", true);
                    Assert.assertTrue(false);

                }

                i++;

            }
            try {
                 if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {   break;
                } else {
                    driver.findElement(By.xpath("//span[text()='Next']")).click();
                }
            } catch (NoSuchElementException e) {
                System.out.println("next button is not visible " + e.getMessage());
                break;
            }
        }
        return this;

    }

    String ExistingCCFourDigitBank = "";

    public BillingPage ExistingBankAcc() throws InterruptedException, IOException {
        waitForPageLoad();
        // js.executeScript("window.scrollBy(0,400)");
        // Thread.sleep(3000);
        waitUntilVisible("ChoosePaymentMethod", "xpath", 30);
        driver.findElement(By.xpath("//select[@id='payment-method-select']")).click();
        Thread.sleep(2000);
        String text = driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Bank account ending in')])[1]")).getText();
        System.out.println(text);
        driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Bank account ending in')])[1]")).click();
        Thread.sleep(1000);
        ExistingCCFourDigitBank = text.split("ending in")[1].trim();
        System.out.println(ExistingCCFourDigitBank);

        // Select drpCountry = new Select(driver.findElement(By.xpath("//select[@id='payment-method-select']")));
        //drpCountry.selectByVisibleText("Bank account ending in "+lastFourDigitBanking+"");
        //drpCountry.selectByVisibleText("Bank account ending in");
        //drpCountry.selectByValue("1");
        clickElement(getElementByXpath("Next"));
        ExtentLogger.pass("Bank account ", true);
        return this;
    }

    public BillingPage ExistingBankAccUKI() throws InterruptedException, IOException {
        waitForPageLoad();
        // js.executeScript("window.scrollBy(0,400)");
        // Thread.sleep(3000);
        waitUntilVisible("ChoosePaymentMethod", "xpath", 30);
        driver.findElement(By.xpath("//select[@id='payment-method-select']")).click();
        Thread.sleep(2000);
        String text = driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Bank account ending in')])[1]")).getText();
        System.out.println(text);
        driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Bank account ending in')])[1]")).click();
        Thread.sleep(1000);
        ExistingCCFourDigitBank = text.split("ending in")[1].trim();
        System.out.println(ExistingCCFourDigitBank);

        // Select drpCountry = new Select(driver.findElement(By.xpath("//select[@id='payment-method-select']")));
        //drpCountry.selectByVisibleText("Bank account ending in "+lastFourDigitBanking+"");
        //drpCountry.selectByVisibleText("Bank account ending in");
        //drpCountry.selectByValue("1");

        return this;
    }

    public BillingPage clickonNextforsetupautopayBanking() throws InterruptedException, IOException {

        int i = 1;
        while (i < 4) {
            try {
                ExtentLogger.pass("Autopay Bank details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
                Thread.sleep(3000);
               /* waitUntilVisible("ClickOnNext","xpath",30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);*/
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 30);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(3000);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;

                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 4) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;


    }
    public BillingPage clickonNextforsetupautopayBanking_USL() throws InterruptedException, IOException {

        int i = 1;
        while (i < 4) {
            try {
                ExtentLogger.pass("Autopay Bank details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
                Thread.sleep(3000);
               /* waitUntilVisible("ClickOnNext","xpath",30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);*/
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 30);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(3000);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;

                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    clickElement(getElementByXpath("BackToBilling"));
                    Thread.sleep(3000);
                    ExtentLogger.pass("Clicked on Back to billing", true);


                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                 /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 4) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;


    }
    public BillingPage clickonNextforsetupautopayExiBanking_CAN() throws InterruptedException, IOException {

        int i = 1;
        while (i < 4) {
            try {
                ExtentLogger.pass("Autopay Bank details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
                Thread.sleep(3000);
               /* waitUntilVisible("ClickOnNext","xpath",30);
                clickElement(getElementByXpath("ClickOnNext"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);*/
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 30);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(3000);
                    waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;

                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically by the due date.') ]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    waitUntilVisible("BackToBilling", "xpath", 30);
                    Thread.sleep(3000);
                    clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 4) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;


    }
    String ExistingCCFourDigit = "";

    public BillingPage SelectExistingPaymentCC() throws InterruptedException, IOException {
        waitUntilVisible("ChoosePaymentMethod", "xpath", 30);

        driver.findElement(By.xpath("//select[@id='payment-method-select']")).click();
        Thread.sleep(2000);
        String text = driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Visa ending in')])[1]")).getText();
        System.out.println(text);
        driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Visa ending in')])[1]")).click();
        Thread.sleep(1000);
        ExistingCCFourDigit = text.split("ending in")[1].trim();
        System.out.println(ExistingCCFourDigit);

        return this;

    }
    public BillingPage SelectExistingPaymentCCWithCVVopPUp() throws InterruptedException, IOException {
        waitUntilVisible("ChoosePaymentMethod", "xpath", 30);

        driver.findElement(By.xpath("//select[@id='payment-method-select']")).click();
        Thread.sleep(2000);
        String text = driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Visa ending in')])[1]")).getText();
        System.out.println(text);
        driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Visa ending in')])[1]")).click();
        Thread.sleep(1000);
        ExistingCCFourDigit = text.split("ending in")[1].trim();
        System.out.println(ExistingCCFourDigit);
        waitTillElemenetVisible("ContinueToAutopayButton");
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        String code = "123";
        waitTillElemenetVisible("SecurityCodePopUp");
        clickElement(getElementByXpath("SecurityCodePopUp"));
        sendKeysTotheElement("SecurityCodePopUp", code);
        driver.switchTo().defaultContent();
        clickElement(getElementByXpath("ContinueToAutopayButton"));
        driver.switchTo().frame("creditCardIframe");
        System.out.println("1st frame");
        Thread.sleep(5000);
        try{
            driver.switchTo().frame("redirectTo3ds1Frame");
        }
        catch (Exception e){
            driver.switchTo().frame("challengeFrame");
        }
        System.out.println("2nd frame");
        Thread.sleep(3000);
        ExtentLogger.pass("Clicking on the pop up", true);
        driver.findElement(By.xpath("//input[@value='Submit']")).click();
        driver.switchTo().defaultContent();


        return this;

    }

    public BillingPage SelectExistingPaymentCCWithCVVopPUpPROD() throws InterruptedException, IOException {
        waitUntilVisible("ChoosePaymentMethod", "xpath", 30);

        driver.findElement(By.xpath("//select[@id='payment-method-select']")).click();
        Thread.sleep(2000);
        String text = driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Visa ending in')])[1]")).getText();
        System.out.println(text);
        driver.findElement(By.xpath("(//select[@id='payment-method-select']/option[contains(text(),'Visa ending in')])[1]")).click();
        Thread.sleep(1000);
        ExistingCCFourDigit = text.split("ending in")[1].trim();
        System.out.println(ExistingCCFourDigit);
        waitTillElemenetVisible("ContinueToAutopayButton");
        driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[class='tr-CreditCardIframe-input']")));
        String code = "123";
        waitTillElemenetVisible("SecurityCodePopUp");
        clickElement(getElementByXpath("SecurityCodePopUp"));
        sendKeysTotheElement("SecurityCodePopUp", code);
        driver.switchTo().defaultContent();
        clickElement(getElementByXpath("ContinueToAutopayButton"));
        driver.switchTo().frame("creditCardIframe");
        System.out.println("1st frame");
        Thread.sleep(5000);
        try{
            driver.switchTo().frame("redirectTo3ds1Frame");
        }
        catch (Exception e){
            driver.switchTo().frame("challengeFrame");
        }
        System.out.println("2nd frame");
        Thread.sleep(3000);
        ExtentLogger.pass("Clicking on the pop up", true);
        waitTillElemenetVisibleByxpath("//input[@value='Submit']");
        ExtentLogger.pass("Submit button is visible in the pop up", true);
      //  driver.findElement(By.xpath("//input[@value='Submit']")).click();
        driver.switchTo().defaultContent();


        return this;

    }


    public BillingPage verifyExistingAutopayCCDetails() throws InterruptedException, IOException {

        Thread.sleep(3000);
        String text = driver.findElement(By.xpath("//*[contains(text(),'Visa ending in')]")).getText();
        String actual = text.split("ending in")[1].trim();
        System.out.println(actual);
        System.out.println("Existing CC Four digits" + ExistingCCFourDigit);

        if (actual.equalsIgnoreCase(ExistingCCFourDigit)) {
            ExtentLogger.pass("Autopay credit card details are verified", true);

        } else {
            ExtentLogger.pass("Autopay credit card details verification failed ", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage ClickOnConfirm() throws InterruptedException, IOException {
        ExtentLogger.pass("Autopay credit card details entered", true);
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,1000)");
        try{waitUntilVisible("ClickOnNext", "xpath", 30);
        clickElement(getElementByXpath("ClickOnNext"));}
        catch(TimeoutException ex){
            waitUntilVisible("ClickOnNext2", "xpath", 30);
            clickElement(getElementByXpath("ClickOnNext2"));
        }
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        waitUntilVisible("CheckTnC", "xpath", 45);
        clickElement(getElementByXpath("CheckTnC"));
        ExtentLogger.pass("Agree terms and conditions", true);
        Thread.sleep(1000);
        waitUntilVisible("Confirm", "xpath", 30);
        clickElement(getElementByXpath("Confirm"));
        return this;
    }

    public BillingPage ClickOnConfirmUKI() throws InterruptedException, IOException {
        ExtentLogger.pass("Autopay credit card details entered", true);
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("ClickOnNext", "xpath", 30);
        clickElement(getElementByXpath("ClickOnNext"));
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(3000);
        Thread.sleep(7000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("creditCardIframe");
        System.out.println("1st frame");
        try{
            driver.switchTo().frame("challengeFrame");
        }
        catch (NoSuchFrameException e){
            driver.switchTo().frame("redirectTo3ds1Frame");
        }
        System.out.println("2nd frame");
        Thread.sleep(3000);
        ExtentLogger.pass("Clicking on the pop up", true);
        driver.findElement(By.xpath("//input[@value='Submit']")).click();
        driver.switchTo().defaultContent();
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(2000);
        waitUntilVisible("CheckTnC", "xpath", 45);
        clickElement(getElementByXpath("CheckTnC"));
        ExtentLogger.pass("Agree terms and conditions", true);
        Thread.sleep(1000);
        waitUntilVisible("Confirm", "xpath", 30);
        clickElement(getElementByXpath("Confirm"));
        return this;
    }


    public BillingPage validateCCAccountWarningHeading() throws InterruptedException, IOException {
        waitTillElemenetVisible("SameCCAccountWarningHeading");
        boolean warning = isElementDisplayed(getElementByXpath("SameCCAccountWarningHeading"));
        Assert.assertTrue(warning);
        ExtentLogger.pass("Warning at the top for same credit card in another account is visible", true);
        clickElement(getElementByXpath("CloseWarning"));
        Thread.sleep(1000);
        //driver.switchTo().defaultContent();
        return this;

    }

    public BillingPage backToBilling() throws InterruptedException, IOException {
        js.executeScript("window.scrollBy(0,-500)");
        waitUntilVisible("BackToBillingfromAddPaymentMethod", "xpath", 30);
        Thread.sleep(3000);
        clickElement(getElementByXpath("BackToBillingfromAddPaymentMethod"));
        return this;

    }

    public BillingPage verifyAutopayEnabledDuplicateCC(String month, String year) throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        Thread.sleep(6000);
        js.executeScript("window.scrollBy(0,600)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledCardNumber"));
        Assert.assertEquals(actual, lastFourDigit);
        String name = driver.findElement(By.xpath("(//span[@class='tr-TileBody-creditCardName']/p/strong)[1]")).getText();
        String expirationDate = driver.findElement(By.xpath("(//*[text()='" + lastFourDigit + "'])/ancestor::div[@class='tr-FlexGrid-row']//div[2]/p[text()='Expiration date']/following-sibling::p/strong")).getText();
        boolean flag = false;
        if (name.equalsIgnoreCase(CardName) && expirationDate.contains(month + "/" + year)) {
            flag = true;
            ExtentLogger.pass("Card details are verified", true);
        }

        if (flag == true) {
            ExtentLogger.pass("Card details are found in Manage payment method screen", true);
        } else {
            ExtentLogger.pass("Card details are not found in Manage payment method screen", true);

            Assert.assertTrue(false);

        }
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }

    public BillingPage verifyExistingAutopayBankDetails() throws InterruptedException, IOException {

        Thread.sleep(7000);

        String actual = driver.findElement(By.xpath("//strong[contains(text(),'"+ExistingCCFourDigitBank+"')]")).getText();
        System.out.println(actual);
        System.out.println("Existing CC Four digits " + ExistingCCFourDigitBank);



        if (actual.contains(ExistingCCFourDigitBank)) {
            ExtentLogger.pass("Autopay Bank account details are verified", true);

        } else {
            ExtentLogger.pass("Autopay Bank account details verification failed ", true);
            Assert.assertTrue(false);
        }


        return this;

    }
    public BillingPage verifyExistingAutopayBankDetails_CAD() throws InterruptedException, IOException {

        Thread.sleep(7000);

       // String text = driver.findElement(By.xpath("//span[@id='id-1' and contains(., 'Account ending in')]")).getText();
        String actual = driver.findElement(By.xpath("//strong[normalize-space()= '"+ExistingCCFourDigitBank+"']")).getText();
        System.out.println(actual);
        System.out.println("Existing CC Four digits" + ExistingCCFourDigitBank);

        if (actual.equalsIgnoreCase(ExistingCCFourDigitBank)) {
            ExtentLogger.pass("Autopay Bank account details are verified", true);

        } else {
            ExtentLogger.pass("Autopay Bank account details verification failed ", true);
            Assert.assertTrue(false);
        }


        return this;

    }
    public BillingPage verifyAutopayOFF() throws InterruptedException, IOException {

        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//strong[normalize-space()='Autopay is turned off']");

        String text = driver.findElement(By.xpath("//strong[normalize-space()='Autopay is turned off']")).getText();
        String actual = "Autopay is turned off";
        System.out.println(actual);
        ExtentLogger.pass("Verficiation of turnoff autopay is successful", true);

      // waitUntilVisible("BackToBilling", "xpath", 30);
      // clickElement(getElementByXpath("BackToBilling"));



        return this;

    }

    public BillingPage verifyAutopayEnabledBankExistingAcc() throws InterruptedException, IOException {
       waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledBankNumber"));
        Assert.assertEquals(actual, ExistingCCFourDigitBank);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }
    public BillingPage verifyAutopayEnabledBankExistingAcc_CAD() throws InterruptedException, IOException {
       Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledBankNumber"));
        Assert.assertEquals(actual, ExistingCCFourDigitBank);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }

    public BillingPage BackToBillingPage() throws InterruptedException, IOException {
        waitForPageLoad();
        //Thread.sleep(6000);
        js.executeScript("window.scrollBy(0,-600)");
        Thread.sleep(1000);
        Thread.sleep(3000);
        //waitTillElemenetVisibleByxpath("Backtobillingpage");
        //getElementText("Thanksforsettingupautopay");
        try{
            Thread.sleep(3000);
            waitForPageLoad();
            clickElement(getElementByXpath("BackToBillingfromAddPaymentMethod"));
            ExtentLogger.pass("Clicking on Back to Billing ",true);
        }
        catch(Exception t){
            System.out.println("No Back to Billing button present");
            ExtentLogger.pass("No Back to Billing button present ",true);
        }

        // Thread.sleep(2000);
        //waitTillElemenetVisibleByxpath("Confirm");
        // clickElement(getElementByXpath("Confirm"));
        return this;

    }

    public BillingPage RountingNumDuplicate() throws InterruptedException, IOException {
        waitForPageLoad();
        //waitUntilVisible("BankAccount", "xpath", 30);
        //driver.switchTo().frame(driver.findElement(By.cssSelector(".tr-ManagePaymentAddDialog-dialogContent")));

        waitTillElemenetVisible("RoutingNumber");
        clickElement(getElementByXpath("RoutingNumber"));
        sendKeysTotheElement("RoutingNumber", RountingNumDuplicate);
        System.out.println("RountingNumDuplicate=" + RountingNumDuplicate);
        // RountingNumDuplicate=description1;

        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }
    public BillingPage TransitNumDuplicate() throws InterruptedException, IOException {
        waitForPageLoad();
        //waitUntilVisible("BankAccount", "xpath", 30);
        //driver.switchTo().frame(driver.findElement(By.cssSelector(".tr-ManagePaymentAddDialog-dialogContent")));

        waitTillElemenetVisible("TransitNum");
        clickElement(getElementByXpath("TransitNum"));
        sendKeysTotheElement("TransitNum", TransitNumDuplicateCAN);
        System.out.println("RountingNumDuplicate=" + TransitNumDuplicateCAN);
        // RountingNumDuplicate=description1;

        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }
    public BillingPage InstitutionNumDuplicate() throws InterruptedException, IOException {
        waitForPageLoad();

        waitTillElemenetVisible("InstitutionNum");
        clickElement(getElementByXpath("InstitutionNum"));
        sendKeysTotheElement("InstitutionNum", InstitutionNumDuplicateCAN1);
        // AccNumDuplicate=description2;
        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }

    public BillingPage AccountNumDuplicate() throws InterruptedException, IOException {
        waitForPageLoad();

        waitTillElemenetVisible("AccountNumber");
        clickElement(getElementByXpath("AccountNumber"));
        sendKeysTotheElement("AccountNumber", AccNumDuplicate);
        // AccNumDuplicate=description2;
        lastFourDigitBanking = AccNumDuplicate;
        lastFourDigitBanking = lastFourDigitBanking.substring(lastFourDigitBanking.length() - 4);
        System.out.println("Last 4 digit number is " + lastFourDigitBanking);
        System.out.println("AccountNumDuplicate=" + AccNumDuplicate);
        driver.switchTo().defaultContent();
        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }

    public BillingPage DeleteAutopayEnabledBankExistingAcc() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledBankNumber"));
        Assert.assertEquals(actual, ExistingCCFourDigitBank);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("DeletAutopayBankAcc"));
        ExtentLogger.pass("Clicked on Delete button successfully ", true);
        waitForPageLoad();
        Thread.sleep(3000);
        clickElement(getElementByXpath("DeleteAutoPayMethod"));
        ExtentLogger.pass("Clicked on DeleteAutoPayMethod button successfully ", true);
        waitForPageLoad();
        waitTillElemenetVisible("BankAccountRemovedMessage");
        String value = getElementTextbyElement(getElementByXpath("BankAccountRemovedMessage"));
        boolean res = value.contains("Bank account removed");
        Assert.assertTrue(res);
        boolean flag = false;
        value = getElementTextbyElement(getElementByXpath("BankAccountNumberRemovedMessage"));
        res = value.contains("Your bank account ending in " + ExistingCCFourDigitBank + " has been removed.");
        Assert.assertTrue(res);
        Thread.sleep(2000);
        ExtentLogger.pass("Pop up validation of Bank account deleted successfully", true);
        clickElement(getElementByXpath("CloseButton"));
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(1000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong[text()='" + ExistingCCFourDigitBank + "']"));
        if (list1.size() == 0) {
            ExtentLogger.pass("Bank Account number deleted successfully", true);
        } else {
            ExtentLogger.pass("Bank Account number deletion failed and bank account number still exist in the account", true);
            Assert.assertTrue(false);
        }
        List<WebElement> list2 = driver.findElements(By.xpath("//div[text()='Autopay enabled']"));
        if (list2.size() == 0) {
            ExtentLogger.pass("AutoPay deleted successfully", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }
        // Thread.sleep(3000);git
        return this;

    }

    public BillingPage DeleteAutopayEnabledBankExistingAcc_CAD() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        /*waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledBankNumber"));
        Assert.assertEquals(actual, ExistingCCFourDigitBank);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);*/
        Thread.sleep(3000);
        clickElement(getElementByXpath("DeletAutopayBankAcc"));
        ExtentLogger.pass("Clicked on Delete button successfully ", true);
        waitForPageLoad();
        Thread.sleep(3000);
        clickElement(getElementByXpath("DeleteAutoPayMethod"));
        ExtentLogger.pass("Clicked on DeleteAutoPayMethod button successfully ", true);
        waitForPageLoad();
        waitTillElemenetVisible("BankAccountRemovedMessage");
        String value = getElementTextbyElement(getElementByXpath("BankAccountRemovedMessage"));
        boolean res = value.contains("Bank account removed");
        Assert.assertTrue(res);
        boolean flag = false;
        value = getElementTextbyElement(getElementByXpath("BankAccountNumberRemovedMessage"));
        res = value.contains("Your bank account ending in " + ExistingCCFourDigitBank + " has been removed.");
        Assert.assertTrue(res);
        Thread.sleep(2000);
        ExtentLogger.pass("Pop up validation of Bank account deleted successfully", true);
        clickElement(getElementByXpath("CloseButton"));
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(1000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong[text()='" + ExistingCCFourDigitBank + "']"));
        if (list1.size() == 0) {
            ExtentLogger.pass("Bank Account number deleted successfully", true);
        } else {
            ExtentLogger.pass("Bank Account number deletion failed and bank account number still exist in the account", true);
            Assert.assertTrue(false);
        }
        List<WebElement> list2 = driver.findElements(By.xpath("//div[text()='Autopay enabled']"));
        if (list2.size() == 0) {
            ExtentLogger.pass("AutoPay deleted successfully", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }
        // Thread.sleep(3000);git
        return this;

    }

    public BillingPage DeleteAutopayEnabledBankNewAcc() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledBankNumber"));
        Assert.assertEquals(actual, lastFourDigitBanking);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("DeletAutopayBankAcc"));
        ExtentLogger.pass("Clicked on Delete button successfully ", true);
        waitForPageLoad();
        Thread.sleep(3000);
        clickElement(getElementByXpath("DeleteAutoPayMethod"));
        ExtentLogger.pass("Clicked on DeleteAutoPayMethod button successfully ", true);
        waitForPageLoad();
        waitTillElemenetVisible("BankAccountRemovedMessage");
        String value = getElementTextbyElement(getElementByXpath("BankAccountRemovedMessage"));
        boolean res = value.contains("Bank account removed");
        Assert.assertTrue(res);
        boolean flag = false;
        value = getElementTextbyElement(getElementByXpath("BankAccountNumberRemovedMessage"));
        res = value.contains("Your bank account ending in " + lastFourDigitBanking + " has been removed.");
        Assert.assertTrue(res);
        Thread.sleep(2000);
        ExtentLogger.pass("Pop up validation of Bank account deleted successfully", true);
        clickElement(getElementByXpath("CloseButton"));
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(1000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong[text()='" + lastFourDigitBanking + "']"));
        if (list1.size() == 0) {
            ExtentLogger.pass("Bank Account number deleted successfully", true);
        } else {
            ExtentLogger.pass("Bank Account number deletion failed and bank account number still exist in the account", true);
            Assert.assertTrue(false);
        }
        List<WebElement> list2 = driver.findElements(By.xpath("//div[text()='Autopay enabled']"));
        if (list2.size() == 0) {
            ExtentLogger.pass("AutoPay deleted successfully", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }

        // Thread.sleep(3000);
        return this;

    }

    public BillingPage deleteAutopayEnabledCCNew() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledCardNumber"));
        Assert.assertEquals(actual, lastFourDigit);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("DeletAutopayBankAcc"));
        ExtentLogger.pass("Clicked on Delete button successfully ", true);
        waitForPageLoad();
        Thread.sleep(3000);
        clickElement(getElementByXpath("DeleteAutoPayMethod"));
        ExtentLogger.pass("Clicked on DeleteAutoPayMethod button successfully ", true);
        waitForPageLoad();
        waitTillElemenetVisible("CreditCardRemovedMessage");
        String value = getElementTextbyElement(getElementByXpath("CreditCardRemovedMessage"));
        boolean res = value.contains("Credit card removed");
        Assert.assertTrue(res);
        boolean flag = false;
        value = getElementTextbyElement(getElementByXpath("CreditCardRemovedNumberMessage"));
        res = value.contains("Your credit card ending in " + lastFourDigit + " has been removed.");
        Assert.assertTrue(res);
        Thread.sleep(2000);
        ExtentLogger.pass("Pop up validation of Credit card deleted successfully", true);
        clickElement(getElementByXpath("CloseButton"));
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(1000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Visa ending in']/following-sibling::p/strong[text()='" + lastFourDigit + "']"));
        if (list1.size() == 0) {
            ExtentLogger.pass("Credit card deleted successfully", true);
        } else {
            ExtentLogger.pass("Credit card number deletion failed and Credit card still exist", true);
            Assert.assertTrue(false);
        }
        List<WebElement> list2 = driver.findElements(By.xpath("//div[text()='Autopay enabled']"));
        if (list2.size() == 0) {
            ExtentLogger.pass("AutoPay deleted successfully", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }

        // Thread.sleep(3000);
        return this;

    }

    public BillingPage deleteAutopayEnabledCCExisting() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        js.executeScript("window.scrollBy(0,500)");
        waitUntilVisible("AutopayEnabled", "xpath", 30);
        boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        Assert.assertTrue(display1);
        Assert.assertTrue(display2);
        String actual = getElementTextbyElement(getElementByXpath("AutoPayEnabledCardNumber"));
        Assert.assertEquals(actual, ExistingCCFourDigit);
        ExtentLogger.pass("Autopay enabled verification completed successfully ", true);
        clickElement(getElementByXpath("DeletAutopayBankAcc"));
        ExtentLogger.pass("Clicked on Delete button successfully ", true);
        waitForPageLoad();
        Thread.sleep(3000);
        clickElement(getElementByXpath("DeleteAutoPayMethod"));
        ExtentLogger.pass("Clicked on DeleteAutoPayMethod button successfully ", true);
        waitForPageLoad();
        waitTillElemenetVisible("CreditCardRemovedMessage");
        String value = getElementTextbyElement(getElementByXpath("CreditCardRemovedMessage"));
        boolean res = value.contains("Credit card removed");
        Assert.assertTrue(res);
        boolean flag = false;
        value = getElementTextbyElement(getElementByXpath("CreditCardRemovedNumberMessage"));
        res = value.contains("Your credit card ending in " + ExistingCCFourDigit + " has been removed.");
        Assert.assertTrue(res);
        Thread.sleep(2000);
        ExtentLogger.pass("Pop up validation of Credit card deleted successfully", true);
        clickElement(getElementByXpath("CloseButton"));
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(1000);
        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Visa ending in']/following-sibling::p/strong[text()='" + ExistingCCFourDigit + "']"));
        if (list1.size() == 0) {
            ExtentLogger.pass("Credit card deleted successfully", true);
        } else {
            ExtentLogger.pass("Credit card number deletion failed and Credit card still exist", true);
            Assert.assertTrue(false);
        }
        List<WebElement> list2 = driver.findElements(By.xpath("//div[text()='Autopay enabled']"));
        if (list2.size() == 0) {
            ExtentLogger.pass("AutoPay deleted successfully", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }

        // Thread.sleep(3000);
        return this;

    }

    public BillingPage verifyAutopayNewBank_TurnedOff() throws InterruptedException, IOException {

        Thread.sleep(3000);
        waitTillElemenetVisible("AutoPayTurnedOffmsg");
        ExtentLogger.pass("Your autopay has been turned off ", true);
       /* boolean display1 = driver.findElement(By.xpath("//p[contains(text(),'Your account will no longer be paid automatically ')]")).isDisplayed();
        // boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        List<WebElement> list3 = driver.findElements(By.xpath("//strong[normalize-space()=" + lastFourDigitBanking + "]"));
        if (list3.size() == 1) {
            ExtentLogger.pass("Your account will no longer be paid automatically with bank account ending in " + lastFourDigitBanking + ".", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }
        Assert.assertTrue(display1);*/
        waitTillElemenetVisible("Backtobillingpage1");
        Thread.sleep(3000);
        clickElement(getElementByXpath("Backtobillingpage1"));


        // Thread.sleep(3000);
        return this;
    }

    public BillingPage verifyAutopayExistingBank_TurnedOff() throws InterruptedException, IOException {

        Thread.sleep(3000);
        waitTillElemenetVisible("AutoPayTurnedOffmsg");
        ExtentLogger.pass("Your autopay has been turned off ", true);
      /*  boolean display1 = driver.findElement(By.xpath("//p[contains(text(),'Your account will no longer be paid automatically ')]")).isDisplayed();
        Assert.assertTrue(display1);
        // boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        List<WebElement> list3 = driver.findElements(By.xpath("//strong[normalize-space()=" + ExistingCCFourDigitBank + "]"));
        if (list3.size() == 1) {
            ExtentLogger.pass("Your account will no longer be paid automatically with bank account ending in " + ExistingCCFourDigitBank + ".", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }
*/
        waitTillElemenetVisible("Backtobillingpage1");
        Thread.sleep(3000);
        clickElement(getElementByXpath("Backtobillingpage1"));


        // Thread.sleep(3000);
        return this;
    }

    public BillingPage verifyAutopayDisableNewBank() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        Thread.sleep(8000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(8000);
        // boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        // Assert.assertTrue(display1);


        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong[text()='" + lastFourDigitBanking + "']"));
        if (list1.size() == 1) {
            ExtentLogger.pass("Bank Account number still exist ", true);
        } else {
            ExtentLogger.pass("Bank Account number is deleted ", true);
            Assert.assertTrue(false);
        }
        List<WebElement> list2 = driver.findElements(By.xpath("//div[text()='Autopay enabled']"));
        if (list2.size() == 0) {
            ExtentLogger.pass("AutoPay deleted successfully", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }


        // clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }

    public BillingPage verifyAutopayDisableExistingBank() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);
        // boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        // Assert.assertTrue(display1);


        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Account ending in']/following-sibling::p/strong[text()='" + ExistingCCFourDigitBank + "']"));
        if (list1.size() == 1) {
            ExtentLogger.pass("Bank Account number still exist in the account", true);
        } else {
            ExtentLogger.pass("Bank Account number deleted ", true);
            Assert.assertTrue(false);
        }
        List<WebElement> list2 = driver.findElements(By.xpath("//div[text()='Autopay enabled']"));
        if (list2.size() == 0) {
            ExtentLogger.pass("AutoPay deleted successfully", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }

        //clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }

    public BillingPage backtobillingFromAutopay() throws InterruptedException, IOException {

        try {
            waitUntilVisible("Backtobillingpage1", "xpath", 80);
            Thread.sleep(3000);
            clickElement(getElementByXpath("Backtobillingpage1"));
            Thread.sleep(15000);
            ExtentLogger.pass("Clicking on Back to billing", true);
            driver.findElement(By.xpath("//span[normalize-space()='Back to billing']")).click();
        } catch(Exception e){
            System.out.println("Not able to click on Back to billing ");
            ExtentLogger.pass("Not able to click on Back to billing ", true);
        }
        return this;
    }

    public BillingPage verifyAutopayNewCC_TurnedOff() throws InterruptedException, IOException {

        Thread.sleep(3000);
        waitTillElemenetVisible("AutoPayTurnedOffmsg");
        ExtentLogger.pass("Your autopay has been turned off ", true);
      /*  boolean display1 = driver.findElement(By.xpath("//p[contains(text(),'Your account will no longer be paid automatically ')]")).isDisplayed();
        // boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        List<WebElement> list3 = driver.findElements(By.xpath("//strong[normalize-space()=" + lastFourDigit + "]"));
        if (list3.size() == 1) {
            ExtentLogger.pass("Your account will no longer be paid automatically with Credit card account ending in " + lastFourDigit + ".", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }
        Assert.assertTrue(display1);

       */
        waitTillElemenetVisible("Backtobillingpage1");
        Thread.sleep(3000);
        clickElement(getElementByXpath("Backtobillingpage1"));


        // Thread.sleep(3000);
        return this;
    }
    public BillingPage verifyAutopayNewCC_TurnedOff_CAD() throws InterruptedException, IOException {

        Thread.sleep(3000);
        waitTillElemenetVisible("AutoPayTurnedOffmsg");
        ExtentLogger.pass("Your autopay has been turned off ", true);
       /* boolean display1 = driver.findElement(By.xpath("//p[contains(text(),'Your account will no longer be paid automatically ')]")).isDisplayed();
        // boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        List<WebElement> list3 = driver.findElements(By.xpath("//strong[normalize-space()=" + lastFourDigit + "]"));
        if (list3.size() == 1) {
            ExtentLogger.pass("Your account will no longer be paid automatically with Credit card account ending in " + lastFourDigit + ".", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }
        Assert.assertTrue(display1);*/
        waitTillElemenetVisible("Backtobillingpage1");
        Thread.sleep(3000);
        clickElement(getElementByXpath("Backtobillingpage1"));


        // Thread.sleep(3000);
        return this;
    }

    public BillingPage verifyAutopayExistingCC_TurnedOff() throws InterruptedException, IOException {

        Thread.sleep(3000);
        waitTillElemenetVisible("AutoPayTurnedOffmsg");
        ExtentLogger.pass("Your autopay has been turned off ", true);
        boolean display1 = driver.findElement(By.xpath("//p[contains(text(),'Your account will no longer be paid automatically ')]")).isDisplayed();
        Assert.assertTrue(display1);
        // boolean display2 = driver.findElement(By.xpath("//*[contains(text(),'Autopay enabled')]")).isDisplayed();
        List<WebElement> list3 = driver.findElements(By.xpath("//strong[normalize-space()=" + ExistingCCFourDigit + "]"));
        if (list3.size() == 1) {
            ExtentLogger.pass("Your account will no longer be paid automatically with Credit card account ending in " + ExistingCCFourDigit + ".", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }

        waitTillElemenetVisible("Backtobillingpage1");
        Thread.sleep(3000);
        clickElement(getElementByXpath("Backtobillingpage1"));


        // Thread.sleep(3000);
        return this;
    }

    public BillingPage verifyAutopayDisableNewCC() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        Thread.sleep(8000);
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(8000);
        // boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        // Assert.assertTrue(display1);


        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()=" + lastFourDigit + "]"));
        if (list1.size() == 1) {
            ExtentLogger.pass("Credit card Account number still exist in the account  ", true);
        } else {
            ExtentLogger.pass("Credit card account number deleted", true);
            Assert.assertTrue(false);
        }
        List<WebElement> list2 = driver.findElements(By.xpath("//div[text()='Autopay enabled']"));
        if (list2.size() == 0) {
            ExtentLogger.pass("AutoPay deleted successfully", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }


         clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }

    public BillingPage verifyAutopayDisableExistingCC() throws InterruptedException, IOException {
        waitUntilVisible("ManagePaymentMethod", "xpath", 30);
        clickElement(getElementByXpath("ManagePaymentMethod"));
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);
        // boolean display1 = driver.findElement(By.xpath("//span[@class='tr-TileHeader-icon']")).isDisplayed();
        // Assert.assertTrue(display1);


        List<WebElement> list1 = driver.findElements(By.xpath("//*[text()='Card ending in']/following-sibling::p/strong[text()='" + ExistingCCFourDigit + "']"));
        if (list1.size() == 1) {
            ExtentLogger.pass("Credit card Account number still exist in the account", true);
        } else {
            ExtentLogger.pass("Credit card Account number deleted ", true);
            Assert.assertTrue(false);
        }
        List<WebElement> list2 = driver.findElements(By.xpath("//div[text()='Autopay enabled']"));
        if (list2.size() == 0) {
            ExtentLogger.pass("AutoPay deleted successfully", true);
        } else {
            ExtentLogger.pass("AutoPay deletion failed ", true);
            Assert.assertTrue(false);
        }

        clickElement(getElementByXpath("BillingTab"));
        waitForPageLoad();
        return this;

    }


    public BillingPage AutoPayOffNewCC(String Url, String month, String year) throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;
                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPayNew()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
       .openURL(dataMap.get("CardGuru"))
               .clickOngenrate().CreditCardNumber()
               .switchToWindow(0)*/
                    .generateCreditCard()
                    .enterCardNumber()
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopay_USL().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    .verifyAutopayNewCC_TurnedOff().verifyAutopayDisableNewCC()
                    //.BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPayNew()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
       .openURL(dataMap.get("CardGuru"))
               .clickOngenrate().CreditCardNumber()
               .switchToWindow(0)*/
                    .generateCreditCard()
                    .enterCardNumber()
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopay_USL().verifyAutopayCCDetails()//.verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    .verifyAutopayNewCC_TurnedOff_CAD().verifyAutopayDisableNewCC()
                   // .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;

                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }

    public BillingPage AutoPayOffNewCC_CAD(String Url, String month, String year) throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;
                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    .SelectPaymentMethod("Add new payment method")
                     .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
       .openURL(dataMap.get("CardGuru"))
               .clickOngenrate().CreditCardNumber()
               .switchToWindow(0)*/
                    .generateCreditCard()
                    .enterCardNumber()
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopay_CAND().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    .verifyAutopayNewCC_TurnedOff_CAD().verifyAutopayDisableNewCC()
                   // .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
       .openURL(dataMap.get("CardGuru"))
               .clickOngenrate().CreditCardNumber()
               .switchToWindow(0)*/
                    .generateCreditCard()
                    .enterCardNumber()
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopay_CAND().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    .verifyAutopayNewCC_TurnedOff().verifyAutopayDisableNewCC()
                    .BackToBillingPage().SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;

                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }




    public BillingPage AutoPayOffNewCC_UKI(String card, String month, String year) throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay or Turn on autopay is visible");
            ExtentLogger.pass("Setup autopay or Turn on autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;
                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            checkCurrencyUKI()
                    .clickOnManagePaymentsMethod()
                    .DeleteCC(card)
                    .clickOnSetUpAutoPayNew()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCardorBank()
                    // .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
        .openURL(dataMap.get("CardGuru"))
                .clickOngenrate().CreditCardNumber()
                .switchToWindow(0)
                    .generateCreditCard()
                    .enterCardNumber()*/
                    .enterCardNumberFromExcelUKI(card)
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopayUKI().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                   // .verifyAutopayNewCC_TurnedOff()
                   // .backToBilling()
                    .backtobillingFromAutopay()
                    .verifyAutopayDisableNewCC()
                   // .BackToBillingPage()
            .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            checkCurrencyUKI()
                    .clickOnManagePaymentsMethod()
                    .DeleteCC(card)
                    .clickOnSetUpAutoPayNew()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCardorBank()
                    // .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
        .openURL(dataMap.get("CardGuru"))
                .clickOngenrate().CreditCardNumber()
                .switchToWindow(0)
                    .generateCreditCard()
                    .enterCardNumber()*/
                    .enterCardNumberFromExcelUKI(card)
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopayUKI().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    //.verifyAutopayNewCC_TurnedOff()
                   // .backToBilling()
                    // .verifyAutopayDisableNewCC()
                    // .BackToBillingPage()
                    .backtobillingFromAutopay()
                    .verifyAutopayDisableNewCC()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;

                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }




    public BillingPage AutoPayOffExistingCC() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay or Turn on autopay is visible");
            ExtentLogger.pass("Setup autopay or Turn on autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPayNew()
                    .SelectExistingPaymentCC()
                .clickonNextforsetupautopay_UKI().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                // .verifyAutopayExistingCC_TurnedOff()
                .backtobillingFromAutopay()
                .verifyAutopayDisableExistingCC()
                .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPayNew()
                    .SelectExistingPaymentCC()
                    .clickonNextforsetupautopay_UKI().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    // .verifyAutopayExistingCC_TurnedOff()
                    .backtobillingFromAutopay()
                    .verifyAutopayDisableExistingCC()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }



    public BillingPage AutoPayOffExistingCC_USL() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay or Turn on autopay is visible");
            ExtentLogger.pass("Setup autopay or Turn on autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            checkCurrencyUKI()
                    .clickOnSetUpAutoPayNew()
                    .SelectExistingPaymentCC().NextButton()
                    .clickonNextforsetupautopayBanking().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    // .verifyAutopayExistingCC_TurnedOff()
                    .backtobillingFromAutopay()
                    .verifyAutopayDisableExistingCC()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    .SelectExistingPaymentCC().NextButton()
                    .clickonNextforsetupautopayBanking().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    //.verifyAutopayExistingCC_TurnedOff()
                    .backtobillingFromAutopay()
                    .verifyAutopayDisableExistingCC()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }




    public BillingPage AutoPayOffExistingCC_UKI_Autopay_ON() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay or Turn on autopay is visible");
            ExtentLogger.pass("Setup autopay or Turn on autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            checkCurrencyUKI()
                    .clickOnSetUpAutoPayNewExisting()
                    .SelectExistingPaymentCCWithCVVopPUp()
                    .clickonNextforsetupautopay_UKI().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    // .verifyAutopayExistingCC_TurnedOff()
                    .backtobillingFromAutopay()
                    .verifyAutopayDisableExistingCC()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPayNewExisting()
                    .SelectExistingPaymentCCWithCVVopPUp()
                    .clickonNextforsetupautopay_UKI().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    //.verifyAutopayExistingCC_TurnedOff()
                    .backtobillingFromAutopay()
                    .verifyAutopayDisableExistingCC()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }


    public BillingPage AutoPayOffExistingCC_UKI() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//div[@class='tr-AutopayOverview-innerCard']//span")).getText().contains("Set up autopay")) {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    .SelectExistingPaymentCC()
                    .clickonNextforsetupautopay_UKI().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    .verifyAutopayExistingCC_TurnedOff().verifyAutopayDisableExistingCC()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    .SelectExistingPaymentCC()
                    .clickonNextforsetupautopay_UKI().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay()
                    .verifyAutopayExistingCC_TurnedOff().verifyAutopayDisableExistingCC()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }


    public BillingPage AutoPayOffNewBank() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .AddNewBankAcc()
                    .RountingNumber()
                    .AccountNumber()
                    .clickonNextforsetupautopay_USL().verifyAutopayBankDetails()//.verifyAutopayEnabledBank()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay().verifyAutopayNewCC_TurnedOff_CAD()
                    // .clickOnManagePaymentsMethod()
                    .verifyAutopayDisableNewBank()

                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .AddNewBankAcc()
                    .RountingNumber()
                    .AccountNumber()
                    .clickonNextforsetupautopay_USL().verifyAutopayBankDetails()//.verifyAutopayEnabledBank()
                    .verifyStatusOfInvoiceAsPaymentPending().ManageAutoPay().verifyAutopayNewCC_TurnedOff_CAD()
                    // .clickOnManagePaymentsMethod()
                    .verifyAutopayDisableNewBank()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }


    public BillingPage AutoPayOffExistingBank() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .ExistingBankAcc()
                    //.RountingNumber()
                    // .AccountNumber()
                    //.NextButton()
                    // .CheckBox()
                    .clickonNextforsetupautopayBanking_USL()
                    //.verifyAutopaybankDetails()
                    .verifyExistingAutopayBankDetails()
                   // .verifyAutopayEnabledBankExistingAcc()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .ManageAutoPay().BackToBillingPage()//.verifyAutopayExistingBank_TurnedOff()
                    .verifyAutopayDisableExistingBank()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;


                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .ExistingBankAcc()
                    //.RountingNumber()
                    // .AccountNumber()
                    //.NextButton()
                    // .CheckBox()
                    .clickonNextforsetupautopayBanking_USL()
                    //.verifyAutopaybankDetails()
                    .verifyExistingAutopayBankDetails()
                    // .verifyAutopayEnabledBankExistingAcc()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .ManageAutoPay().BackToBillingPage()//.verifyAutopayExistingBank_TurnedOff()
                    .verifyAutopayDisableExistingBank()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }


    public BillingPage DeleteAutoPayNewCC(String Url, String month, String year) throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }


            clickOnSetUpAutoPay()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
       .openURL(dataMap.get("CardGuru"))
               .clickOngenrate().CreditCardNumber()
               .switchToWindow(0)*/
                    .generateCreditCard()
                    .enterCardNumber()
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopay_USL().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCNew()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();


            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
       .openURL(dataMap.get("CardGuru"))
               .clickOngenrate().CreditCardNumber()
               .switchToWindow(0)*/
                    .generateCreditCard()
                    .enterCardNumber()
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopay_USL().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCNew()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }


    public BillingPage DeleteAutoPayNewCC_CAD(String Url, String month, String year) throws IOException, InterruptedException {
        Thread.sleep(7000);
      //  waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {    System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }


            clickOnSetUpAutoPay()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
       .openURL(dataMap.get("CardGuru"))
               .clickOngenrate().CreditCardNumber()
               .switchToWindow(0)*/
                    .generateCreditCard()
                    .enterCardNumber()
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopay_CAND().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCNew()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();


            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
       .openURL(dataMap.get("CardGuru"))
               .clickOngenrate().CreditCardNumber()
               .switchToWindow(0)*/
                    .generateCreditCard()
                    .enterCardNumber()
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopay_CAND().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCNew()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }



    public BillingPage DeleteAutoPayNewCC_UKI(String card, String month, String year) throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
        ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay or Turn on autopay is visible");
            ExtentLogger.pass("Setup autopay or Turn on autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

                 checkCurrencyUKI()
                         .clickOnManagePaymentsMethod()
                         .DeleteCC(card)
                .clickOnSetUpAutoPayNew()
                .SelectPaymentMethod("Add new payment method")
                .clickOnCreditCardorBank()

                    // .clickOnCreditCard()
                    .enterNameOnCard()
                         /* .openNewTab()
             .openURL(dataMap.get("CardGuru"))
                     .clickOngenrate().CreditCardNumber()
                     .switchToWindow(0)
                         .generateCreditCard()
                    .enterCardNumber()*/
                         .enterCardNumberFromExcelUKI(card)
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopayUKI().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCNew()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();


            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            checkCurrencyUKI()
                    .clickOnManagePaymentsMethod()
                    .DeleteCC(card)
                    .clickOnSetUpAutoPayNew()
                    .SelectPaymentMethod("Add new payment method")
                    .clickOnCreditCardorBank()
                    //  .clickOnCreditCard()
                    .enterNameOnCard()
                    /* .openNewTab()
       .openURL(dataMap.get("CardGuru"))
               .clickOngenrate().CreditCardNumber()
               .switchToWindow(0)
                    .generateCreditCard()
                    .enterCardNumber()*/
                    .enterCardNumberFromExcelUKI(card)
                    .SelectMonthAndYear(month, year)
                    .enterSecurityCode().clickonNextforsetupautopayUKI().verifyAutopayCCDetails().verifyAutopayEnabled()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCNew()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }






    public BillingPage DeleteAutoPayExistingCC() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    .SelectExistingPaymentCC()
                    .clickonNextforsetupautopay_USL().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCExisting()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    .SelectExistingPaymentCC()
                    .clickonNextforsetupautopay_USL().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCExisting()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }

    public BillingPage DeleteAutoPayExistingCC_CAD() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    .SelectExistingPaymentCC()
                    .clickonNextforsetupautopay_CAND().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCExisting()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    .SelectExistingPaymentCC()
                    .clickonNextforsetupautopay_CAND().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCExisting()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }




    public BillingPage DeleteAutoPayExistingCC_UKI() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

           checkCurrencyUKI()
                    .clickOnSetUpAutoPayNewExisting()
                    .SelectExistingPaymentCCWithCVVopPUp()
                    .clickonNextforsetupautopayUKIExisting().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCExisting()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            checkCurrencyUKI()
                    .clickOnSetUpAutoPayNewExisting()
                    .SelectExistingPaymentCCWithCVVopPUp()
                    .clickonNextforsetupautopayUKIExisting().verifyExistingAutopayCCDetails().verifyAutopayEnabledExisting()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .deleteAutopayEnabledCCExisting()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }






    public BillingPage DeleteAutoPayNewBank() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;


                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .AddNewBankAcc()
                    .RountingNumber()
                    .AccountNumber().NextButton()
                    .clickonNextforsetupautopayBanking().backtobillingFromAutopay()
                    .verifyAutopayBankDetails()//.verifyAutopayEnabledBank()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .DeleteAutopayEnabledBankNewAcc()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();



            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .AddNewBankAcc()
                    .RountingNumber()
                    .AccountNumber().NextButton()
                    .clickonNextforsetupautopayBanking()//.backtobillingFromAutopay()
                    .verifyAutopayBankDetails()
                  //  .backtobillingFromAutopay()
           // .verifyAutopaybankDetails()
                    //.verifyAutopayEnabledBank()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .DeleteAutopayEnabledBankNewAcc()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }

    public BillingPage DeleteAutoPayNewBankCAD() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;


                    }

                    i++;

                }
                try {
                    if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                            ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                    {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .AddNewBankAcc()
                    .TransitNum_CAN()
                    .Institution_CAN()
                    .AccountNumber().NextButton()
                    .clickonNextforsetupautopayExiBanking_CAN().backtobillingFromAutopay()
                    .verifyAutopayBankDetails()//.verifyAutopayEnabledBank()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .DeleteAutopayEnabledBankNewAcc()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();



            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                            if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                                    ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                            {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                            if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                                    ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                            {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay().backtobillingFromAutopay();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                    if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                            ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                    {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .AddNewBankAcc()
                    .TransitNum_CAN()
                    .Institution_CAN()
                    .AccountNumber().NextButton()
                    .clickonNextforsetupautopayExiBanking_CAN()//.backtobillingFromAutopay()
                    .verifyAutopayBankDetails()
                    //  .backtobillingFromAutopay()
                    // .verifyAutopaybankDetails()
                    //.verifyAutopayEnabledBank()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .DeleteAutopayEnabledBankNewAcc()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                            if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                                    ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                            {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                            if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                                    ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                            {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }


    public BillingPage DeleteAutoPayExistingBank() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .ExistingBankAcc()
                    //.RountingNumber()
                    // .AccountNumber()
                    //.NextButton()
                    // .CheckBox()
                    .clickonNextforsetupautopayBanking()
                    //.verifyAutopaybankDetails()
                    .clickOnManagePaymentsMethod()
                    .verifyExistingAutopayBankDetails()
                    //.verifyAutopayEnabledBankExistingAcc_CAD()
                    .backToBilling()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .DeleteAutopayEnabledBankExistingAcc()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay();//.backtobillingFromAutopay();
            BackToBillingPage();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .ExistingBankAcc()
                    //.RountingNumber()
                    // .AccountNumber()
                    //.NextButton()
                    // .CheckBox()
                    .clickonNextforsetupautopayBanking()
                    //.verifyAutopaybankDetails()
                    .verifyExistingAutopayBankDetails()
                    .verifyAutopayEnabledBankExistingAcc()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .DeleteAutopayEnabledBankExistingAcc()
                    .BackToBillingPage()
                    .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }

    public BillingPage DeleteAutoPayExistingBank_CAD() throws IOException, InterruptedException {
        Thread.sleep(7000);
        waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
        if (driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Set up autopay")
                ||driver.findElement(By.xpath("//span[contains(text(),'Set up autopay') or contains(text(),'Turn on autopay') or contains(text(),'Manage autopay')]")).getText().contains("Turn on autopay"))
        {
            System.out.println("Setup autopay is visible");
            ExtentLogger.pass("Setup autopay is visible", true);
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();
                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }

            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .ExistingBankAcc()
                    //.RountingNumber()
                    // .AccountNumber()
                    //.NextButton()
                    // .CheckBox()
                    .clickonNextforsetupautopayExiBanking_CAN()
                    //.verifyAutopaybankDetails()
                    .clickOnManagePaymentsMethod()
                    .verifyExistingAutopayBankDetails_CAD()
                    //.verifyAutopayEnabledBankExistingAcc_CAD()
                    .backToBilling()
                   // .verifyStatusOfInvoiceAsPaymentPending()
                    .DeleteAutopayEnabledBankExistingAcc_CAD()
                    .BackToBillingPage();
                  // .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);

            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(2000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        } else {
            System.out.println("Manage autopay is visible");
            ExtentLogger.pass("Manage autopay is visible", true);
            ManageAutoPay();//.backtobillingFromAutopay();
            BackToBillingPage();
            Thread.sleep(10000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            List<String> openInvoices = new ArrayList<String>();
            List<String> pastDue = new ArrayList<String>();
            boolean a = true;
            while (a) {

                List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
                int i = 1, j = 1, k = 1;
                for (WebElement e : list1) {
                    Thread.sleep(3000);
                    if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Payment pending")) {
                        System.out.println("Status is not Payment pending");
                        ExtentLogger.pass("Status is not Payment pending", true);
                        String value = "";
                        Thread.sleep(3000);
                        if (driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                            System.out.println("Past due");
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a)[" + j + "]")).getText();
                            pastDue.add(value);
                            j++;
                        } else {

                            System.out.println("Open");
                            //value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/th[1])[" + k + "]")).getText();
                            System.out.println("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th");
                            value = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]//ancestor::tr//th")).getText();

                            openInvoices.add(value);
                            k++;
                        }

                    } else {
                        System.out.println("Status is Payment pending");
                        ExtentLogger.pass("Status is Payment pending", true);
                        j++;

                    }

                    i++;

                }
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    break;
                }
            }
            for (String value : pastDue) {
                System.out.println("Invoice number with status  as Past due " + value);
                ExtentLogger.pass("Invoice number with status  as Past due " + value, true);
            }

            for (String s : openInvoices) {
                System.out.println("Invoice number with status  as open Invoices " + s);
                ExtentLogger.pass("Invoice number with status  as open Invoices " + s, true);

            }
            clickOnSetUpAutoPay()
                    // .AutoPay()
                    .ExistingBankAcc()
                    //.RountingNumber()
                    // .AccountNumber()
                    //.NextButton()
                    // .CheckBox()
                    .clickonNextforsetupautopayExiBanking_CAN()
                    //.verifyAutopaybankDetails()
                    .verifyExistingAutopayBankDetails()
                    .verifyAutopayEnabledBankExistingAcc()
                    .verifyStatusOfInvoiceAsPaymentPending()
                    .DeleteAutopayEnabledBankExistingAcc()
                    .BackToBillingPage();
                   // .SetUpAutoPayVisible();

            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < pastDue.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']")).isDisplayed();
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']/ancestor::tr//td[5]/span")).getText().trim();
                            System.out.println("Checking value of past due " + pastDue.get(i));
                            ExtentLogger.pass("Checking value of past due " + pastDue.get(i), true);
                            Assert.assertEquals(temp, "Past due");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException e) {

                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1]/a[text()='" + pastDue.get(i) + "']", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException ex) {
                            System.out.println("next button is not visible " + ex.getMessage());
                            break;
                        }
                    }
                }

            }
            driver.navigate().refresh();
            waitForPageLoad();
            Thread.sleep(8000);
            waitTillElemenetVisibleByxpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]");
            for (int i = 0; i < openInvoices.size(); i++) {
                boolean b = true;
                while (b) {
                    Thread.sleep(3000);
                    try {
                        Thread.sleep(3000);
                        b = !driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']")).isDisplayed();
                        System.out.println("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']");
                        if (b == false) {
                            String temp = driver.findElement(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]")).getText().trim();
                            System.out.println("Checking value of open invoices " + openInvoices.get(i));
                            ExtentLogger.pass("Checking value of open invoices " + openInvoices.get(i), true);
                            Assert.assertEquals(temp, "Open");
                            driver.navigate().refresh();
                            waitForPageLoad();
                            Thread.sleep(5000);
                            break;
                        }
                    } catch (NoSuchElementException ex) {
                        try {
                            Thread.sleep(3000);
                             if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {               ExtentLogger.pass("Next button is disabled", true);
                                ExtentLogger.pass("//table[@class='tr-DataGrid-table']/tbody/tr/th[1][text()='" + openInvoices.get(i) + "']/ancestor::tr//td[5]", true);
                                Assert.assertTrue(false);
                                break;
                            } else {
                                driver.findElement(By.xpath("//span[text()='Next']")).click();
                                ExtentLogger.pass("Clicked on Next button", true);
                                Thread.sleep(3000);
                            }
                        } catch (NoSuchElementException e) {
                            System.out.println("next button is not visible " + e.getMessage());
                            break;
                        }
                    }
                }

            }


        }
        return this;

    }



    public BillingPage NoPaymentDue() throws IOException {
        waitTillElemenetVisible("NoPaymentDue");
        Boolean warningtext2 = IsElementdisplayed(getElementByXpath("NoPaymentDue"));
        Assert.assertTrue(warningtext2);
        ExtentLogger.pass("No payment due in heading is successfully validated.", true);

        return this;
    }

    String firstNameUnAuth = "";
    String lastNameUnAuth = "";
    String emailUnAuth = "";

    public BillingPage enterDetailsUnAuth() throws InterruptedException, IOException {

        waitUntilVisible("firstNameUnAuth", "xpath", 30);
        clickElement(getElementByXpath("firstNameUnAuth"));
        firstNameUnAuth = fake.name().firstName();
        firstNameUnAuth = firstNameUnAuth.replaceAll("'", "");
        sendKeysTotheElement("firstNameUnAuth", firstNameUnAuth);
        lastNameUnAuth = fake.name().lastName();
        lastNameUnAuth = lastNameUnAuth.replaceAll("'", "");
        sendKeysTotheElement("lastNameUnAuth", lastNameUnAuth);
        System.out.println("Last Name is " + lastNameUnAuth);
        emailUnAuth = firstNameUnAuth + lastNameUnAuth + "@yopmail.com";
        sendKeysTotheElement("emailUnAuth", emailUnAuth);
        System.out.println("Email is " + emailUnAuth);
        ExtentLogger.pass("Details entered- " + firstNameUnAuth + " " + lastNameUnAuth + " , " + emailUnAuth, true);

        clickElement(getElementByXpath("NextUnAuth1"));


        return this;

    }


    public BillingPage UnAuthRountingNumber() throws InterruptedException, IOException {
        waitForPageLoad();
        //waitUntilVisible("BankAccount", "xpath", 30);
        //driver.switchTo().frame(driver.findElement(By.cssSelector(".tr-ManagePaymentAddDialog-dialogContent")));

        waitTillElemenetVisible("RoutingNumberUnAuth");
        clickElement(getElementByXpath("RoutingNumberUnAuth"));
        sendKeysTotheElement("RoutingNumberUnAuth", description1);
        System.out.println("RountingNum=" + description1);
        RountingNumDuplicate = description1;

        ExtentLogger.pass("Routing Number is " + description1, true);

        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }


    public BillingPage UnAuthAccountNumber() throws InterruptedException, IOException {
        waitForPageLoad();

        waitTillElemenetVisible("AccountNumberUnAuth");
        clickElement(getElementByXpath("AccountNumberUnAuth"));
        sendKeysTotheElement("AccountNumberUnAuth", description2);
        System.out.println("AccountNum=" + description2);
        ExtentLogger.pass("Account Number is " + description2, true);

        AccNumDuplicate = description2;
        lastFourDigitBanking = description2;
        lastFourDigitBanking = lastFourDigitBanking.substring(lastFourDigitBanking.length() - 4);
        System.out.println("Last 4 digit number is " + lastFourDigitBanking);
        ExtentLogger.pass("Last 4 digit number is " + lastFourDigitBanking, true);
        // clickElement(getElementByXpath("NextUnAuth2"));


        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }

    public BillingPage clickonNextforsetupautopayUnAuth() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically prior to the due date.') ]")).isDisplayed();
                    boolean UnAuthConfirmationMessage = driver.findElement(By.xpath("//*[contains(text(),'e all set with autopay')]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3 && UnAuthConfirmationMessage) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                 /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }
    public BillingPage clickonNextforsetupautopayUnAuth_ANZ() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically on or after the due date.') ]")).isDisplayed();
                    boolean UnAuthConfirmationMessage = driver.findElement(By.xpath("//*[contains(text(),'e all set with autopay')]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3 && UnAuthConfirmationMessage) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage clickonNextforsetupautopayUnAuth_LRA() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically on or after the due date.') ]")).isDisplayed();
                    boolean UnAuthConfirmationMessage = driver.findElement(By.xpath("//*[contains(text(),'e all set with autopay')]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3 && UnAuthConfirmationMessage) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage clickonNextforsetupautopayUnAuth_CARS() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("CheckTnC", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("CheckTnC"))) {
                    waitTillElemenetVisible("CheckTnC");
                    clickElement(getElementByXpath("CheckTnC"));
                    ExtentLogger.pass("Agree terms and conditions", true);
                    Thread.sleep(1000);
                    waitUntilVisible("Confirm", "xpath", 45);
                    clickElement(getElementByXpath("Confirm"));
                    Thread.sleep(7000);
                    waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);
                    boolean ConfirmationMessage1 = false;
                    boolean ConfirmationMessage3 = false;
                    try {
                        ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thanks for setting up autopay.')]")).isDisplayed();
                    } catch (NoSuchElementException e) {
                        ConfirmationMessage3 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for updating your autopay method.')]")).isDisplayed();

                    }
                    boolean ConfirmationMessage2 = driver.findElement(By.xpath("//*[contains(text(),'Your future invoices will be paid automatically by the due date.') ]")).isDisplayed();
                    boolean UnAuthConfirmationMessage = driver.findElement(By.xpath("//*[contains(text(),'e all set with autopay')]")).isDisplayed();

                    if (ConfirmationMessage1 || ConfirmationMessage3 && UnAuthConfirmationMessage) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Autopay enrollment message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage UnAuthSignInLink() {
        waitTillElemenetVisible("SignInLinkUnAuth");
        clickElement(getElementByXpath("SignInLinkUnAuth"));
        return this;

    }

    public BillingPage UnAuthProfileSignInLink() throws IOException {
        waitTillElemenetVisible("ProfileSignIn");
        ExtentLogger.pass("Clicking on Profile sign in button", true);
        clickElement(getElementByXpath("ProfileSignIn"));

        return this;


    }
    public BillingPage UnAuthProfileSignInLinkBelow() throws IOException {
        waitTillElemenetVisible("SignInUnAuthBelow");
        ExtentLogger.pass("Clicking on signing in button below", true);
        clickElement(getElementByXpath("SignInUnAuthBelow"));

        return this;


    }
    public BillingPage validateLinksInSignInPageUnAuth() throws IOException {
        waitForPageLoad();
        waitTillElemenetVisible("LegalHeadingUnAuth");
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("MyAccountHeadingUnAuth")));
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("MyAccountLegalUnAuth")));
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("MyAccountTaxUnAuth")));
        Assert.assertEquals(driver.getTitle(),"My Account");
        Assert.assertEquals(driver.getCurrentUrl(),"https://stg.myaccount.thomsonreuters.com/");
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("USLegalProductLink")));
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("AustraliaNewZealandLink")));
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("CanadaLink")));
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("UKILegalLink")));
       ExtentLogger.pass("All the links verified, URL is 'https://stg.myaccount.thomsonreuters.com/' and title is 'My Account'", true);
        return this;
    }
    public BillingPage clickOnUSLegalProductLinkUnAuth() throws IOException {
        waitTillElemenetVisible("LegalHeadingUnAuth");
        clickElement(getElementByXpath("USLegalProductLink"));
        ExtentLogger.pass("Clicking on USLegalProduct Link", true);
        return this;
    }
    public BillingPage clickOnAustraliaNewZealandLinkUnAuth() throws IOException {
        waitTillElemenetVisible("LegalHeadingUnAuth");
        clickElement(getElementByXpath("AustraliaNewZealandLink"));
        ExtentLogger.pass("Clicking on AustraliaNewZealand Link", true);
        return this;
    }
    public BillingPage clickOnCanadaLinkUnAuth() throws IOException {
        waitTillElemenetVisible("LegalHeadingUnAuth");
        clickElement(getElementByXpath("CanadaLink"));
        ExtentLogger.pass("Clicking on Canada Link", true);
        return this;
    }
    public BillingPage clickOnUKILegalLinkUnAuth() throws IOException {
        waitTillElemenetVisible("LegalHeadingUnAuth");
        clickElement(getElementByXpath("UKILegalLink"));
        ExtentLogger.pass("Clicking on UKILegal Link", true);
        return this;
    }
    public BillingPage navigateBack(){
        driver.navigate().back();
        waitForPageLoad();
        return this;
    }
    public BillingPage validateUSLUnAuthLink() throws IOException {
        waitForPageLoad();
        waitTillElemenetVisible("MyAccountUnAuthUSL");
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("SigninUsingOnepassUnAuthUSL")));
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("TRLogo")));
        Assert.assertEquals(driver.getTitle(),"My Account | Thomson Reuters");
        ExtentLogger.pass("Texts are verified and the Title is 'My Account | Thomson Reuters'", true);


        return this;


    }

    public BillingPage validateCARSUnAuthLink() throws IOException {
        waitForPageLoad();
        waitTillElemenetVisible("MyAccountUnAuthCARS");
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("SigninUsingOnepassUnAuthUSL")));
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("TRLogo")));
        Assert.assertEquals(driver.getTitle(),"MyAccount Canada Signon");
        ExtentLogger.pass("Texts are verified and the Title is 'MyAccount Canada Signon'", true);


        return this;


    }
    public BillingPage validateUKIUnAuthLink() throws IOException {
        waitForPageLoad();
        waitTillElemenetVisible("MyAccountUnAuthUKI");
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("SigninUsingOnepassUnAuthUSL")));
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("TRLogo")));
        Assert.assertEquals(driver.getTitle(),"My Account – UKI Legal Signon");
        ExtentLogger.pass("Texts are verified and the Title is 'My Account – UKI Legal Signon'", true);


        return this;


    }
    public BillingPage validateBKRSUnAuthLink() throws IOException {
        waitForPageLoad();
        waitTillElemenetVisible("MyAccountUnAuthBKRS");
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("SigninUsingOnepassUnAuthUSL")));
        Assert.assertTrue(IsElementdisplayed(getElementByXpath("TRLogo")));
        Assert.assertEquals(driver.getTitle(),"MyAccount Global Signon");
        ExtentLogger.pass("Texts are verified and the Title is 'MyAccount Global Signon'", true);


        return this;


    }
    public BillingPage UnAuthSignInProfile() throws IOException {
        waitTillElemenetVisible("ProfileSignIn");
        clickElement(getElementByXpath("ProfileSignIn"));
        ExtentLogger.pass("Clicking on sign in button", true);
        return this;

    }


    public BillingPage enterEmailIDinAccount(String username, String emailID) throws InterruptedException, IOException {


        try {
            waitTillElemenetVisible("SignintoTaxNewXpath");
            clickElement(getElementByXpath("SignintoTaxNewXpath"));
            ExtentLogger.pass("Sign into tax link was  available", true);
        } catch (Exception e) {
            ExtentLogger.pass("New UI is not available", true);
        }
        try {
            clickOnUserNameTextBox(emailID).clickOnGoToAccount();
            waitTillElemenetVisible("LegalLink");
            clickElement(getElementByXpath("LegalLink"));
            ExtentLogger.pass("Sign into Legal link was  available", true);
        } catch (Exception e) {
            ExtentLogger.pass("Old UI is not available", true);
        }
        try {
            waitTillElemenetVisible("LegalLink");
            clickElement(getElementByXpath("LegalLink"));
        }
        catch (Exception e) {
            ExtentLogger.pass("LegalLink is not available", true);
        }
        waitTillElemenetVisible("UserNameEmail");
        clickElement(getElementByXpath("UserNameEmail"));
        sendKeysTotheElement("UserNameEmail", username);
        //clickElement(getElementByXpath("Continue"));
        ExtentLogger.pass("Enter the username" + username, true);
        return this;

    }

    public BillingPage clickOnGoToAccount() throws InterruptedException, IOException {

        clickElement(getElementByXpath("AccountSIgnInButton"));
        ExtentLogger.pass("Click on Go to Account", true);
        return this;
    }

    public BillingPage clickOnUserNameTextBox(String emailID) throws InterruptedException, IOException {
        //Thread.sleep(3000);
        try {
            waitTillElemenetVisible("EmailTextBox");
            clickElement(getElementByXpath("EmailTextBox"));
            sendKeysTotheElement("EmailTextBox", emailID);
            ExtentLogger.pass("Entering the username", true);
            clickOnGoToAccount();
            // validateInvalidEmailID();
        } catch (Exception e) {
            //ExtentLogger.pass("UI is updated hence this usecase is invalid" , true);
        }
        return this;
    }

    public BillingPage enterPasswordinAccount(String password) throws InterruptedException, IOException {

        waitTillElemenetVisible("PasswordBP");
        clickElement(getElementByXpath("PasswordBP"));
        sendKeysTotheElement("PasswordBP", password);
        clickElement(getElementByXpath("Continue"));
        //ExtentLogger.pass("Enter the password", true);
        return this;

    }

    public BillingPage validateLoginfunctionality() throws InterruptedException, IOException {
        try {
            waitTillElemenetVisible("SupportTab");
            Boolean b = driver.findElement(By.xpath("//a[@aria-label='Support page']")).isDisplayed();
            Assert.assertTrue(b);
            ExtentLogger.pass("Login functionality is validated", true);

        } catch (Exception e) {
            ExtentLogger.pass("Login functionality validation failed", true);
            log.error(e);
        }
        return this;
    }

    public BillingPage ClickOnConfirmUnAuth() throws InterruptedException, IOException {
        ExtentLogger.pass("Autopay details entered", true);
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(3000);
        waitUntilVisible("ClickOnNext2", "xpath", 30);
        clickElement(getElementByXpath("ClickOnNext2"));
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(7000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("creditCardIframe");
        System.out.println("1st frame");
       driver.switchTo().frame("challengeFrame");
        System.out.println("2nd frame");
        Thread.sleep(3000);
        ExtentLogger.pass("Clicking on the pop up", true);
        driver.findElement(By.xpath("//input[@value='Submit']")).click();
        Thread.sleep(3000);
        driver.switchTo().defaultContent();
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0,1500)");
        Thread.sleep(3000);
        waitUntilVisible("CheckTnC", "xpath", 45);
        clickElement(getElementByXpath("CheckTnC"));
        ExtentLogger.pass("Agree terms and conditions", true);
        Thread.sleep(1000);
        waitUntilVisible("Confirm", "xpath", 30);
        clickElement(getElementByXpath("Confirm"));
        return this;
    }

    public BillingPage ClickOnConfirmUnAuth_ANZanother() throws InterruptedException, IOException {
        ExtentLogger.pass("Autopay details entered", true);
        Thread.sleep(1000);
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(3000);
        waitUntilVisible("ClickOnNext2", "xpath", 30);
        clickElement(getElementByXpath("ClickOnNext2"));
        js.executeScript("window.scrollBy(0,600)");
        Thread.sleep(7000);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("creditCardIframe");
        System.out.println("1st frame");
       /*driver.switchTo().frame("challengeFrame");
        System.out.println("2nd frame");
        Thread.sleep(3000);
        ExtentLogger.pass("Clicking on the pop up", true);
        driver.findElement(By.xpath("//input[@value='Submit']")).click();
        Thread.sleep(3000);
        driver.switchTo().defaultContent();*/
        driver.switchTo().defaultContent();
        Thread.sleep(6000);
        js.executeScript("window.scrollBy(0,3000)");
        Thread.sleep(3000);
        waitUntilVisible("CheckTnC", "xpath", 45);
        clickElement(getElementByXpath("CheckTnC"));
        ExtentLogger.pass("Agree terms and conditions", true);
        Thread.sleep(1000);
        waitUntilVisible("Confirm", "xpath", 30);
        clickElement(getElementByXpath("Confirm"));
        return this;
    }

    public BillingPage getPastDueVerify(HomePage homePage) throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("PastDuePaymentPage");

        String text = driver.findElement(By.xpath("//label[@for='PAST']//b")).getText();
        text = text.trim();

        System.out.println(text);
        Assert.assertEquals(text, homePage.pastDueAmount);
        ExtentLogger.pass("Past due amount is verified", true);
        clickElement(getElementByXpath("PastDuePaymentPage"));
        Thread.sleep(2000);

        clickElement(getElementByXpath("NextUnAuth1"));
        return this;
    }
    public BillingPage getPastDueVerify_USL(Home_UnAuth home_unAuth) throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("PastDuePaymentPage");

        String text = driver.findElement(By.xpath("//label[@for='PAST']//b")).getText();
        text = text.trim();

        System.out.println(text);
        Assert.assertEquals(text, home_unAuth.pastDueAmountverify);
        ExtentLogger.pass("Past due amount is verified", true);
        clickElement(getElementByXpath("PastDuePaymentPage"));
        Thread.sleep(2000);

        clickElement(getElementByXpath("NextUnAuth1"));
        return this;
    }


    String pastDueAmount_TA61="";
    public BillingPage getPastDueVerify_TA61() throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("PastDuePaymentPage");

        String text = driver.findElement(By.xpath("//label[@for='PAST']//b")).getText();
        pastDueAmount_TA61 = text.trim();

        System.out.println(text);
       // Assert.assertEquals(text, pastDueAmount_TA61);
        ExtentLogger.pass("Past due amount is Stored", true);
        clickElement(getElementByXpath("PastDuePaymentPage"));
        Thread.sleep(2000);

        clickElement(getElementByXpath("NextUnAuth1"));
        return this;
    }


    public BillingPage clickOnPastDueLRA() throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("PastDuePaymentPage");

        clickElement(getElementByXpath("PastDuePaymentPage"));
        Thread.sleep(2000);

        clickElement(getElementByXpath("NextUnAuth1"));
        return this;
    }

    public BillingPage getTotalDueVerify(HomePage homePage) throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("TotalDuePaymentPage");

        String text = driver.findElement(By.xpath("//*[contains(text(),'Total')]/b")).getText();
        text = text.trim();

        System.out.println(text);
        Assert.assertEquals(text, homePage.totalDueAmount);
        ExtentLogger.pass("Total due amount is verified", true);
        clickElement(getElementByXpath("TotalDuePaymentPage"));
        Thread.sleep(2000);

        clickElement(getElementByXpath("NextUnAuth1"));
        return this;
    }
    public BillingPage getTotalDueVerify_USL(HomePage homePage) throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("TotalDuePaymentPage");

        String text = driver.findElement(By.xpath("//*[contains(text(),'Total')]/b")).getText();
        text = text.trim();

        System.out.println(text);
        Assert.assertEquals(text, homePage.totalDueAmount);
        ExtentLogger.pass("Total due amount is verified", true);
        clickElement(getElementByXpath("TotalDuePaymentPage"));
        Thread.sleep(2000);

        clickElement(getElementByXpath("NextUnAuth1"));
        return this;
    }
    String totalDueAmount_TA61="";
    public BillingPage getTotalDueVerify_TA61() throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("TotalDuePaymentPage");

        String text = driver.findElement(By.xpath("//*[contains(text(),'Total')]/b")).getText();
        totalDueAmount_TA61 = text.trim();

        System.out.println(text);
       // Assert.assertEquals(text, homePage.totalDueAmount);
        ExtentLogger.pass("Total due amount is Stored", true);
        clickElement(getElementByXpath("TotalDuePaymentPage"));
        Thread.sleep(2000);

        clickElement(getElementByXpath("NextUnAuth1"));
        return this;
    }
    public BillingPage clickOnTotalDue() throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("TotalDuePaymentPage");


        clickElement(getElementByXpath("TotalDuePaymentPage"));
        Thread.sleep(2000);

        clickElement(getElementByXpath("NextUnAuth1"));
        return this;
    }

    String emailIdUnAuth = "";
    String confirmationNumber = "";

    public BillingPage clickonNextforpaymentUnAuth() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(7000);
                driver.switchTo().defaultContent();
                driver.switchTo().frame("creditCardIframe");
                System.out.println("1st frame");
                driver.switchTo().frame("redirectTo3ds1Frame");
                System.out.println("2nd frame");
                Thread.sleep(3000);
                ExtentLogger.pass("Clicking on the pop up", true);
                driver.findElement(By.xpath("//input[@value='Submit']")).click();
                Thread.sleep(3000);
                driver.switchTo().defaultContent();
                js.executeScript("window.scrollBy(0,1500)");
                Thread.sleep(3000);
                waitUntilVisible("Confirm", "xpath", 45);
                emailIdUnAuth = fake.name().firstName() + fake.name().lastName() + "@yopmail.com";
                sendKeysTotheElement("EmailIdUnAuthPayment", emailIdUnAuth);
                ExtentLogger.pass("Email id entered is " + emailIdUnAuth, true);
                Thread.sleep(2000);
                clickElement(getElementByXpath("Confirm"));
                ExtentLogger.pass("Clicking on confirm", true);

                waitUntilVisible("UnAuthPaymentConfirmation", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("UnAuthPaymentConfirmation"))) {
                    Thread.sleep(1000);

                    // waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    //Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);

                    waitTillElemenetVisible("UnAuthPaymentConfirmation");
                    Thread.sleep(10000);
                    boolean ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for your payment')]")).isDisplayed();
                    String ConfirmationMessage2 = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p")).getText().trim();
                    System.out.println("Message is " + ConfirmationMessage2);
                    Assert.assertTrue(ConfirmationMessage2.contains("Your payment of") && ConfirmationMessage2.contains("will be processed within 1 to 2 business days."));
                   // String amount = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p/span")).getText().trim();

                   // System.out.println("Amount is " + amount);
                   // Assert.assertTrue(amount.contains(home.pastDueAmount));
                   // ExtentLogger.pass("Amount in the confirmation page is "+amount,true);

                    String conNumber = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p[2]")).getText().trim();
                    confirmationNumber = conNumber.split("is")[1].trim();
                    ExtentLogger.pass("Confirmation number is " + confirmationNumber, true);

                    System.out.println("confirmationNumber is " + confirmationNumber);

                    if (ConfirmationMessage1) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    //Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                driver.findElement(By.xpath("//button[text()='Back']")).click();
                Thread.sleep(3000);
                System.out.println(e.getMessage());
                 /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage clickonNextforpaymentUnAuthBank() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");

                waitUntilVisible("Confirm", "xpath", 45);
                emailIdUnAuth = fake.name().firstName() + fake.name().lastName() + "@yopmail.com";
                sendKeysTotheElement("EmailIdUnAuthPayment", emailIdUnAuth);
                ExtentLogger.pass("Email id entered is " + emailIdUnAuth, true);
                Thread.sleep(2000);
                clickElement(getElementByXpath("Confirm"));
                ExtentLogger.pass("Clicking on confirm", true);

                waitUntilVisible("UnAuthPaymentConfirmation", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("UnAuthPaymentConfirmation"))) {
                    Thread.sleep(1000);

                    // waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    //Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);

                    waitTillElemenetVisible("UnAuthPaymentConfirmation");
                    Thread.sleep(10000);
                    boolean ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for your payment')]")).isDisplayed();
                    String ConfirmationMessage2 = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p")).getText().trim();
                    System.out.println("Message is " + ConfirmationMessage2);
                    Assert.assertTrue(ConfirmationMessage2.contains("Your payment of") && ConfirmationMessage2.contains("will be processed within 1 to 2 business days."));
                   // String amount = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p/span")).getText().trim();

                   // System.out.println("Amount is " + amount);
                   // ExtentLogger.pass("Amount in the confirmation page is "+amount,true);
                    // Assert.assertTrue(amount.contains(home.pastDueAmount));

                    String conNumber = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p[2]")).getText().trim();
                    confirmationNumber = conNumber.split("is")[1].trim();
                    ExtentLogger.pass("Confirmation number is " + confirmationNumber, true);

                    System.out.println("confirmationNumber is " + confirmationNumber);

                    if (ConfirmationMessage1) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    //Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                driver.findElement(By.xpath("//button[text()='Back']")).click();
                Thread.sleep(3000);
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage clickonNextforpaymentUnAuthLRA() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("Confirm", "xpath", 45);
                emailIdUnAuth = fake.name().firstName() + fake.name().lastName() + "@yopmail.com";
                sendKeysTotheElement("EmailIdUnAuthPayment", emailIdUnAuth);
                ExtentLogger.pass("Email id entered is " + emailIdUnAuth, true);
                Thread.sleep(2000);
                clickElement(getElementByXpath("Confirm"));
                ExtentLogger.pass("Clicking on confirm", true);

                waitUntilVisible("UnAuthPaymentConfirmation", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("UnAuthPaymentConfirmation"))) {
                    Thread.sleep(1000);

                    // waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    //Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);

                    waitTillElemenetVisible("UnAuthPaymentConfirmation");
                    Thread.sleep(10000);
                    boolean ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for your payment')]")).isDisplayed();
                    String ConfirmationMessage2 = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p")).getText().trim();
                    System.out.println("Message is " + ConfirmationMessage2);
                    Assert.assertTrue(ConfirmationMessage2.contains("Your payment of") && ConfirmationMessage2.contains("will be processed within 1 to 2 business days."));
                    String amount = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p/span")).getText().trim();

                    System.out.println("Amount is " + amount);
                    ExtentLogger.pass("Amount is " + amount, true);

                    String conNumber = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p[2]")).getText().trim();
                    confirmationNumber = conNumber.split("is")[1].trim();
                    ExtentLogger.pass("Confirmation number is " + confirmationNumber, true);

                    System.out.println("confirmationNumber is " + confirmationNumber);

                    if (ConfirmationMessage1) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    //Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                driver.findElement(By.xpath("//button[text()='Back']")).click();
                Thread.sleep(3000);
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }


    public BillingPage clickonNextforpaymentUnAuthLRAInvoice(String excelAmount) throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("Confirm", "xpath", 45);
                emailIdUnAuth = fake.name().firstName() + fake.name().lastName() + "@yopmail.com";
                sendKeysTotheElement("EmailIdUnAuthPayment", emailIdUnAuth);
                ExtentLogger.pass("Email id entered is " + emailIdUnAuth, true);
                Thread.sleep(2000);
                clickElement(getElementByXpath("Confirm"));
                ExtentLogger.pass("Clicking on confirm", true);

                waitUntilVisible("UnAuthPaymentConfirmation", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("UnAuthPaymentConfirmation"))) {
                    Thread.sleep(1000);

                    // waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    //Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);

                    waitTillElemenetVisible("UnAuthPaymentConfirmation");
                    Thread.sleep(10000);
                    boolean ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for your payment')]")).isDisplayed();
                    String ConfirmationMessage2 = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p")).getText().trim();
                    System.out.println("Message is " + ConfirmationMessage2);
                    Assert.assertTrue(ConfirmationMessage2.contains("Your payment of") && ConfirmationMessage2.contains("will be processed within 1 to 2 business days."));
                   // String amount = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p/span")).getText().trim();

                   // System.out.println("Amount is " + amount);
                   // Assert.assertTrue(amount.contains(excelAmount));
                  //  ExtentLogger.pass("Amount is " + amount, true);


                    String conNumber = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p[2]")).getText().trim();
                    confirmationNumber = conNumber.split("is")[1].trim();
                    ExtentLogger.pass("Confirmation number is " + confirmationNumber, true);

                    System.out.println("confirmationNumber is " + confirmationNumber);

                    if (ConfirmationMessage1) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    //Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                driver.findElement(By.xpath("//button[text()='Back']")).click();
                Thread.sleep(3000);
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage clickonNextforpaymentUnAuthTotal(HomePage home) throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(7000);
                driver.switchTo().defaultContent();
                driver.switchTo().frame("creditCardIframe");
                System.out.println("1st frame");
                driver.switchTo().frame("redirectTo3ds1Frame");
                System.out.println("2nd frame");
                Thread.sleep(3000);
                ExtentLogger.pass("Clicking on the pop up", true);
                driver.findElement(By.xpath("//input[@value='Submit']")).click();
                Thread.sleep(3000);
                driver.switchTo().defaultContent();
                js.executeScript("window.scrollBy(0,1500)");
                Thread.sleep(3000);
                waitUntilVisible("Confirm", "xpath", 45);
                emailIdUnAuth = fake.name().firstName() + fake.name().lastName() + "@yopmail.com";
                clickElement(getElementByXpath("EmailIdUnAuthPayment"));
                driver.findElement(By.xpath("//input[@id='email']")).clear();
                sendKeysTotheElement("EmailIdUnAuthPayment", emailIdUnAuth);
                ExtentLogger.pass("Email id entered is " + emailIdUnAuth, true);
                Thread.sleep(2000);
                clickElement(getElementByXpath("Confirm"));
                ExtentLogger.pass("Clicking on confirm", true);

                waitUntilVisible("UnAuthPaymentConfirmation", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("UnAuthPaymentConfirmation"))) {
                    Thread.sleep(1000);

                    // waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    //Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);

                    waitTillElemenetVisible("UnAuthPaymentConfirmation");
                    Thread.sleep(10000);
                    boolean ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for your payment')]")).isDisplayed();
                    String ConfirmationMessage2 = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p")).getText().trim();
                    System.out.println("Message is " + ConfirmationMessage2);
                    Assert.assertTrue(ConfirmationMessage2.contains("Your payment of") && ConfirmationMessage2.contains("will be processed within 1 to 2 business days."));
                   // String amount = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p/span")).getText().trim();

                   // System.out.println("Amount is " + amount);
                   // Assert.assertTrue(amount.contains(home.totalDueAmount));

                    String conNumber = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p[2]")).getText().trim();
                    confirmationNumber = conNumber.split("is")[1].trim();
                    ExtentLogger.pass("Confirmation number is " + confirmationNumber, true);

                    System.out.println("confirmationNumber is " + confirmationNumber);

                    if (ConfirmationMessage1) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    //Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                js.executeScript("window.scrollBy(0,1000)");
                Thread.sleep(3000);
                WebElement back = driver.findElement(By.xpath("//button[text()='Back']"));
                js.executeScript("arguments[0].click();", back);
                Thread.sleep(3000);
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }


    public BillingPage clickonNextforpaymentUnAuthTotal_TA61() throws InterruptedException, IOException {

        int i = 1;
        while (i < 6) {
            try {
                ExtentLogger.pass("Autopay details entered", true);
                Thread.sleep(1000);
                js.executeScript("window.scrollBy(0,500)");
                Thread.sleep(3000);
                waitUntilVisible("NextUnAuth2", "xpath", 30);
                clickElement(getElementByXpath("NextUnAuth2"));
                js.executeScript("window.scrollBy(0,600)");
                Thread.sleep(3000);
                waitUntilVisible("Confirm", "xpath", 45);
                emailIdUnAuth = fake.name().firstName() + fake.name().lastName() + "@yopmail.com";
                clickElement(getElementByXpath("EmailIdUnAuthPayment"));
                driver.findElement(By.xpath("//input[@id='email']")).clear();
                sendKeysTotheElement("EmailIdUnAuthPayment", emailIdUnAuth);
                ExtentLogger.pass("Email id entered is " + emailIdUnAuth, true);
                Thread.sleep(2000);
                clickElement(getElementByXpath("Confirm"));
                ExtentLogger.pass("Clicking on confirm", true);

                waitUntilVisible("UnAuthPaymentConfirmation", "xpath", 45);
                if (isElementDisplayed(getElementByXpath("UnAuthPaymentConfirmation"))) {
                    Thread.sleep(1000);

                    // waitUntilVisible("BackToAccountUnAuth", "xpath", 80);
                    //Thread.sleep(7000);
                    //waitTillElemenetVisible("BackToBilling");
                    //waitUntilVisible("ThanksForSettingAutopay","xpath",30);

                    waitTillElemenetVisible("UnAuthPaymentConfirmation");
                    Thread.sleep(10000);
                    boolean ConfirmationMessage1 = driver.findElement(By.xpath("//*[contains(text(),'Thank you for your payment')]")).isDisplayed();
                    String ConfirmationMessage2 = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p")).getText().trim();
                    System.out.println("Message is " + ConfirmationMessage2);
                    Assert.assertTrue(ConfirmationMessage2.contains("Your payment of") && ConfirmationMessage2.contains("will be processed within 1 to 2 business days."));
                   // String amount = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p/span")).getText().trim();

                  //  System.out.println("Amount is " + amount);
                   // ExtentLogger.pass("Amount is " + amount, true);

                   // Assert.assertTrue(amount.contains(totalDueAmount_TA61));

                    String conNumber = driver.findElement(By.xpath("//div[@class='tr-PaymentConfirmed-text']/p[2]")).getText().trim();
                    confirmationNumber = conNumber.split("is")[1].trim();
                    ExtentLogger.pass("Confirmation number is " + confirmationNumber, true);

                    System.out.println("confirmationNumber is " + confirmationNumber);

                    if (ConfirmationMessage1) {
                        System.out.println("Message is visible");
                        ExtentLogger.pass("Message is visible successfully", true);

                    } else {
                        System.out.println("Message is not visible");
                        ExtentLogger.pass("Message is not visible", true);
                        Assert.assertTrue(false);

                    }
                    //Assert.assertTrue(ConfirmationMessage1);
                    //Assert.assertTrue(ConfirmationMessage2);
                    ExtentLogger.pass("Message validation completed successfully", true);
                    // waitUntilVisible("BackToBilling", "xpath", 30);
                    //  clickElement(getElementByXpath("BackToBilling"));

                    break;
                }
            } catch (TimeoutException e) {
                js.executeScript("window.scrollBy(0,1000)");
                Thread.sleep(3000);
                WebElement back = driver.findElement(By.xpath("//button[text()='Back']"));
                js.executeScript("arguments[0].click();", back);
                Thread.sleep(3000);
                System.out.println(e.getMessage());
                /* ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
                driver.switchTo().window(tabs.get(1));
                clickOngenrate()
                        .CreditCardNumber();
                driver.switchTo().window(tabs.get(0));*/
                generateCreditCard()
                        .enterCardNumber();
                ExtentLogger.pass("Retrying to add credit card. " + i, true);
                i++;

            }


        }
        if (i == 6) {
            ExtentLogger.pass("Could not add!!", true);
            Assert.assertTrue(false);
        }


        return this;

    }

    public BillingPage verifyStatusOfInvoiceAsNoPastDue() throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("InvoicesTable");
        System.out.println("Invoice table not visible");
        ExtentLogger.pass("Invoice table not visible", true);


        Thread.sleep(4000);
        //String color = driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color");
        // System.out.println(color);
        boolean a = true;
        while (a) {
            List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
            int i = 1;
            for (WebElement e : list1) {
                if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due")) {
                    System.out.println("Status is not past due");
                    ExtentLogger.pass("Status is not past due", true);

                } else {
                    System.out.println("Status is past due");
                    ExtentLogger.pass("Status is past due", true);
                    Assert.assertTrue(false);

                }

                i++;

            }
            try {
                 if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {   break;
                } else {
                    driver.findElement(By.xpath("//span[text()='Next']")).click();
                }
            } catch (NoSuchElementException e) {
                System.out.println("next button is not visible " + e.getMessage());
                break;
            }
        }
        return this;
    }

    public BillingPage verifyStatusOfInvoiceAsNoPastDueNorDue() throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("InvoicesTable");
        Thread.sleep(4000);
        //String color = driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color");
        // System.out.println(color);
        boolean a = true;
        while (a) {
            List<WebElement> list1 = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']/tbody/tr/td[5]"));
            int i = 1;
            for (WebElement e : list1) {
                if (!driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Past due") ||
                        !driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']/tbody/tr/td[5])[" + i + "]")).getText().equalsIgnoreCase("Due")) {
                    System.out.println("Status is not past due nor due");
                    ExtentLogger.pass("Status is not past due nor due", true);

                } else {
                    System.out.println("Status is past due or due");
                    ExtentLogger.pass("Status is past due or due", true);
                    Assert.assertTrue(false);

                }

                i++;

            }
            try {
                 if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {   break;
                } else {
                    driver.findElement(By.xpath("//span[text()='Next']")).click();
                }
            } catch (NoSuchElementException e) {
                System.out.println("next button is not visible " + e.getMessage());
                break;
            }
        }
        return this;
    }


    public BillingPage getInvoiceVerify(HomePage homePage, String invoiceNumber) throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("InvoicePaymentPage");
        clickElement(getElementByXpath("InvoicePaymentPage"));
        Thread.sleep(2000);
        waitTillElemenetVisible("InvoiceTextBox");
        sendKeysTotheElement("InvoiceTextBox", invoiceNumber);
        Thread.sleep(2000);
        String value = driver.findElement(By.xpath("//ul[@class='tr-SpecificInvoiceDetails']//span")).getText().trim();
        Assert.assertEquals(value, homePage.invoiceAmount);

        clickElement(getElementByXpath("NextAuthInvoice"));
        return this;
    }
    String invoiceAmount_TA61="";
    public BillingPage getInvoiceVerify_TA61( String invoiceNumber) throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("InvoicePaymentPage");
        clickElement(getElementByXpath("InvoicePaymentPage"));
        Thread.sleep(2000);
        waitTillElemenetVisible("InvoiceTextBox");
        sendKeysTotheElement("InvoiceTextBox", invoiceNumber);
        Thread.sleep(2000);
        String value = driver.findElement(By.xpath("//ul[@class='tr-SpecificInvoiceDetails']//span")).getText().trim();
        invoiceAmount_TA61=value;
        System.out.println(invoiceAmount_TA61);
        //Assert.assertEquals(value,invoiceAmount_TA61);

        clickElement(getElementByXpath("NextAuthInvoice"));
        return this;
    }

    public BillingPage clickOnVerifyInvoice(String invoiceNumber,String amount) throws InterruptedException, IOException {
        waitForPageLoad();
        waitTillElemenetVisible("InvoicePaymentPage");
        clickElement(getElementByXpath("InvoicePaymentPage"));
        Thread.sleep(2000);
        waitTillElemenetVisible("InvoiceTextBox");
        sendKeysTotheElement("InvoiceTextBox", invoiceNumber);
        Thread.sleep(2000);
        String value = driver.findElement(By.xpath("//ul[@class='tr-SpecificInvoiceDetails']//span")).getText().trim();
        Assert.assertTrue(value.contains(amount));
        clickElement(getElementByXpath("NextAuthInvoice"));
        return this;
    }

    public BillingPage verifyInvoiceStatusUnAuth(String invoiceNumber) throws IOException, InterruptedException {
        waitForPageLoad();
        waitTillElemenetVisible("InvoicesTable");
        Thread.sleep(5000);
        String value="";
        boolean a = true;
        while (a) {
            try {
                value = driver.findElement(By.xpath("//a[text()='" + invoiceNumber + "']/parent::th/parent::tr/td[5]")).getText().trim();
                System.out.println("Status for invoice number " + invoiceNumber + " is " + value);
                ExtentLogger.pass("Status for invoice number " + invoiceNumber + " is " + value, true);
                Assert.assertTrue(value.contains("Payment pending"));
                break;
            } catch (NoSuchElementException ex) {
                System.out.println("Invoice number is not present in first page");
                ExtentLogger.pass("Invoice number is not present in first page", true);
                try {
                     if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")
                ||driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgb(136, 136, 136)"))
                {       break;
                    } else {
                        driver.findElement(By.xpath("//span[text()='Next']")).click();
                    }
                } catch (NoSuchElementException e) {
                    System.out.println("next button is not visible " + e.getMessage());
                    ExtentLogger.pass("Next button is not visible");
                    break;
                }
            }
        }
        if(value.isEmpty()){
            System.out.println("Value is empty");
            ExtentLogger.pass("Value is empty");
            Assert.assertTrue(false);
        }

        return this;
    }


    String sourceCode= fake.regexify("[1-9]{6}");
    public BillingPage UnAuthSourceCode() throws InterruptedException, IOException {
        waitForPageLoad();
        //waitUntilVisible("BankAccount", "xpath", 30);
        //driver.switchTo().frame(driver.findElement(By.cssSelector(".tr-ManagePaymentAddDialog-dialogContent")));

        waitTillElemenetVisible("SourceCodeTextBox");
        clickElement(getElementByXpath("SourceCodeTextBox"));
        sendKeysTotheElement("SourceCodeTextBox", sourceCode);
        System.out.println("Source code is " + sourceCode);
      //  RountingNumDuplicate = description1;

        ExtentLogger.pass("Source code is " + sourceCode, true);

        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }

    String bankAccEightDigit=fake.regexify("[1-9]{8}");

    public BillingPage UnAuthAccountNumberEightDigit() throws InterruptedException, IOException {
        waitForPageLoad();

        waitTillElemenetVisible("AccountNumberUnAuth");
        clickElement(getElementByXpath("AccountNumberUnAuth"));
        sendKeysTotheElement("AccountNumberUnAuth", bankAccEightDigit);
        System.out.println("AccountNum=" + bankAccEightDigit);
        ExtentLogger.pass("Account Number is " + bankAccEightDigit, true);

        //AccNumDuplicate = description2;
        lastFourDigitBanking = bankAccEightDigit;
        lastFourDigitBanking = lastFourDigitBanking.substring(lastFourDigitBanking.length() - 4);
        System.out.println("Last 4 digit number is " + lastFourDigitBanking);
        ExtentLogger.pass("Last 4 digit number is " + lastFourDigitBanking, true);
        // clickElement(getElementByXpath("NextUnAuth2"));


        //Thread.sleep(10000);
        //driver.navigate().refresh();

        return this;
    }



}


