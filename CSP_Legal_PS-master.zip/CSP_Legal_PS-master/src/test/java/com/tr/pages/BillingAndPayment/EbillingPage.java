package com.tr.pages.BillingAndPayment;

import com.github.javafaker.Faker;
import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.hamcrest.core.Is;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;
import java.util.List;

public class EbillingPage extends BasePage_PS {

    public EbillingPage() {
        super("locatorsDefinition/BillingAndPayment/EbillingPage.json");
        PageFactory.initElements(getDriver(), this);
    }
    public EbillingPage clickOnManageBilling() throws InterruptedException, IOException {


        Thread.sleep(5000);
        waitTillElemenetVisible("Manage_Ebilling");
        clickElement(getElementByXpath("Manage_Ebilling"));
        ExtentLogger.pass("Clicking on Manage_Ebilling link", true);
        return this;

    }
    int lastRecordNumber = 0;
    Faker fake = new Faker();
    String firsteblillingName =null;
    String lastebillingName =null;
    String emailId =null;
    public EbillingPage getrecordscount() throws InterruptedException, IOException {
        waitTillElemenetVisible("BillingPagination");
        Boolean b = true;
        while (true) {
            WebElement userNameTxt = driver.findElement(By.xpath("//div[contains(text(),'Viewing')]"));
            System.out.println(userNameTxt);
            JavascriptExecutor js = (JavascriptExecutor) driver;
            String lastRecord = js.executeScript("return arguments[0].innerHTML", userNameTxt).toString();
            System.out.println(lastRecord);
            String d[]=lastRecord.split(" – ");
            lastRecord=d[1];
            lastRecordNumber = Integer.parseInt(lastRecord);
            //lastRecord = lastRecord.substring(lastRecord.indexOf("-") + 1).trim();
            // lastRecordNumber = Integer.parseInt(lastRecord.substring(lastRecord.length() - 2));

            System.out.println("last record is " + lastRecordNumber);
            try{
                b = driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).isEnabled();

            if (b == false)
                break;
            driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).click();
            Thread.sleep(3000);}
            catch(NoSuchElementException e){

                System.out.println("Only 1 page "+e.getMessage());
                break;
            }
        }

        //ExtentLogger.pass("Pagination is set to 100", true);

        return this;
    }

    public EbillingPage Fillcontactdetails(EbillingPage p,String index) throws InterruptedException, IOException {

        p.firsteblillingName = fake.name().firstName();
        p.lastebillingName = fake.name().lastName();
        p.emailId = p.firsteblillingName + p.lastebillingName + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling");
        driver.findElement(By.xpath("(//*[text()='First name']/parent::label/following-sibling::input)["+index+"]")).sendKeys(p.firsteblillingName);
        //sendKeysTotheElement("FirstNameEbilling",p.firsteblillingName);
        waitTillElemenetVisible("LastNameEbilling");
        driver.findElement(By.xpath("(//*[text()='Last name']/parent::label/following-sibling::input)["+index+"]")).sendKeys(p.lastebillingName);
        //clearText(getElementByXpath("LastNameEbilling"));
        //sendKeysTotheElement("LastNameEbilling",p.lastebillingName);
        waitTillElemenetVisible("EmailEbilling");
        driver.findElement(By.xpath("(//*[text()='Email']/parent::label/following-sibling::input)["+index+"]")).sendKeys(p.emailId);
       // clearText(getElementByXpath("EmailEbilling"));
       // sendKeysTotheElement("EmailEbilling", p.emailId);
        ExtentLogger.pass("Entered the first name, last name and Email Address", true);

        return this;

    }

    public EbillingPage Validatecontactsubmission(EbillingPage p,String i) throws InterruptedException, IOException {
       waitTillElemenetVisible("Contact_added");
        Boolean contact_added=IsElementdisplayed(getElementByXpath("Contact_added"));
        Assert.assertTrue(contact_added);
        contact_added=IsElementdisplayed(getElementByXpath("Contact_added_text"));
        Assert.assertTrue(contact_added);
        String contactname=driver.findElement(By.xpath("(//*[@class='tr-ContactManagementSuccess-contactList']//li)["+i+"]")).getText();
        Assert.assertTrue(contactname.contains(p.firsteblillingName));
        Assert.assertTrue(contactname.contains(p.lastebillingName));
        contact_added=IsElementdisplayed(getElementByXpath("Managebilling_button"));
        Assert.assertTrue(contact_added);
        contact_added=IsElementdisplayed(getElementByXpath("Backtobilling_button"));
        Assert.assertTrue(contact_added);
        ExtentLogger.pass("All the details on the contact added successfully alert text are validated, the details are namely first name,lase name,We’ve added these contacts to receive e-billing notifications:,Manage e-billing contacts button & Back to billing button "+p.firsteblillingName+" "+p.lastebillingName, true);
        return this;
    }

    public EbillingPage Validatecontactdetailsinlist(EbillingPage p,int recordsadded) throws InterruptedException, IOException {

        Boolean a= true;
        int i=1;


        //  WebElement userNameTxt = driver.findElement(By.xpath("//div[contains(text(),'Viewing')]"));
        //  System.out.println(userNameTxt);
       /* JavascriptExecutor js = (JavascriptExecutor) driver;
        String lastRecord = js.executeScript("return arguments[0].innerHTML",userNameTxt).toString();
        System.out.println(lastRecord);
        lastRecord=lastRecord.substring(lastRecord.indexOf("-")+1).trim();*/
        p.lastRecordNumber = p.lastRecordNumber + recordsadded;
        System.out.println("Last record number is oncreased by 1. SO new number is "+p.lastRecordNumber);
        waitForPageLoad();
        Thread.sleep(5000);
        boolean result = false;
        while (true) {
            try {
                int size=driver.findElements(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])")).size();
                for(int j=1;j<=size;j++) {
                    WebElement ele = driver.findElement(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])[" + j + "]"));
                    String name = getElementTextbyElement(ele);
                    System.out.println(name);
                    System.out.println(ele);

                    if (name.contains(p.firsteblillingName) && name.contains(p.lastebillingName)) {
                        result = true;
                        ExtentLogger.pass("Newly added ebilling contact is present "+p.firsteblillingName +" "+p.lastebillingName, true);
                        break;
                    }
                }

                if (a == false || result==true)
                    break;
                driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).click();
                a = driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).isEnabled();
                System.out.println("a value is "+a);
                i++;
                System.out.println("value of i is" +i);

            } catch (NoSuchElementException e) {
                System.out.println("inside catch "+e.getMessage());
                a=false;
            }
        }
        Assert.assertTrue(result);
        p.firsteblillingName =p.firsteblillingName.toLowerCase();
        WebElement ele1 = driver.findElement(By.xpath("//tbody[@class='tr-DataGrid-tableBody']//th[contains(text(),'" + p.firsteblillingName + "')]/following-sibling::td[1]"));
        String email = getElementTextbyElement(ele1);
        System.out.println(ele1);
        System.out.println(email);
        Assert.assertEquals(p.emailId, email.trim());
        ExtentLogger.pass("Newly added ebilling contact email is correct "+p.emailId, true);



   /*     for (int i = 1; i <= lastRecordNumber; i++) {
            WebElement ele = driver.findElement(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])["+i+"]"));
            String name = getElementTextbyElement(ele);
            System.out.println(name);
            System.out.println(ele);

            if (name.contains(firsteblillingName) && name.contains(lastebillingName)) {
                result=true;
                ExtentLogger.pass("Newly added ebilling contact is present", true);
                break;
            }

        }
        Assert.assertTrue(result);
        firsteblillingName=firsteblillingName.toLowerCase();
        WebElement ele1 = driver.findElement(By.xpath("//tbody[@class='tr-DataGrid-tableBody']//th[contains(text(),'"+firsteblillingName+"')]/following-sibling::td[1]"));
        String email = getElementTextbyElement(ele1);
        System.out.println(ele1);
        System.out.println(email);
        Assert.assertEquals(emailId,email.trim());*/
        return this;
    }

    public EbillingPage addOneEbillingContact(EbillingPage p) throws InterruptedException, IOException {
        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));
        Thread.sleep(1000);

        p.firsteblillingName = fake.name().firstName();
        p.lastebillingName = fake.name().lastName();
        p.emailId = p.firsteblillingName + p.lastebillingName + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling");
        clearText(getElementByXpath("FirstNameEbilling"));
        sendKeysTotheElement("FirstNameEbilling",p. firsteblillingName);
        waitTillElemenetVisible("LastNameEbilling");
        clearText(getElementByXpath("LastNameEbilling"));
        sendKeysTotheElement("LastNameEbilling",p.lastebillingName);
        waitTillElemenetVisible("EmailEbilling");
        clearText(getElementByXpath("EmailEbilling"));
        sendKeysTotheElement("EmailEbilling", p.emailId);
        ExtentLogger.pass("Entered the first name, last name and Email Address", true);

        waitTillElemenetVisible("SubmitEbillingContact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("SubmitEbillingContact"));
        Thread.sleep(6000);

        Validatecontactsubmission(p,"1");
        waitTillElemenetVisible("ManageEbillingContact");
        ExtentLogger.pass("Click on manage ebilling contact", true);
        Thread.sleep(1000);
        boolean firstnamevalue=driver.findElement(By.xpath("//li[contains(text(),'"+p.firsteblillingName+"')]")).isDisplayed();
        boolean lastnamevalue=driver.findElement(By.xpath("//li[contains(text(),'"+p.lastebillingName+"')]")).isDisplayed();
        Assert.assertTrue(firstnamevalue);
        Assert.assertTrue(lastnamevalue);
        Thread.sleep(1000);
        clickElement(getElementByXpath("ManageEbillingContact"));
        waitTillElemenetVisible("AddEbillingContact");
        Thread.sleep(4000);
        driver.navigate().refresh();
        Validatecontactdetailsinlist(p,1);


        return this;
    }

    public EbillingPage addduplicatedEbillingContact(EbillingPage page) throws InterruptedException, IOException {
        Boolean a = true;
        int i = 1;
        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));
        Thread.sleep(1000);

        waitTillElemenetVisible("FirstNameEbilling");
        clearText(getElementByXpath("FirstNameEbilling"));
        sendKeysTotheElement("FirstNameEbilling", page.firsteblillingName);
        waitTillElemenetVisible("LastNameEbilling");
        clearText(getElementByXpath("LastNameEbilling"));
        sendKeysTotheElement("LastNameEbilling", page.lastebillingName);
        waitTillElemenetVisible("EmailEbilling");
        clearText(getElementByXpath("EmailEbilling"));
        sendKeysTotheElement("EmailEbilling", page.emailId);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("SubmitEbillingContact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("SubmitEbillingContact"));
        Thread.sleep(6000);

        waitTillElemenetVisible("DupContact_warn1");
        Boolean warningtext1= IsElementdisplayed(getElementByXpath("DupContact_warn1"));
        Assert.assertTrue(warningtext1);
        ExtentLogger.pass("Warning one on addition of duplicate contact is successfully validated.", true);
        String color =getElementByXpath("DupContact_warn1_color").getCssValue("border-color");
        Assert.assertEquals(color,"rgb(220, 10, 10)");
        ExtentLogger.pass("Color of warning box 1 is validated...", true);

        Boolean warningtext2= IsElementdisplayed(getElementByXpath("DupContact_warn2"));
        Assert.assertTrue(warningtext2);
        ExtentLogger.pass("Warning two on addition of duplicate contact is successfully validated.", true);
        String color1 =getElementByXpath("DupContact_warn2_color").getCssValue("border-color");
         if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of warning box 2 is validated...", true);
        return this;

    }

    public EbillingPage add5contacts(EbillingPage page) throws InterruptedException, IOException {
        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));
        Thread.sleep(5000);

        Fillcontactdetails(page,"1");
        waitTillElemenetVisible("Addanother_contact");
        clickElement(getElementByXpath("Addanother_contact"));
        Thread.sleep(5000);

        EbillingPage page1=new EbillingPage();
        Fillcontactdetails(page1,"2");
        waitTillElemenetVisible("Addanother_contact");
        clickElement(getElementByXpath("Addanother_contact"));
        Thread.sleep(5000);

        EbillingPage page2=new EbillingPage();
        Fillcontactdetails(page2,"3");
        waitTillElemenetVisible("Addanother_contact");
        clickElement(getElementByXpath("Addanother_contact"));
        Thread.sleep(5000);

        EbillingPage page3=new EbillingPage();
        //Fillcontactdetails(page2,"4");
        page3.firsteblillingName = fake.name().firstName();
        page3.lastebillingName = fake.name().lastName();
        page3.emailId = page3.firsteblillingName + page3.lastebillingName + "@test.com";

        waitTillElemenetVisible("FirstNameEbilling");
        driver.findElement(By.xpath("(//*[text()='First name']/parent::label/following-sibling::input)[4]")).sendKeys(page3.firsteblillingName);
        waitTillElemenetVisible("LastNameEbilling");
        driver.findElement(By.xpath("(//*[text()='Last name']/parent::label/following-sibling::input)[4]")).sendKeys(page3.lastebillingName);
        waitTillElemenetVisible("EmailEbilling");
        driver.findElement(By.xpath("(//*[text()='Email']/parent::label/following-sibling::input)[4]")).sendKeys(page3.emailId);
        ExtentLogger.pass("Entered the first name, last name and Email Address", true);


        waitTillElemenetVisible("Addanother_contact");
        clickElement(getElementByXpath("Addanother_contact"));
        Thread.sleep(5000);



        waitTillElemenetVisible("FirstNameEbilling");
        driver.findElement(By.xpath("(//*[text()='First name']/parent::label/following-sibling::input)[5]")).sendKeys(page3.firsteblillingName);
        waitTillElemenetVisible("LastNameEbilling");
        driver.findElement(By.xpath("(//*[text()='Last name']/parent::label/following-sibling::input)[5]")).sendKeys(page3.lastebillingName);
        waitTillElemenetVisible("EmailEbilling");
        driver.findElement(By.xpath("(//*[text()='Email']/parent::label/following-sibling::input)[5]")).sendKeys(page3.emailId);
        ExtentLogger.pass("Entered the first name, last name and Email Address", true);


        Boolean warningtext3= IsElementdisplayed(getElementByXpath("DupContact_warn3"));
        Assert.assertTrue(warningtext3);
        ExtentLogger.pass("Warning 3 on addition of duplicate contact is successfully validated.", true);
        String color1 =getElementByXpath("DupContact_warn3_color").getCssValue("border-color");
         if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of warning box 3 is validated...", true);

        driver.findElement(By.xpath("(//button[@aria-label='Remove row'])[5]")).click();
        Thread.sleep(3000);
        waitTillElemenetVisible("Addanother_contact");
        clickElement(getElementByXpath("Addanother_contact"));
        Thread.sleep(5000);

        EbillingPage page4=new EbillingPage();
        page4.firsteblillingName = fake.name().firstName();
        page4.lastebillingName = fake.name().lastName();
        page4.emailId = page4.firsteblillingName + page4.lastebillingName + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling");
        driver.findElement(By.xpath("(//*[text()='First name']/parent::label/following-sibling::input)[5]")).clear();
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//*[text()='First name']/parent::label/following-sibling::input)[5]")).sendKeys(page4.firsteblillingName);
        waitTillElemenetVisible("LastNameEbilling");
        driver.findElement(By.xpath("(//*[text()='Last name']/parent::label/following-sibling::input)[5]")).clear();
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//*[text()='Last name']/parent::label/following-sibling::input)[5]")).sendKeys(page4.lastebillingName);
        waitTillElemenetVisible("EmailEbilling");
        driver.findElement(By.xpath("(//*[text()='Email']/parent::label/following-sibling::input)[5]")).clear();
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//*[text()='Email']/parent::label/following-sibling::input)[5]")).sendKeys(page4.emailId);
        ExtentLogger.pass("Entered the first name, last name and Email Address", true);

        String c=driver.findElement(By.xpath("//button[@class='tr-AddContactForm-addAnotherButton']")).getCssValue("color");
        if(c.equalsIgnoreCase("rgba(136, 136, 136, 1)")
                || c.equalsIgnoreCase("rgb(136, 136, 136)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of add another contact button is grey, hence its disabled", true);
        System.out.println("Enabled "+c);
        Thread.sleep(5000);

        waitTillElemenetVisible("Addanother_contact");
        clickElement(getElementByXpath("Addanother_contact"));
        try
        {
            ExtentLogger.pass("Clicking on add another contact button to make sure no new section is getting added as add another contact button is disabled", true);
            driver.findElement(By.xpath("(//*[text()='First name']/parent::label/following-sibling::input)[6]")).click();
        }
        catch(NoSuchElementException exception) {
            ExtentLogger.pass("Exception caught as there was no 6th row after clicking add another contact.", true);
        }

        Thread.sleep(5000);



        System.out.println("Set1 "+page.firsteblillingName);
        System.out.println("Set1 "+page.lastebillingName);
        System.out.println("Set1 "+page.emailId);

        System.out.println("Set2 "+page1.firsteblillingName);
        System.out.println("Set2 "+page1.lastebillingName);
        System.out.println("Set2 "+page1.emailId);

        System.out.println("Set3 "+page2.firsteblillingName);
        System.out.println("Set3 "+page2.lastebillingName);
        System.out.println("Set3 "+page2.emailId);

        System.out.println("Set4 "+page3.firsteblillingName);
        System.out.println("Set4 "+page3.lastebillingName);
        System.out.println("Set4 "+page3.emailId);

        System.out.println("Set5 "+page4.firsteblillingName);
        System.out.println("Set5 "+page4.lastebillingName);
        System.out.println("Set5 "+page4.emailId);

        waitTillElemenetVisible("SubmitEbillingContact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("SubmitEbillingContact"));
        Thread.sleep(10000);

        Validatecontactsubmission(page,"1");
        Validatecontactsubmission(page1,"2");
        Validatecontactsubmission(page2,"3");
        Validatecontactsubmission(page3,"4");
        Validatecontactsubmission(page4,"5");

        waitTillElemenetVisible("ManageEbillingContact");
        ExtentLogger.pass("Click on manage ebilling contact", true);
        Thread.sleep(1000);
       // boolean firstnamevalue=driver.findElement(By.xpath("//li[contains(text(),'"+p.firsteblillingName+"')]")).isDisplayed();
        //boolean lastnamevalue=driver.findElement(By.xpath("//li[contains(text(),'"+p.lastebillingName+"')]")).isDisplayed();
       // Assert.assertTrue(firstnamevalue);
        //Assert.assertTrue(lastnamevalue);
        Thread.sleep(1000);
        clickElement(getElementByXpath("ManageEbillingContact"));
        waitTillElemenetVisible("AddEbillingContact");
        Thread.sleep(4000);
        driver.navigate().refresh();

        Validatecontactdetailsinlist(page,5);
        driver.findElement(By.xpath("//*[text()='Back to billing']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Manage e-billing contacts']/parent::div/parent::a")).click();
        Thread.sleep(2000);
       // driver.findElement(By.xpath("//*[text()='Back to billing']")).click();
       // Thread.sleep(2000);
       // driver.navigate().refresh();
        Validatecontactdetailsinlist(page1,5);
        driver.findElement(By.xpath("//*[text()='Back to billing']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Manage e-billing contacts']/parent::div/parent::a")).click();
        Thread.sleep(2000);
       // driver.navigate().refresh();
        Validatecontactdetailsinlist(page2,5);
        driver.findElement(By.xpath("//*[text()='Back to billing']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Manage e-billing contacts']/parent::div/parent::a")).click();
        Thread.sleep(2000);
       // driver.findElement(By.xpath("//*[text()='Back to billing']")).click();
      //  Thread.sleep(2000);
        //driver.navigate().refresh();
        Validatecontactdetailsinlist(page3,5);
        driver.findElement(By.xpath("//*[text()='Back to billing']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='Manage e-billing contacts']/parent::div/parent::a")).click();
        Thread.sleep(2000);
       // driver.findElement(By.xpath("//*[text()='Back to billing']")).click();
       // Thread.sleep(2000);
        //driver.navigate().refresh();
        Validatecontactdetailsinlist(page4,5);
       // driver.findElement(By.xpath("//*[text()='Back to billing']")).click();
        //Thread.sleep(2000);
        //driver.navigate().refresh();

      /*  System.out.println("Set1 "+page.lastRecordNumber);
        System.out.println("Set2 "+page1.lastRecordNumber);
        System.out.println("Set3 "+page2.lastRecordNumber);

        System.out.println("Set4 "+page3.lastRecordNumber);
        System.out.println("Set5 "+page4.lastRecordNumber);*/
        return this;
    }
    public EbillingPage Edit_contact_to_duplicate (EbillingPage page) throws InterruptedException, IOException {

        waitTillElemenetVisible("AddEbillingContact");
        Thread.sleep(5000);
        ExtentLogger.pass("Clicking on Edit button of first contact record in list...", true);
        driver.findElement(By.xpath("(//div[@class='tr-ActionsPill-kebabContainer'])[1]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//*[text()='Edit']/parent::button)[1]")).click();
        Thread.sleep(3000);
        ExtentLogger.pass("Saving the details of first contact record in list ...", true);
        String fn= driver.findElement(By.xpath("//input[@name='First name']")).getAttribute("value");
        String ln= driver.findElement(By.xpath("//input[@name='Last name']")).getAttribute("value");
        String email= driver.findElement(By.xpath("//input[@name='Email']")).getAttribute("value");
        ExtentLogger.pass("Saved firstname,lastname & emailid of record one successfully...", true);
        ExtentLogger.pass("Saved firstname of record one successfully..."+fn, true);
        ExtentLogger.pass("Saved firstname of record one successfully..."+ln, true);
        ExtentLogger.pass("Saved firstname of record one successfully..."+email, true);
        Thread.sleep(3000);
        driver.findElement(By.xpath("//button[text()='Cancel']")).click();
        Thread.sleep(7000);
        driver.findElement(By.xpath("(//div[@class='tr-ActionsPill-kebabContainer'])[2]")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("(//*[text()='Edit']/parent::button)[2]")).click();
        Thread.sleep(3000);
        ExtentLogger.pass("Editing contact details of record2...", true);

        driver.findElement(By.xpath("//input[@name='First name']")).sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@name='Last name']")).sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));;
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@name='Email']")).sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
        Thread.sleep(3000);
        ExtentLogger.pass("cleared firstname,lastname & emaild of record 2 successfully..."+fn, true);
        driver.findElement(By.xpath("//input[@name='First name']")).sendKeys(fn);
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@name='Last name']")).sendKeys(ln);
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@name='Email']")).sendKeys(email);
        Thread.sleep(3000);
        ExtentLogger.pass("Entered contact details of record one in record 2 successfully...", true);
        driver.findElement(By.xpath("//*[text()='Save']/parent::button")).click();
        Thread.sleep(3000);
        ExtentLogger.pass("Clicked on save button...", true);
        waitTillElemenetVisible("DupContact_warn4");
        Boolean warningtext2= IsElementdisplayed(getElementByXpath("DupContact_warn4"));
        Assert.assertTrue(warningtext2);
        ExtentLogger.pass("Warning 4 on Editing a contact to a duplicate contact is successfully validated.", true);
        String color1 =getElementByXpath("DupContact_warn4_color").getCssValue("border-color");
         if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of warning box 4 is validated...", true);

        warningtext2= IsElementdisplayed(getElementByXpath("DupContact_warn5"));
        Assert.assertTrue(warningtext2);
        ExtentLogger.pass("Warning 5 on We couldn’t save your changes. Please try again shortly. is successfully validated.", true);
        color1 =getElementByXpath("DupContact_warn5_color").getCssValue("border-color");
         if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of warning box 4 is validated...", true);

        return this;
    }

    public EbillingPage Edit_contact (EbillingPage page) throws InterruptedException, IOException {

        page.firsteblillingName = fake.name().firstName();
        page.lastebillingName = fake.name().lastName();
        page.emailId = page.firsteblillingName + page.lastebillingName + "@test.com";

        waitTillElemenetVisible("AddEbillingContact");
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//div[@class='tr-ActionsPill-kebabContainer'])[2]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//*[text()='Edit']/parent::button)[2]")).click();
        Thread.sleep(3000);
        ExtentLogger.pass("Editing contact details of record2...", true);

        driver.findElement(By.xpath("//input[@name='First name']")).sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@name='Last name']")).sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));;
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@name='Email']")).sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
        Thread.sleep(3000);
        ExtentLogger.pass("cleared firstname,lastname & emaild of record 2 successfully..."+firsteblillingName +" "+lastebillingName +" " +emailId, true);
        driver.findElement(By.xpath("//input[@name='First name']")).sendKeys(firsteblillingName);
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@name='Last name']")).sendKeys(lastebillingName);
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@name='Email']")).sendKeys(emailId);
        Thread.sleep(3000);
        ExtentLogger.pass("Entered contact details of record one in record 2 successfully...", true);
        driver.findElement(By.xpath("//*[text()='Save']/parent::button")).click();
        Thread.sleep(3000);
        ExtentLogger.pass("Clicked on save button...", true);
        Thread.sleep(3000);

        Boolean a=IsElementdisplayed(getElementByXpath("Contact_updated_alert_msg"));
        Assert.assertTrue(a);
        ExtentLogger.pass("Successfully validated the contact update alert text...and the text was E-billing contact and  was successfully updated.", true);

        String contact_name=getElementText(getElementByXpath("Contact_updated_alert_msg_name"));
        Assert.assertTrue(contact_name.contains(firsteblillingName));
        ExtentLogger.pass("Successfully validated the contact update alert text...and it contained firstname " +firsteblillingName, true);

        Assert.assertTrue(contact_name.contains(lastebillingName));
        ExtentLogger.pass("Successfully validated the contact update alert text...and it contained lastname " +lastebillingName, true);


        String color1 =getElementByXpath("DupContact_warn6_color").getCssValue("background-color");
         if(color1.equalsIgnoreCase("rgba(0, 93, 162, 1)") 
                || color1.equalsIgnoreCase("rgb(0, 93, 162)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of Contact updated alert box is validated...", true);

        String getfullname=getElementText(driver.findElement(By.xpath("//tr[2]//th[1]"))).trim();
        String fullname= lastebillingName+","+" "+firsteblillingName;
        Assert.assertEquals(getfullname,fullname);
        ExtentLogger.pass("Successfully validated the updated first & last name in the table...", true);

        String getemail=getElementText(driver.findElement(By.xpath("//tr[2]//td[1]")));
        Assert.assertEquals(getemail,emailId);
        ExtentLogger.pass("Successfully validated the updated emailid name in the table...", true);


        return this;
    }

    public EbillingPage Delete_contact (EbillingPage page) throws InterruptedException, IOException {

        JavascriptExecutor jse=(JavascriptExecutor)driver;

        waitTillElemenetVisible("AddEbillingContact");
        Thread.sleep(3000);

        String name= driver.findElement(By.xpath("//tr[2]//th[1]")).getText();
        String email=driver.findElement(By.xpath("//tr[2]//td[1]")).getText();
        Thread.sleep(3000);
        ExtentLogger.pass("Storing details of contact before deleting..."+name +" "+email, true);

        driver.findElement(By.xpath("(//div[@class='tr-ActionsPill-kebabContainer'])[2]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//*[text()='Delete']/parent::button)[2]")).click();
        Thread.sleep(3000);
        ExtentLogger.pass("Deleting contact of record2...", true);
        driver.findElement(By.xpath("//*[text()='Yes, delete']/parent::button")).click();
        //Thread.sleep(3000);

        waitTillElemenetVisible("Contact_deleted_alert_msg");
        Boolean g=IsElementdisplayed(getElementByXpath("Contact_deleted_alert_msg"));
        Assert.assertTrue(g);
        ExtentLogger.pass("Successfully validated the contact deleted alert text...and the text was E-billing contact and  is deleted.", true);

        String split[]=name.split(",");

        String contact_name=getElementText(getElementByXpath("Contact_updated_alert_msg_name"));
        System.out.println("Split is "+split[0] +" "+split[1] +" "+contact_name);


        Assert.assertTrue(contact_name.contains(split[0].trim()));
        ExtentLogger.pass("Successfully validated the contact deleted alert text...and it contained lastname " +split[0], true);

        Assert.assertTrue(contact_name.contains(split[1].trim()));
        ExtentLogger.pass("Successfully validated the contact update alert text...and it contained firstname " +split[1], true);



        String color1 =getElementByXpath("DupContact_warn6_color").getCssValue("background-color");
         if(color1.equalsIgnoreCase("rgba(0, 93, 162, 1)") 
                || color1.equalsIgnoreCase("rgb(0, 93, 162)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of Contact deleted alert box is validated...", true);
        Thread.sleep(3000);

        String color =null;
        Boolean a=true;
        int Pagination =1;
        while(a)
        {
           List<WebElement> l=  driver.findElements(By.xpath("//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']"));

           for(int i=1;i<=l.size();i++)
           {
            String tempname= driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//th[1])["+i+"]")).getText();

            if(tempname.equals(name))
            {
                String mail= driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[1])["+i+"]")).getText();
                Boolean c= mail.equals(email);
                if(c)
                {
                    ExtentLogger.pass("Deleted record data found in table ,hence record was not deleted...", true);
                    Assert.assertTrue(false);
                }

            }
           }
           jse.executeScript("window.scrollBy(0,350)");
           ExtentLogger.pass("Deleted record details not found in page number..."+Pagination, true);
           Pagination++;
           try
           {
                color= driver.findElement(By.xpath("//*[@class='tr-DynamicPagination-buttonLabel' and text()='Next']/following-sibling::span")).getCssValue("border-color");
           }
           catch(NoSuchElementException e)
           {
               ExtentLogger.pass("Exception caught as there was no Next button...", true);
               break;
           }

           if(color.equals("rgb(250, 100, 0)") || color.equals("rgba(250, 100, 0, 1)") )
           {
               ExtentLogger.pass("Next button was available...", true);
               WebElement element= driver.findElement(By.xpath("//*[@class='tr-DynamicPagination-buttonLabel' and text()='Next']/parent::button"));

               Thread.sleep(3000);
               jse.executeScript("arguments[0].click();", element);
               ExtentLogger.pass("Next button was Clicked...", true);
           }
           else
           {
               a= false;
               ExtentLogger.pass("Next button was disabled...", true);
           }

        }
        return this;
    }


    public EbillingPage addOneEbillingContactwithMaxchar() throws InterruptedException, IOException {

        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));
        Thread.sleep(1000);
        String firsteblillingName = fake.regexify("[a-z]{40}");
        String lastebillingName = fake.regexify("[a-z]{40}");
        String emailId = fake.regexify("[a-z]{111}") + "@test.commmmm";
        System.out.println("fn "+firsteblillingName.length());
        System.out.println("ln "+lastebillingName.length());
        System.out.println("em "+emailId.length());
        waitTillElemenetVisible("FirstNameEbilling");
        sendKeysTotheElement("FirstNameEbilling", firsteblillingName);
        waitTillElemenetVisible("LastNameEbilling");
        sendKeysTotheElement("LastNameEbilling", lastebillingName);
        waitTillElemenetVisible("EmailEbilling");
        sendKeysTotheElement("EmailEbilling", emailId);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        String firstNameSize = driver.findElement(By.xpath("//*[text()='First name']/parent::label/following-sibling::input")).getAttribute("value");
        String lastNameNameSize = driver.findElement(By.xpath("//*[text()='Last name']/parent::label/following-sibling::input")).getAttribute("value");
        String emailSize = driver.findElement(By.xpath("//*[text()='Email']/parent::label/following-sibling::input")).getAttribute("value");
        System.out.println(firstNameSize);
        System.out.println(lastNameNameSize);
        System.out.println(emailSize);
        Assert.assertEquals(firstNameSize.length(), 35);
        Assert.assertEquals(lastNameNameSize.length(), 35);
        Assert.assertEquals(emailSize.length(), 120);
        ExtentLogger.pass("Length of First Name, last name and Email Address is correct!", true);
        return this;
    }


    public EbillingPage LastContactDeleteButton() throws InterruptedException, IOException {
        waitTillElemenetVisible("ActionBilling");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,200)");
        int size = driver.findElements(By.xpath("//table[@aria-labelledby='contacts-table-caption']//tr")).size();
        Assert.assertEquals(size, 2);
        ExtentLogger.pass("Only 1 ebilling contact is present", true);
        Thread.sleep(1000);
        waitTillElemenetVisible("ActionBilling");
        clickElement(getElementByXpath("ActionBilling"));
        Thread.sleep(3000);
        boolean result=false;
        try {
            if (driver.findElement(By.xpath("(//*[text()='Delete']/parent::button)[1]")).isDisplayed()) ;
            result = true;
        }catch(Exception e){}
        Assert.assertFalse(result);
        ExtentLogger.pass("Delete Button is not displayed for last ebilling contact", true);

        return this;

    }

    public EbillingPage emptycontact_fields() throws InterruptedException, IOException {
        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));
        Thread.sleep(1000);

        driver.findElement(By.xpath("//*[@name='Last name']")).click();
        Boolean a=driver.findElement(By.xpath("//*[@class='tr-FormItemInput-validationMessage' and text()='Enter a first name.']")).isDisplayed();
        Assert.assertTrue(a);
        ExtentLogger.pass("Successfully validated the warning Enter firstname..", true);

        String color1 =driver.findElement(By.xpath("//*[@class='tr-FormItemInput-validationMessage' and text()='Enter a first name.']")).getCssValue("color");
        if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of warning Enter a firstname  is validated & is red...", true);
        Thread.sleep(3000);

        color1 =driver.findElement(By.xpath("//input[@name='First name']")).getCssValue("border");
         if(color1.equalsIgnoreCase("2px solid rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("2px solid rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of firstname textbox is validated & is red...", true);
        Thread.sleep(3000);

        driver.findElement(By.xpath("//*[@name='Email']")).click();
        a=driver.findElement(By.xpath("//*[@class='tr-FormItemInput-validationMessage' and text()='Enter a last name.']")).isDisplayed();
        Assert.assertTrue(a);
        ExtentLogger.pass("Successfully validated the warning Enter lastname...", true);

        color1 =driver.findElement(By.xpath("//*[@class='tr-FormItemInput-validationMessage' and text()='Enter a last name.']")).getCssValue("color");
        if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of warning Enter a lastname  is validated & is red...", true);
        Thread.sleep(3000);

        color1 =driver.findElement(By.xpath("//input[@name='Last name']")).getCssValue("border");
         if(color1.equalsIgnoreCase("2px solid rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("2px solid rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of lastname textbox is validated & is red...", true);
        Thread.sleep(3000);

        driver.findElement(By.xpath("//input[@name='First name']")).click();
        a=driver.findElement(By.xpath("//*[@class='tr-FormItemInput-validationMessage' and text()='Enter an email.']")).isDisplayed();
        Assert.assertTrue(a);
        ExtentLogger.pass("Successfully validated the warning Enter emailid...", true);

        color1 =driver.findElement(By.xpath("//*[@class='tr-FormItemInput-validationMessage' and text()='Enter an email.']")).getCssValue("color");
        if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of warning Enter a emailid  is validated & is red...", true);
        Thread.sleep(3000);

        color1 =driver.findElement(By.xpath("//input[@name='Email']")).getCssValue("border");
         if(color1.equalsIgnoreCase("2px solid rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("2px solid rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of email textbox is validated & is red...", true);
        Thread.sleep(3000);



        return this;
    }

    public EbillingPage checkingoverlay_fields() throws InterruptedException, IOException {
        waitTillElemenetVisible("Addanother_contact");
        clickElement(getElementByXpath("Addanother_contact"));
        Thread.sleep(1000);
        ExtentLogger.pass("Clicking on Add another contact", true);

        driver.findElement(By.xpath("(//*[@name='Last name'])[2]")).click();
        Boolean a=driver.findElement(By.xpath("(//*[@class='tr-FormItemInput-validationMessage' and text()='Enter a first name.'])[2]")).isDisplayed();
        Assert.assertTrue(a);
        ExtentLogger.pass("Successfully validated the warning Enter firstname 2..", true);

        String color1 =driver.findElement(By.xpath("(//*[@class='tr-FormItemInput-validationMessage' and text()='Enter a first name.'])[2]")).getCssValue("color");
        if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of warning Enter a firstname 2  is validated & is red...", true);
        Thread.sleep(3000);

        color1 =driver.findElement(By.xpath("(//input[@name='First name'])[2]")).getCssValue("border");
         if(color1.equalsIgnoreCase("2px solid rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("2px solid rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of firstname 2 textbox is validated & is red...", true);
        Thread.sleep(3000);

        driver.findElement(By.xpath("(//*[@name='Email'])[2]")).click();
        a=driver.findElement(By.xpath("(//*[@class='tr-FormItemInput-validationMessage' and text()='Enter a last name.'])[2]")).isDisplayed();
        Assert.assertTrue(a);
        ExtentLogger.pass("Successfully validated the warning Enter lastname 2...", true);

        color1 =driver.findElement(By.xpath("(//*[@class='tr-FormItemInput-validationMessage' and text()='Enter a last name.'])[2]")).getCssValue("color");
        if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        
        ExtentLogger.pass("Color of warning Enter a lastname 2 is validated & is red...", true);
        Thread.sleep(3000);

        color1 =driver.findElement(By.xpath("(//input[@name='Last name'])[2]")).getCssValue("border");
         if(color1.equalsIgnoreCase("2px solid rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("2px solid rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of lastname textbox 2 is validated & is red...", true);
        Thread.sleep(3000);

        driver.findElement(By.xpath("(//input[@name='First name'])[2]")).click();
        a=driver.findElement(By.xpath("(//*[@class='tr-FormItemInput-validationMessage' and text()='Enter an email.'])[2]")).isDisplayed();
        Assert.assertTrue(a);
        ExtentLogger.pass("Successfully validated the warning Enter emailid 2...", true);

        color1 =driver.findElement(By.xpath("(//*[@class='tr-FormItemInput-validationMessage' and text()='Enter an email.'])[2]")).getCssValue("color");
        if(color1.equalsIgnoreCase("rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of warning Enter a emailid 2 is validated & is red...", true);
        Thread.sleep(3000);

        color1 =driver.findElement(By.xpath("(//input[@name='Email'])[2]")).getCssValue("border");
         if(color1.equalsIgnoreCase("2px solid rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("2px solid rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of email textbox 2 is validated & is red...", true);
        Thread.sleep(3000);

        driver.findElement(By.xpath("(//*[@name='Email'])[2]")).sendKeys("test.com");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[text()='Add contacts']")).click();
        Thread.sleep(2000);
        a=driver.findElement(By.xpath("//*[@class='tr-FormItemInput-validationMessage' and text()='Enter a valid email.']")).isDisplayed();
        Assert.assertTrue(a);
        ExtentLogger.pass("Successfully validated the warning Invalid emailid 2...", true);
        color1 =driver.findElement(By.xpath("(//input[@name='Email'])[2]")).getCssValue("border");
         if(color1.equalsIgnoreCase("2px solid rgba(220, 10, 10, 1)") 
                || color1.equalsIgnoreCase("2px solid rgb(220, 10, 10)")){}else{Assert.fail();}
        ExtentLogger.pass("Color of email textbox 2 for invalid email id is validated & is red...", true);


        return this;
    }
}



