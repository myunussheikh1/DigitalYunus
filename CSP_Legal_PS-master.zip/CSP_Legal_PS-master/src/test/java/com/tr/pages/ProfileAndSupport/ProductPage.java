package com.tr.pages.ProfileAndSupport;

import com.github.javafaker.Faker;
import com.tr.commons.ReadProperties;
import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;


public class ProductPage extends BasePage_PS {

    Faker fake = new Faker();
    String ticketNumber = "";
    static String subject = "";
    String usermessage = "";
    int attachmentCountinInt = 0;
    String accountNumber;
    int lastRecordNumber = 0;
    JavascriptExecutor jse = (JavascriptExecutor) driver;

    public ProductPage() {
        super("locatorsDefinition/ProfileAndSupport/ProductPage.json");
        PageFactory.initElements(getDriver(), this);

    }


    public ProductPage clickOnSupport() throws InterruptedException, IOException {


        Thread.sleep(5000);
        waitTillElemenetVisible("SupportLink");
        clickElement(getElementByXpath("SupportLink"));
        ExtentLogger.pass("Clicking on Support tab", true);
        return this;

    }
    public ProductPage Signout() throws InterruptedException, IOException {


        Thread.sleep(5000);
        waitTillElemenetVisible("Profile");
        clickElement(getElementByXpath("Profile"));
        ExtentLogger.pass("Clicking on Profile", true);
        Thread.sleep(5000);
        waitTillElemenetVisible("Signout");
        clickElement(getElementByXpath("Signout"));
        ExtentLogger.pass("Clicking on Signout", true);
        Thread.sleep(2000);
        Boolean a=driver.findElement(By.xpath("//strong[text()='You’re signed out']")).isDisplayed();
        Assert.assertTrue(a);
        ExtentLogger.pass("User has successfully signed out!!", true);
        clickElement(getElementByXpath("Signinagain"));

        return this;

    }

    public ProductPage clickOnManageBilling() throws InterruptedException, IOException {


        Thread.sleep(5000);
        waitTillElemenetVisible("Manage_Ebilling");
        clickElement(getElementByXpath("Manage_Ebilling"));
        ExtentLogger.pass("Clicking on Manage_Ebilling link", true);
        return this;

    }

    public ProductPage getBillingaccountnumber() throws InterruptedException, IOException {


        Thread.sleep(5000);
        waitTillElemenetVisible("AccountNumberHeader");
        accountNumber = getElementText("AccountNumberHeader");
        accountNumber = accountNumber.substring(accountNumber.length() - 10);

        return this;

    }

    public ProductPage ManageEbillinTabValidation() throws InterruptedException, IOException {


        Thread.sleep(5000);
        waitTillElemenetVisible("Manage_Ebilling");
        boolean b = driver.findElement(By.xpath("//strong[text()='Manage e-billing contacts']")).isDisplayed();
        if (b) {
            Assert.assertTrue(driver.findElement(By.xpath("//*[text()='Current contacts']")).isDisplayed());
            ExtentLogger.pass("User is successfully landed on on Manage_Ebilling window.", true);
        } else {
            ExtentLogger.pass("User could not land on on Manage_Ebilling window.", true);
        }
        return this;

    }

    public ProductPage ManageEbillinTableValidation() throws InterruptedException, IOException {


        Thread.sleep(5000);
        waitTillElemenetVisible("Manage_Ebilling");
        Boolean b = driver.findElement(By.xpath("//table[@aria-labelledby='contacts-table-caption']//th//span[text()='Name']")).isDisplayed();
        if (b) {
            Assert.assertTrue(driver.findElement(By.xpath("//table[@aria-labelledby='contacts-table-caption']//th//span[text()='Email']")).isDisplayed());
            Assert.assertTrue(IsElementdisplayed(getElementByXpath("Invoicenotification")));
            int size = driver.findElements(By.xpath("//table[@aria-labelledby='contacts-table-caption']//tr")).size();
            Assert.assertTrue(size > 1);
            ExtentLogger.pass("User is successfully landed on on Manage_Ebilling window and table is validated.", true);
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            waitTillElemenetVisible("ActionBilling");
            size = size - 1;
            ExtentLogger.pass("Number of rows visible to user in current table view..." + size, true);

        } else {
            ExtentLogger.pass(" Manage_Ebilling table not found.", true);
        }
        jse.executeScript("window.scrollBy(0,-550)");
        return this;

    }

    public ProductPage ActionOptions() throws InterruptedException, IOException {

        int size = driver.findElements(By.xpath("//table[@aria-labelledby='contacts-table-caption']//tr")).size();
        Assert.assertTrue(size > 1);
        Thread.sleep(5000);
        int temp = 1;
        while (size > 1) {
            if (temp == 3)
                break;
            String s = String.valueOf(temp);
            Thread.sleep(3000);
            driver.findElement(By.xpath("(//*[@class= 'tr-ActionsPill-kebabContainer'])[" + s + "]")).click();
            Thread.sleep(3000);
            System.out.println("(//*[@class= 'tr-ActionsPill-kebabContainer'])[" + s + "]");
            System.out.println("s value is" + s);
            Assert.assertTrue(driver.findElement(By.xpath("(//*[text()='Edit']/parent::button)[" + s + "]")).isDisplayed());
            Assert.assertTrue(driver.findElement(By.xpath("(//*[text()='Delete']/parent::button)[" + s + "]")).isDisplayed());
            //Assert.assertTrue(IsElementdisplayed(getElementByXpath("EditButton")));
            //Assert.assertTrue(IsElementdisplayed(getElementByXpath("DeleteButton")));
            ExtentLogger.pass("Edit & Delete Actions are successfully validated", true);
            temp++;

            jse.executeScript("window.scrollBy(0,200)");
        }


        return this;

    }


    public ProductPage clickOnResolvedTickets() throws InterruptedException, IOException {


        waitTillElemenetVisible("ResolvedTicketTab");
        clickElement(getElementByXpath("ResolvedTicketTab"));
        ExtentLogger.pass("Clicking on Resolved ticket tab", true);
        return this;

    }

    public ProductPage clickOnBilling() throws InterruptedException, IOException {


        Thread.sleep(5000);
        waitTillElemenetVisible("BillingLink");
        clickElement(getElementByXpath("BillingLink"));
        ExtentLogger.pass("Clicked on Billing Link successfully...", true);
        return this;

    }

    public ProductPage clickonSubmitTicket() throws InterruptedException, IOException {
        Thread.sleep(4000);
        waitTillElemenetVisible("SubmitTicket");
        clickElement(getElementByXpath("SubmitTicket"));
        ExtentLogger.pass("Create a ticket", true);
        return this;

    }

    public ProductPage clickOnTopic(String s) throws InterruptedException, IOException {

        Thread.sleep(10000);
        waitTillElemenetVisible("Topic");
        WebElement ele = driver.findElement(By.xpath("//*[text()='" + s + "']"));
        clickElement(ele);
        ExtentLogger.pass("Click on topic", true);

        return this;

    }

    public ProductPage clickOnTopicNext() throws InterruptedException {

        waitTillElemenetVisible("TopicNext");
        clickElement(getElementByXpath("TopicNext"));
        return this;

    }

    public ProductPage clickOnCategory(String Productname, String s) throws InterruptedException, IOException {
        Thread.sleep(2000);
        if (Productname.equalsIgnoreCase("Product support")) {
            clickElement(getElementByXpath("subproduct"));

            //driver.findElement(By.xpath("//button[@id='" + s + "']")).click();
            driver.findElement(By.xpath("//*[text()='" + s + "']/parent::span//ancestor::label[@class='tr-FormRadioControl-label']//input[@type='radio']")).click();
            ExtentLogger.pass("Click on Category", true);

        } else {

            Thread.sleep(5000);
            WebElement Sendbutton= driver.findElement(By.xpath("//*[text()='" + s + "']/parent::span//ancestor::label[@class='tr-FormRadioControl-label']//input[@type='radio']"));
            // WebElement ele = driver.findElement(By.xpath("//*[text()='" + s + "']"));
            // clickElement(ele);
            JavascriptExecutor executor = (JavascriptExecutor)driver;
            executor.executeScript("arguments[0].click()", Sendbutton);
            ExtentLogger.pass("Click on Category", true);
        }
        return this;

    }

    public ProductPage clickOnCategoryNext() throws InterruptedException {

        waitTillElemenetVisible("CategoryNext");
        clickElement(getElementByXpath("CategoryNext"));

        return this;

    }

    public ProductPage clickOnReason(String Reason) throws InterruptedException, IOException {
        Thread.sleep(2000);
        WebElement ele = driver.findElement(By.xpath("//*[contains(text(),'" + Reason + "')]"));
        clickElement(ele);
        ExtentLogger.pass("Click on Reason", true);
        return this;


    }

    public ProductPage clickOnReasonNext() throws InterruptedException {

        waitTillElemenetVisible("ReasonNext");
        clickElement(getElementByXpath("ReasonNext"));
        return this;

    }

    public ProductPage enterTicketSubject() throws InterruptedException, IOException {
        subject = "Automation Testing";
        waitTillElemenetVisible("TicketSubject");
        clickElement(getElementByXpath("TicketSubject"));
        sendKeysTotheElement("TicketSubject", subject);
        ExtentLogger.pass("Enter the Subject", true);
        return this;

    }

    public ProductPage enterInvalidTicketSubject() throws InterruptedException, IOException {
        String subject = fake.regexify("[a-z]{36}");
        waitTillElemenetVisible("TicketSubject");
        clickElement(getElementByXpath("TicketSubject"));
        sendKeysTotheElement("TicketSubject", subject);
        ExtentLogger.pass("Enter the Invalid Subject", true);
        return this;

    }
    String invoiceNumber="";
    public ProductPage getInvoiceNumber() throws InterruptedException, IOException {

        waitTillElemenetVisible("openFirstInvoice");
        invoiceNumber = getElementText(getElementByXpath("openFirstInvoice"));
        System.out.println(invoiceNumber);
        ExtentLogger.pass("Invoice Number is " + invoiceNumber, true);
        return this;

    }
    String invoiceNumber1="";
    public ProductPage getInvoiceNumber1() throws InterruptedException, IOException {

        waitTillElemenetVisible("openFirstInvoicee");
        invoiceNumber = getElementText(getElementByXpath("openFirstInvoicee"));
        System.out.println(invoiceNumber1);
        ExtentLogger.pass("Invoice Number is " + invoiceNumber, true);
        return this;

    }
    public ProductPage reportProblem() throws InterruptedException, IOException {
        waitForPageLoad();
        Thread.sleep(3000);
        try {
            while (driver.findElement(By.xpath("//span[text()='Next']/parent::button")).isEnabled()) {
                List<WebElement> eles = driver.findElements(By.xpath("//td[text()='Invoice']/preceding-sibling::th/a"));
                System.out.println("Number of invoices present in one page are "+eles.size());
                ExtentLogger.pass("Number of invoices present in one page are "+eles.size(), true);
                for (int i = 1; i <= eles.size(); i++) {
                    System.out.println("value of i"+i);
                    invoiceNumber1 = driver.findElement(By.xpath("(//td[text()='Invoice']/preceding-sibling::th/a)[" + i + "]")).getText();
                    driver.findElement(By.xpath("(//td[text()='Invoice']/preceding-sibling::th/a)[" + i + "]")).click();
                    waitForPageLoad();
                    Thread.sleep(1000);
                    try {
                        driver.findElement(By.xpath("//a[text()='Report a problem']")).click();
                        System.out.println("Clicked on Report a problem");
                        ExtentLogger.pass("Clicked on Report a problem",true);
                        break;
                    } catch (NoSuchElementException e) {
                        e.printStackTrace();
                        Thread.sleep(2000);
                        driver.findElement(By.xpath("//a[text()='Back to billing']")).click();
                        System.out.println("Clicked on Back to billing");
                        ExtentLogger.pass("Clicked on Back to billing",true);
                        waitForPageLoad();
                        Thread.sleep(2000);
                    }
                }
                if (driver.getTitle().equals("Dispute an invoice | Thomson Reuters")) {
                    System.out.println("Page title is Dispute an invoice | Thomson Reuters");
                    ExtentLogger.pass("Page title is Dispute an invoice | Thomson Reuters",true);
                    break;
                }
                driver.findElement(By.xpath("//span[text()='Next']/parent::button")).click();
                System.out.println("Clicked on Next page");
                ExtentLogger.pass("Clicked on Next page",true);
            }
        }catch(NoSuchElementException ex){
            System.out.println("Only 1 page is available");
            ExtentLogger.pass("Only 1 page is available",true);
            List<WebElement> eles = driver.findElements(By.xpath("//td[text()='Invoice']/preceding-sibling::th/a"));
            for (int i = 1; i <= eles.size(); i++) {
                invoiceNumber1 = driver.findElement(By.xpath("(//td[text()='Invoice']/preceding-sibling::th/a)[" + i + "]")).getText();
                driver.findElement(By.xpath("(//td[text()='Invoice']/preceding-sibling::th/a)[" + i + "]")).click();
                waitForPageLoad();
                Thread.sleep(1000);
                try {
                    driver.findElement(By.xpath("//a[text()='Report a problem']")).click();
                    System.out.println("Clicked on Report a problem");
                    ExtentLogger.pass("Clicked on Report a problem",true);
                    break;
                } catch (NoSuchElementException e) {
                    e.printStackTrace();
                    Thread.sleep(2000);
                    driver.findElement(By.xpath("//a[text()='Back to billing']")).click();
                    System.out.println("Clicked on Back to billing");
                    ExtentLogger.pass("Clicked on Back to billing",true);
                    waitForPageLoad();
                    Thread.sleep(2000);
                }
            }
        }


        System.out.println("Invoice Number is " +invoiceNumber1);
        ExtentLogger.pass("Invoice Number is " + invoiceNumber1, true);
        return this;

    }

    public ProductPage clickOnPaidInvoices() throws InterruptedException, IOException {

        waitTillElemenetVisible("PaidInvoices");
        clickElement(getElementByXpath("PaidInvoices"));
        ExtentLogger.pass("Clicking on Paid invoice", true);
        return this;

    }
    public ProductPage enterTelephone() throws InterruptedException, IOException {
        String phoneNumber = "+1848" + ThreadLocalRandom.current().nextLong(2000000, 9999999);
        System.out.println(phoneNumber);
        waitTillElemenetVisible("Telephone");
        clickElement(getElementByXpath("Telephone"));
        WebElement phoneNumberTextBox = getElementByXpath("Telephone");
        phoneNumberTextBox.sendKeys(Keys.CONTROL, Keys.chord("a"));
        phoneNumberTextBox.sendKeys(Keys.BACK_SPACE);
        Thread.sleep(3000);
        phoneNumberTextBox.sendKeys(phoneNumber);
        ExtentLogger.pass("Entered the Phone number", true);
        return this;

    }
    public ProductPage enterTelephone_canada() throws InterruptedException, IOException {
        String phoneNumber = "+1647" + ThreadLocalRandom.current().nextLong(1000000, 9999999);
        System.out.println(phoneNumber);
        waitTillElemenetVisible("Telephone");
        clickElement(getElementByXpath("Telephone"));
        WebElement phoneNumberTextBox = getElementByXpath("Telephone");
        phoneNumberTextBox.sendKeys(Keys.CONTROL, Keys.chord("a"));
        phoneNumberTextBox.sendKeys(Keys.BACK_SPACE);
        Thread.sleep(3000);
        phoneNumberTextBox.sendKeys(phoneNumber);
        ExtentLogger.pass("Entered the Phone number", true);
        return this;
    }

    public ProductPage enterTelephoneUKI() throws InterruptedException, IOException {
        String phoneNumber = "+44789" + ThreadLocalRandom.current().nextLong(1000000, 9999999);
        System.out.println(phoneNumber);
        waitTillElemenetVisible("Telephone");
        clickElement(getElementByXpath("Telephone"));
        WebElement phoneNumberTextBox = getElementByXpath("Telephone");
        phoneNumberTextBox.sendKeys(Keys.CONTROL, Keys.chord("a"));
        phoneNumberTextBox.sendKeys(Keys.BACK_SPACE);
        Thread.sleep(3000);
        phoneNumberTextBox.sendKeys(phoneNumber);
        ExtentLogger.pass("Entered the Phone number", true);
        return this;

    }

    public ProductPage enterInvalidTelephone(String phone) throws InterruptedException, IOException {
        String phoneNumber = "+9191" + ThreadLocalRandom.current().nextLong(100000000, 999999999);
        System.out.println(phoneNumber);
        waitTillElemenetVisible("Telephone");
        clickElement(getElementByXpath("Telephone"));
        WebElement phoneNumberTextBox = getElementByXpath("Telephone");
        phoneNumberTextBox.sendKeys(Keys.CONTROL, Keys.chord("a"));
        phoneNumberTextBox.sendKeys(Keys.BACK_SPACE);
        Thread.sleep(3000);
        phoneNumberTextBox.sendKeys(phoneNumber);
        ExtentLogger.pass("Enter the Invalid Telephone number", true);
        return this;

    }

    public ProductPage updateTelephone() throws InterruptedException, IOException {

        waitTillElemenetVisible("update_Telephone");
        clickElement(getElementByXpath("update_Telephone"));
        ExtentLogger.pass("Click on update telephone number", true);
        return this;

    }
    String description="";
    public ProductPage enterDescription() throws InterruptedException, IOException {
         description = fake.regexify("[a-z]{15}");
        waitTillElemenetVisible("Description");
        clickElement(getElementByXpath("Description"));
        sendKeysTotheElement("Description", description);
        ExtentLogger.pass("Description is entered successfully...", true);

        return this;

    }

    public ProductPage enterInvalidDescription() throws InterruptedException, IOException {
        String description = fake.regexify("[a-z]{2001}");
        waitTillElemenetVisible("Description");
        clickElement(getElementByXpath("Description"));
        sendKeysTotheElement("Description", description);
        ExtentLogger.pass("Enter the Invalid Description...", true);

        return this;

    }

    public ProductPage selectTheFile(String s) throws InterruptedException, IOException {
        Thread.sleep(5000);
        String base = System.getProperty("user.dir");
        System.out.println(base);
        if (s.equalsIgnoreCase("Yes")) {
            driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//dummy.pdf");
            Thread.sleep(5000);
            ExtentLogger.pass("Upload the file", true);
        }
        return this;

    }

    public ProductPage clickonSubmitTheTicket() throws InterruptedException, IOException {

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,150)");
        ExtentLogger.pass("Submitting the ticket...", true);
        Thread.sleep(7000);
        waitTillElemenetVisible("SubmitTheTicket");
        clickElement(getElementByXpath("SubmitTheTicket"));
        ExtentLogger.pass("Click on Submit ticket", true);
        return this;

    }

    public ProductPage clickonTicketDetails() throws InterruptedException, IOException {

        waitTillElemenetVisible("TicketDetails");
        clickElement(getElementByXpath("TicketDetails"));
        Thread.sleep(3000);
        ExtentLogger.pass("Opening ticket created...", true);
        return this;
    }
    
    public ProductPage clickonShowTicketDetails() throws InterruptedException, IOException {

        waitTillElemenetVisible("ShowTicketDetails");
        clickElement(getElementByXpath("ShowTicketDetails"));
        Thread.sleep(3000);
        ExtentLogger.pass("Clicking on Show Ticket Details...", true);
        return this;

    }
    
    public ProductPage isAttachmentVisible(String s) throws InterruptedException, IOException {
        Thread.sleep(15000);
        waitForPageLoad();
        if (s.equalsIgnoreCase("Yes")) {
            Assert.assertTrue(IsElementdisplayed(getElementByXpath("VerifyAttachment")));
            ExtentLogger.pass("Attachment is visible", true);

        }
        return this;

    }

    public ProductPage isemailnotificationneeded(String s) throws InterruptedException, IOException {
        Thread.sleep(5000);
        if (s.equalsIgnoreCase("Yes")) {
            WebElement element = driver.findElement(By.xpath("//*[text()='Receive email notifications when an agent comments on your ticket.']"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
            Thread.sleep(2000);
            ExtentLogger.pass("Email notification is selected...", true);

        }
        return this;


    }
    public ProductPage openTicketForClosing() throws IOException, InterruptedException {
Thread.sleep(5000);
            boolean a=true;
                while(a) {
                    int length=driver.findElements(By.xpath("//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']")).size();
                    for (int i = 1; i <= length; i++) {
                        if ((driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("General account questions") && driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")) ||
                                (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("Billing, payments, refunds, and returns")&& driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")) ||
                                (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("Orders, subscriptions, and renewals")&& driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")) ||
                                (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("Thomson Reuters company and vendor info") && driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New"))||
                                (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("Manage account admins")&& driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")) ||
                                (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("Account passwords")&& driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")))
                        {
                            driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[1]//a)[" + i + "]")).click();
                            a=false;
                            break;
                        } else {

                        }
                    }
                    if(a) {
                        try {
                            if (driver.findElement(By.xpath("//*[text()='Next']/parent::button")).isEnabled() ) {
                                driver.findElement(By.xpath("//*[text()='Next']")).click();
                            }
                            else{
                                a=false;
                            }
                        }
                        catch(NoSuchElementException e){
                            a=false;
                        }
                    }
                }


                return  this;
        }
    public ProductPage openDisputeTicketForClosing() throws IOException, InterruptedException {
        Thread.sleep(5000);
        boolean a=true;
        while(a) {
            int length=driver.findElements(By.xpath("//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']")).size();

            for (int i = 1; i <= length; i++) {
                if (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[1]//a)[" + i + "]")).getText()
                        .contains("Problem on invoice") &&
                        driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]"))
                                .getText().contains("New"))
                        {

                    driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[1]//a)[" + i + "]")).click();
                    a=false;
                    break;
                } else {

                }
            }
            if(a) {

                try {
                    if (driver.findElement(By.xpath("//*[text()='Next']/parent::button")).isEnabled() ) {
                        driver.findElement(By.xpath("//*[text()='Next']")).click();

                    }
                    else{
                        a=false;

                    }
                }
                catch(NoSuchElementException e){
                    a=false;

                }
            }
        }


        return  this;
    }

    public ProductPage openProductTicketForClosing() throws IOException, InterruptedException {
    	Thread.sleep(5000);
    	            boolean a=true;
    	                while(a) {
    	                    int length=driver.findElements(By.xpath("//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']")).size();
    	                    for (int i = 1; i <= length; i++) {
    	                        if ((driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("Westlaw Classic") && driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")) ||

    	                                (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("Westlaw Edge")&& driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")) || 
    	                                (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("CLEAR")&& driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")) ||
                                        (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("ProView")&& driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")) ||
                                        (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("Practical Law UK")&& driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")) ||
                                        (driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[5])[" + i + "]")).getText().contains("Lawtel on Westlaw UK")&& driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[2])[" + i + "]")).getText().contains("New")))

    	                        {
    	                        	driver.findElement(By.xpath("(//tr[@class='tr-DataGrid-row tr-DataGrid-row--body']//td[1]//a)[" + i + "]")).click();
    	                            a=false;
    	                            break;
    	                        } else {
    	                        	
    	                        }
    	                    }
    	                    if(a) {
    	                        try {
                                    if (driver.findElement(By.xpath("//*[text()='Next']/parent::button")).isEnabled() ) {
                                        driver.findElement(By.xpath("//*[text()='Next']")).click();
    	                            }
    	                            else{
    	                                a=false;
    	                            }
    	                        }
    	                        catch(NoSuchElementException e){
                                    a=false;
    	                        }
    	                    }
    	                }


    	                return  this;
    	        }

    public ProductPage getTicketNumber() throws InterruptedException, IOException {

        waitTillElemenetVisible("CaseNumber");
        ticketNumber = getElementText(getElementByXpath("CaseNumber"));
        System.out.println(ticketNumber);
        ExtentLogger.pass("Ticket Number is " + ticketNumber, true);
        return this;

    }

    public ProductPage validateResolvedTicketStatus() throws InterruptedException, IOException {


        waitTillElemenetVisible("ResolvedTicketStatus");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,350)");
        Thread.sleep(2000);
        String status = getElementText(getElementByXpath("ResolvedTicketStatus"));
        System.out.println(status);
        Assert.assertEquals(status, "Resolved");
        ExtentLogger.pass("Ticket status is " + status, true);
        return this;

    }

    public ProductPage validateNoOpenTicket() throws InterruptedException, IOException {


        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,850)");
        Thread.sleep(4000);
        waitTillElemenetVisible("NoOpenTickets");
        String message = getElementText(getElementByXpath("NoOpenTickets"));
        System.out.println(message);
        Assert.assertEquals(message, "You don’t have any open tickets.");
        ExtentLogger.pass("You don’t have any open tickets. is Visible", true);
        return this;

    }

    public ProductPage validatenewstatus() throws InterruptedException, IOException {
        String New = null;
        waitTillElemenetVisible("new_status");
        New = getElementText(getElementByXpath("new_status"));
        Assert.assertEquals(New, "New");
        int a = driver.findElements(By.xpath("//*[@class='tr-TicketProgressBar-step is-unselected']")).size();
        Assert.assertEquals(a, 3);
        ExtentLogger.pass("Validate the status is New", true);

        return this;

    }

    public ProductPage validateticketinopenTickets(ProductPage s) throws InterruptedException, IOException {


        waitForPageLoad();
        Thread.sleep(5000);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("window.scrollBy(0,950)");
        Thread.sleep(3000);
        waitTillElemenetVisibleByxpath("//td[text()='"+s.ticketNumber+"']");
        WebElement ele=driver.findElement(By.xpath("//td[text()='"+s.ticketNumber+"']"));
        Boolean result= isElementDisplayed(ele);
        Assert.assertTrue(result);
        ExtentLogger.pass("Ticketnumber is found in open ticket queue.", true);

        return this;

    }

    public ProductPage validatewipstatus() throws InterruptedException, IOException {
        Thread.sleep(10000);
        driver.navigate().refresh();
        String New = null;
        waitTillElemenetVisible("new_status");
        New = driver.findElement(By.xpath("(//*[@class='tr-TicketProgressBar-step is-selected']/div[@class='tr-TicketProgressBar-label'])[2]")).getText();
        Assert.assertTrue(New.contains("Assigned to"));
        New = driver.findElement(By.xpath("(//*[@class='tr-TicketProgressBar-step is-selected']/div[@class='tr-TicketProgressBar-label'])[3]")).getText();
        Assert.assertEquals(New, "Work in progress");
        int a = driver.findElements(By.xpath("//*[@class='tr-TicketProgressBar-step is-unselected']")).size();
        Assert.assertEquals(a, 1);
        //
        ExtentLogger.pass("Ticket is in Work in progress and is validated successfully", true);
        return this;

    }


    //with nick name validation
    public ProductPage validateAssignedStatus_withNickName() throws InterruptedException, IOException {

        driver.navigate().refresh();
        String Status = null;
        waitTillElemenetVisible("new_status");
        Status = driver.findElement(By.xpath("(//*[@class='tr-TicketProgressBar-step is-selected']/div[@class='tr-TicketProgressBar-label'])[2]")).getText();
        Assert.assertTrue(Status.contains("Assigned to test.txphelpdeskagent"));
        ExtentLogger.pass("Ticket is Assigned to test.txphelpdeskagent (with nick name) and is Validated successfully", true);
        return this;

    }

    //without nick name validation
    public ProductPage validateAssignedStatus_withoutNickName() throws InterruptedException, IOException {
        driver.navigate().refresh();
        String Status= null;
        waitTillElemenetVisible("new_status");
        //Status=driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/ul/li[2]/div[2]")).getText();
        Status=driver.findElement(By.xpath("/html/body/div[1]/div/main/div/div/div/div/div[2]/div/div[2]/div[1]/div[1]/div[1]/ul/li[2]/div[2]")).getText();
        Assert.assertTrue(Status.contains("Assigned to representative"));
        ExtentLogger.pass("Ticket is Assigned to representative (without nick name) and is Validated successfully", true);
        return this;

    }

    //OptIn email notification checkbox is selected
    public ProductPage OptIn_emailNotify_checkbox() throws InterruptedException, IOException {
        driver.navigate().refresh();
        String Status= null;
        driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div/div/div/div[2]/div/div[2]/div[1]/div[2]/div/label/span")).click();
        ExtentLogger.pass("Opt In email Notify is checked", true);
        Thread.sleep(5000);
        return this;

    }

    public ProductPage validateresolvedstatus() throws InterruptedException, IOException {
        driver.navigate().refresh();
        String New = null;
        Thread.sleep(3000);

        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='tr-TicketProgressBar-step is-selected']/div[@class='tr-TicketProgressBar-label'])[2]")));
        //waitTillElemenetVisible("new_status");
        New = driver.findElement(By.xpath("(//*[@class='tr-TicketProgressBar-step is-selected']/div[@class='tr-TicketProgressBar-label'])[2]")).getText();
        Assert.assertTrue(New.contains("Assigned to"));
        New = driver.findElement(By.xpath("(//*[@class='tr-TicketProgressBar-step is-selected']/div[@class='tr-TicketProgressBar-label'])[3]")).getText();
        Assert.assertEquals(New, "Work in progress");
        New = driver.findElement(By.xpath("(//*[@class='tr-TicketProgressBar-step is-selected']/div[@class='tr-TicketProgressBar-label'])[4]")).getText();
        Assert.assertEquals(New, "Resolved");
        int a = driver.findElements(By.xpath("//*[@class='tr-TicketProgressBar-step is-unselected']")).size();
        Assert.assertEquals(a, 0);
        ExtentLogger.pass("Ticket is resolved and is validated successfully", true);
        return this;

    }

    /*public ProductPage sendFeedsFromUserside(SFDC_PS sfdc_ps) throws InterruptedException, IOException {
        usermessage = "Please assist me";
        sendKeysTotheElement("CaseFeedTextbox", usermessage);
        Thread.sleep(1000);
        String base = System.getProperty("user.dir");
        driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//dummy.pdf");
        Thread.sleep(1000);
        waitTillElemenetVisible("SendCaseFeed");
        clickElement(getElementByXpath("SendCaseFeed"));
        waitTillElemenetVisible("SendCaseFeed");
        Thread.sleep(2000);
        driver.navigate().refresh();
        waitTillElemenetVisible("SendCaseFeed");
        Thread.sleep(1000);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,2000)");
        Thread.sleep(4000);
        waitTillElemenetVisible("Agentmessage");
        String accountUsername = getElementText(getElementByXpath("accountUsername"));
        log.info("Username of the account is " + accountUsername);
        String userMessageOnRightSide = driver.findElement(By.xpath("//strong[contains(text(),'" + accountUsername + "')]/parent::span/parent::div/parent::div/following-sibling::div/p")).getText();
        Assert.assertEquals(userMessageOnRightSide, usermessage);
        String agentMessageOnLeftSide = driver.findElement(By.xpath("//*[contains(text(),'epresentative')]/ancestor::div[@class='tr-ConversationItem-supportComment']//div[@class='tr-TicketSenderComment-supportComment']/p")).getText();
        Assert.assertEquals(userMessageOnRightSide, usermessage);
        Assert.assertEquals(agentMessageOnLeftSide, sfdc_ps.message);

        ExtentLogger.pass("Sending feeds from user side...", true);
        ArrayList tab = new ArrayList(driver.getWindowHandles());
        driver.switchTo().window((String) tab.get(3));
        return this;

    }

    public ProductPage validateagentmessageinUI(SFDC_PS sfdc_ps) throws InterruptedException, IOException {

        Thread.sleep(5000);
        driver.navigate().refresh();
        Thread.sleep(5000);
        waitTillElemenetVisible("SendCaseFeed");
        String text = getElementText(getElementByXpath("Validatetheagentmessage"));
        if (text.contains(sfdc_ps.message)) {
            Assert.assertTrue(true);
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("window.scrollBy(0,950)");
            Thread.sleep(2000);
            System.out.println("Text is visible");
            ExtentLogger.pass("Text Message is visible", true);
        } else {
            System.out.println("Text is not visible");
        }
        return this;

    }*/

    public ProductPage clickonUpdateNumber() throws InterruptedException {

        waitTillElemenetVisible("UpdateNumber");
        clickElement(getElementByXpath("UpdateNumber"));
        return this;

    }

    public ProductPage openSFDCInNewTab(String url) throws InterruptedException, IOException {
        Thread.sleep(3000);
        ((JavascriptExecutor) driver).executeScript("window.open()");
        ArrayList tab = new ArrayList(driver.getWindowHandles());
        driver.switchTo().window((String) tab.get(1));
        driver.get(url);
        Thread.sleep(10000);
        ExtentLogger.pass("Navigating to SFDC instance...", true);

        return this;
    }

    public ProductPage gobacktosupport() throws InterruptedException {
        Thread.sleep(3000);
        driver.get(ReadProperties.getConfig("web-url"));
        return this;
    }

    public ProductPage clickOnFirstInvoice() throws InterruptedException, IOException {

        waitTillElemenetVisible("openFirstInvoicee");
        clickElement(getElementByXpath("openFirstInvoicee"));
        return this;

    }

    public ProductPage reportAProblem() throws InterruptedException, IOException {

        waitTillElemenetVisible("reportAProblem");
        clickElement(getElementByXpath("reportAProblem"));
        Thread.sleep(3000);
        ExtentLogger.pass("Creating a billing dispute case...", true);
        return this;

    }
    public ProductPage selectAndContinueCharges() throws InterruptedException, IOException {
    try {
        if (IsElementdisplayed(getElementByXpath("selectCheckboxCharges"))) {
            waitTillElemenetVisible("selectCheckboxCharges");
            clickElement(getElementByXpath("selectCheckboxCharges"));
            waitTillElemenetVisible("continueCharges");
            clickElement(getElementByXpath("continueCharges"));
            Thread.sleep(3000);
            ExtentLogger.pass("Select checkbx and click on continue...", true);
        }
    }catch (Exception e){
        System.out.println(e.getMessage());
    }
        return this;

    }

    public ProductPage selectTypeOfProblem(String type) throws InterruptedException, IOException {

        waitTillElemenetVisible("typeofproblem");
        clickElement(getElementByXpath("typeofproblem"));
        driver.findElement(By.xpath("//span[text()='" + type + "']/parent::button")).click();
        ExtentLogger.pass("Selected the case type successfully...", true);
        return this;

    }
    public ProductPage selectTypeOfProblem(String category, String reason) throws InterruptedException, IOException {

        waitTillElemenetVisible("typeofproblem");
        clickElement(getElementByXpath("typeofproblem"));
        driver.findElement(By.xpath("//span[text()='" + category + "']/parent::button")).click();
        ExtentLogger.pass("Choose a category "+category, true);
        waitTillElemenetVisible("typeofreason");
        clickElement(getElementByXpath("typeofreason"));
        driver.findElement(By.xpath("//span[text()='" + reason + "']/parent::button")).click();
        ExtentLogger.pass("Choose a reason "+reason, true);
        return this;

    }

    public ProductPage openSFDCWBInNewTab() throws InterruptedException, IOException {
        Thread.sleep(3000);
        ((JavascriptExecutor) driver).executeScript("window.open()");
        ArrayList tab = new ArrayList(driver.getWindowHandles());
        driver.switchTo().window((String) tab.get(2));
        driver.get("https://workbench.developerforce.com/login.php");
        Thread.sleep(10000);
        ExtentLogger.pass("Opening the Workbench in new tab", true);
        return this;
    }

    //Opening The YOPMail in new tab
    public ProductPage openYOPMailInNewTab() throws InterruptedException, IOException {
        Thread.sleep(3000);
        ((JavascriptExecutor) driver).executeScript("window.open()");
        ArrayList tab = new ArrayList(driver.getWindowHandles());
        //driver.switchTo().window((String) tab.get(3));
        driver.switchTo().window((String) tab.get(1));
        driver.get("https://yopmail.com/en/");
        Thread.sleep(10000);
        ExtentLogger.pass("Opening the YopMail in new tab", true);
        return this;
    }

    public ProductPage loginToSFDC(String username, String password) throws InterruptedException, IOException {
        waitTillElemenetVisible("SFDCUsername");
        sendKeysTotheElement("SFDCUsername", username);
        sendKeysTotheElement("SFDCPassword", password);
        clickElement(getElementByXpath("SFDCLoginButton"));
        ExtentLogger.pass("Logging into SFDC", true);
        return this;
    }


    public ProductPage SelectProductCase() throws InterruptedException, IOException {
        Thread.sleep(2000);
        ExtentLogger.pass("Click on topic", true);
        waitUntilVisible("product_support_radio_button", "xpath", 30);
        clickElement(getElementByXpath("product_support_radio_button"));
        ExtentLogger.pass("product_support_radio_button is clicked successfully!!", true);

        waitUntilVisible("next_button_1", "xpath", 30);
        clickElement(getElementByXpath("next_button_1"));
        ExtentLogger.pass("next_button_1 is clicked successfully!!", true);
        return this;
    }


    public ProductPage ProductSearchTextBox(String s) throws InterruptedException, IOException {

        Thread.sleep(2000);
        ExtentLogger.pass("click on product!!", true);
        waitUntilVisible("product_search_text_box", "xpath", 60);
        clickElement(getElementByXpath("product_search_text_box"));
        ExtentLogger.pass("product_search_text_box is clicked successfully!!", true);

        driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
        clickElement(getElementByXpath("product_search_text_box_click"));


        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        clickElement(getElementByXpath("subproduct"));
//        String s = "Westlaw Classic";
        driver.findElement(By.xpath("//button[@id='" + s + "']")).click();

        ExtentLogger.pass(s + " option selected successfully!!", true);
        waitUntilVisible("next_button_2", "xpath", 30);
        clickElement(getElementByXpath("next_button_2"));
        ExtentLogger.pass("next_button_2 is clicked successfully!!", true);
        return this;
    }

    public ProductPage ProductSearchTextBox_CheckPointEdge() throws InterruptedException, IOException {

        Thread.sleep(2000);
        ExtentLogger.pass("click on product!!", true);
        waitUntilVisible("product_search_text_box", "xpath", 60);
        clickElement(getElementByXpath("product_search_text_box"));
        ExtentLogger.pass("product_search_text_box is clickedd successfully!!", true);

        driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
        clickElement(getElementByXpath("product_search_text_box_click"));


        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        clickElement(getElementByXpath("subproduct"));
        String s = "Checkpoint Edge";
        driver.findElement(By.xpath("//button[@id='" + s + "']")).click();

        ExtentLogger.pass("checkpoint edge option selected successfully!!", true);
        waitUntilVisible("next_button_2", "xpath", 30);
        clickElement(getElementByXpath("next_button_2"));
        ExtentLogger.pass("next_button_2 is clickedd successfully!!", true);
        return this;
    }

    public ProductPage ProductSearchTextBox_CheckPointTools() throws InterruptedException, IOException {

        Thread.sleep(2000);
        ExtentLogger.pass("click on product!!", true);
        waitUntilVisible("product_search_text_box", "xpath", 60);
        clickElement(getElementByXpath("product_search_text_box"));
        ExtentLogger.pass("product_search_text_box is clickedd successfully!!", true);

        driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
        clickElement(getElementByXpath("product_search_text_box_click"));


        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        clickElement(getElementByXpath("subproduct"));
        String s = "Checkpoint Tools";
        driver.findElement(By.xpath("//button[@id='" + s + "']")).click();

        ExtentLogger.pass("checkpoint tools option selected successfully!!", true);
        waitUntilVisible("next_button_2", "xpath", 30);
        clickElement(getElementByXpath("next_button_2"));
        ExtentLogger.pass("next_button_2 is clickedd successfully!!", true);
        return this;
    }

    //Subbu
//added for productSearch of Checkpoint Engage
    public ProductPage ProductSearchTextBox_CheckPointEngage() throws InterruptedException, IOException {

        Thread.sleep(2000);
        ExtentLogger.pass("click on product!!", true);
        waitUntilVisible("product_search_text_box", "xpath", 60);
        clickElement(getElementByXpath("product_search_text_box"));
        ExtentLogger.pass("product_search_text_box is clickedd successfully!!", true);

        driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
        clickElement(getElementByXpath("product_search_text_box_click"));


        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        clickElement(getElementByXpath("subproduct"));
        String s = "Checkpoint Engage";
        driver.findElement(By.xpath("//button[@id='" + s + "']")).click();

        ExtentLogger.pass("checkpoint tools option selected successfully!!", true);
        waitUntilVisible("next_button_2", "xpath", 30);
        clickElement(getElementByXpath("next_button_2"));
        ExtentLogger.pass("next_button_2 is clickedd successfully!!", true);
        return this;
    }

    //Subbu
//added for productSearch of e-Form RS
    public ProductPage ProductSearchTextBox_eFormRS() throws InterruptedException, IOException {

        Thread.sleep(2000);
        waitUntilVisible("product_search_text_box", "xpath", 60);
        clickElement(getElementByXpath("product_search_text_box"));
        System.out.println("product_search_text_box is clickedd successfully!!");
        ExtentLogger.pass("product_search_text_box is clickedd successfully!!", true);
        driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
        clickElement(getElementByXpath("product_search_text_box_click"));


        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        clickElement(getElementByXpath("subproduct"));
        String s = "e-Form RS";
        driver.findElement(By.xpath("//button[@id='" + s + "']")).click();

        System.out.println("checkpoint tools option selected successfully!!");
        waitUntilVisible("next_button_2", "xpath", 30);
        clickElement(getElementByXpath("next_button_2"));
        System.out.println("next_button_2 is clickedd successfully!!");
        ExtentLogger.pass("next_button_2 is clickedd successfully!!", true);
        return this;
    }

    //Subbu
//added for productSearch of SMART Practice Aids
    public ProductPage ProductSearchTextBox_SMARTPracticeAids() throws InterruptedException, IOException {

        Thread.sleep(2000);
        waitUntilVisible("product_search_text_box", "xpath", 60);
        clickElement(getElementByXpath("product_search_text_box"));
        System.out.println("product_search_text_box is clickedd successfully!!");
        ExtentLogger.pass("product_search_text_box is clickedd successfully!!", true);
        driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
        clickElement(getElementByXpath("product_search_text_box_click"));


        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        clickElement(getElementByXpath("subproduct"));
        String s = "SMART Practice Aids";
        driver.findElement(By.xpath("//button[@id='" + s + "']")).click();

        System.out.println("checkpoint tools option selected successfully!!");
        ExtentLogger.pass("checkpoint tools option selected successfully!!", true);
        waitUntilVisible("next_button_2", "xpath", 30);
        clickElement(getElementByXpath("next_button_2"));
        System.out.println("next_button_2 is clickedd successfully!!");
        ExtentLogger.pass("next_button_2 is clickedd successfully!!", true);
        return this;
    }


    public ProductPage ReasonDropDown_MFA() throws InterruptedException, IOException {
        Thread.sleep(2000);
        waitUntilVisible("MFA_radio_button", "xpath", 30);
        clickElement(getElementByXpath("MFA_radio_button"));
        System.out.println("other_radio_button is clickedd successfully!!");
        ExtentLogger.pass("other_radio_button is clickedd successfully!!", true);

        waitUntilVisible("next_button_3", "xpath", 30);
        clickElement(getElementByXpath("next_button_3"));
        System.out.println("next_button_3 is clickedd successfully!!");
        ExtentLogger.pass("next_button_3 is clickedd successfully!!", true);
        return this;
    }


    public ProductPage ReasonDropDown_INeedToDeleteUserFromproduct() throws InterruptedException, IOException {
        Thread.sleep(2000);
        waitUntilVisible("IneedtoDeleteUserFromProduct_radio_button", "xpath", 30);
        clickElement(getElementByXpath("IneedtoDeleteUserFromProduct_radio_button"));
        System.out.println("I IneedtoDeleteUserFromProduct_radio_button is clickedd successfully!!");
        ExtentLogger.pass("I IneedtoDeleteUserFromProduct_radio_button is clickedd successfully!!", true);
        waitUntilVisible("next_button_3", "xpath", 30);
        clickElement(getElementByXpath("next_button_3"));
        System.out.println("next_button_3 is clickedd successfully!!");
        ExtentLogger.pass("next_button_3 is clickedd successfully!!", true);

        return this;
    }

    //Subbu
    //Added method for radio btn 'I need help with an error message' selection
    public ProductPage ReasonDropDown_INeedHelpWithAnErrorMessage() throws InterruptedException, IOException {
        Thread.sleep(2000);
        waitUntilVisible("INeedHelpWithAnErrorMessage_radio_button", "xpath", 30);
        clickElement(getElementByXpath("INeedHelpWithAnErrorMessage_radio_button"));
        System.out.println("I INeedHelpWithAnErrorMessage_radio_button is clickedd successfully!!");
        ExtentLogger.pass("INeedHelpWithAnErrorMessage_radio_button successfully!!", true);
        waitUntilVisible("next_button_3", "xpath", 30);
        clickElement(getElementByXpath("next_button_3"));
        System.out.println("next_button_3 is clickedd successfully!!");

        return this;
    }

    //Subbu
    //Added method for radio btn 'I need to edit a user for a product' selection
    public ProductPage ReasonDropDown_INeedToEditAUserForAProduct() throws InterruptedException, IOException {
        Thread.sleep(2000);
        waitUntilVisible("INeedToEditAUserForAProduct_radio_button", "xpath", 30);
        clickElement(getElementByXpath("INeedToEditAUserForAProduct_radio_button"));
        System.out.println("I INeedToEditAUserForAProduct_radio_button is clickedd successfully!!");
        ExtentLogger.pass("I INeedToEditAUserForAProduct_radio_button is clickedd successfully!!", true);
        waitUntilVisible("next_button_3", "xpath", 30);
        clickElement(getElementByXpath("next_button_3"));
        System.out.println("next_button_3 is clickedd successfully!!");
        ExtentLogger.pass("next_button_3 is clickedd successfully!!", true);

        return this;
    }

    //Subbu
    //Added method for radio btn 'I have a question about setup' selection
    public ProductPage ReasonDropDown_IHaveAQuestionAboutSetup() throws InterruptedException, IOException {
        Thread.sleep(2000);
        waitUntilVisible("IHaveAQuestionAboutSetup_radio_button", "xpath", 30);
        clickElement(getElementByXpath("IHaveAQuestionAboutSetup_radio_button"));
        System.out.println("I IHaveAQuestionAboutSetup_radio_button is clickedd successfully!!");
        ExtentLogger.pass("I IHaveAQuestionAboutSetup_radio_button is clickedd successfully!!", true);
        waitUntilVisible("next_button_3", "xpath", 30);
        clickElement(getElementByXpath("next_button_3"));
        System.out.println("next_button_3 is clickedd successfully!!");
        ExtentLogger.pass("next_button_3 is clickedd successfully!!", true);
        return this;
    }


    public ProductPage ReasonDropDown_ProductUserASProductAdmin() throws InterruptedException, IOException {
        Thread.sleep(2000);
        waitUntilVisible("ProductUserAsAdminRadioButton_Reason", "xpath", 30);
        clickElement(getElementByXpath("ProductUserAsAdminRadioButton_Reason"));
        System.out.println("product user as a admin_radio_button is clickedd successfully!!");
        ExtentLogger.pass("product user as a admin_radio_button is clickedd successfully!!", true);
        waitUntilVisible("next_button_3", "xpath", 30);
        clickElement(getElementByXpath("next_button_3"));
        System.out.println("next_button_3 is clickedd successfully!!");
        ExtentLogger.pass("next_button_3 is clickedd successfully!!", true);
        return this;
    }


    public ProductPage clearTelephone() throws InterruptedException, IOException {

        waitTillElemenetVisible("Telephone");
        clickElement(getElementByXpath("Telephone"));
        WebElement phoneNumberTextBox = getElementByXpath("Telephone");
        phoneNumberTextBox.sendKeys(Keys.CONTROL, Keys.chord("a"));
        phoneNumberTextBox.sendKeys(Keys.BACK_SPACE);
        Thread.sleep(3000);
        ExtentLogger.pass("Clear the telephone number field", true);
        return this;

    }

    public ProductPage validateTelephoneMandatoryMessage() throws InterruptedException, IOException {


        String warning = getElementText(getElementByXpath("phoneNumberEmptyValidation"));
        Boolean b = warning.equalsIgnoreCase("Enter a phone number.");
        Assert.assertTrue(b);
        ExtentLogger.pass("Submitting ticket with empty Phone number is validated", true);
        log.info("The obtained warning is " + warning);

        return this;

    }

    public ProductPage validateSubjectMandatoryMessage() throws InterruptedException, IOException {


        String warning = getElementText(getElementByXpath("subjectEmptyValidation"));
        Boolean b = warning.equalsIgnoreCase("Enter a subject.");
        Assert.assertTrue(b);
        ExtentLogger.pass("Submitting ticket with empty Subject is validated", true);
        log.info("The obtained warning is " + warning);

        return this;

    }

    public ProductPage validateDescriptionMandatoryMessage() throws InterruptedException, IOException {


        String warning = getElementText(getElementByXpath("descriptionEmptyValidation"));
        Boolean b = warning.equalsIgnoreCase("Enter a description.");
        Assert.assertTrue(b);
        ExtentLogger.pass("Submitting ticket with empty Description is validated", true);
        log.info("The obtained warning is " + warning);

        return this;

    }

    public ProductPage validateSubjectInvalidMessage() throws InterruptedException, IOException {


        String warning = getElementText(getElementByXpath("subjectEmptyValidation"));
        Boolean b = warning.equalsIgnoreCase("Max message length of 35 characters reached.");
        Assert.assertTrue(b);
        ExtentLogger.pass("Submitting ticket with invalid Subject is validated", true);
        log.info("The obtained warning is " + warning);

        return this;

    }

    public ProductPage validateDescriptionInvalidMessage() throws InterruptedException, IOException {


        String warning = getElementText(getElementByXpath("descriptionEmptyValidation"));
        Boolean b = warning.equalsIgnoreCase("Max message length of 2000 characters reached.");
        Assert.assertTrue(b);
        ExtentLogger.pass("Submitting ticket with invalid Description is validated", true);
        log.info("The obtained warning is " + warning);

        return this;

    }

    public ProductPage validateTelephoneInvalidMessage() throws InterruptedException, IOException {


        String warning = getElementText(getElementByXpath("phoneNumberEmptyValidation"));
        Boolean b = warning.equalsIgnoreCase("Enter a valid phone number.");
        Assert.assertTrue(b);
        ExtentLogger.pass("Submitting ticket with invalid Phone number is validated", true);
        log.info("The obtained warning is " + warning);

        return this;

    }


    public ProductPage openFirstTicket() throws InterruptedException, IOException {


        waitTillElemenetVisible("openFirstRecord");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,900)");
        Thread.sleep(3000);
        ExtentLogger.pass("Opening first open ticket", true);
        clickElement(getElementByXpath("openFirstRecord"));
        return this;

    }

    public ProductPage openTicket(ProductPage p) throws InterruptedException, IOException {


        waitTillElemenetVisible("openFirstRecord");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,900)");
        Thread.sleep(3000);
        driver.findElement(By.xpath("//td[text()='"+p.ticketNumber+"']//preceding-sibling::td[2]//a")).click();
        ExtentLogger.pass("Opening created ticket", true);
        return this;

    }

    public ProductPage openFirstResolvedTicket() throws InterruptedException, IOException {

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,900)");
        Thread.sleep(3000);
        waitTillElemenetVisible("openFirstResolvedRecord");
        ExtentLogger.pass("Opening first resolved ticket", true);
        clickElement(getElementByXpath("openFirstResolvedRecord"));
        return this;

    }
    public ProductPage waitForThreeMinutes() throws InterruptedException, IOException {


        Thread.sleep(30000);
        Thread.sleep(30000);
        Thread.sleep(30000);
        Thread.sleep(30000);
        Thread.sleep(30000);
        Thread.sleep(30000);
        Thread.sleep(30000);
        Thread.sleep(30000);
        Thread.sleep(30000);
        Thread.sleep(30000);



        return this;

    }
    String description1="";
    public ProductPage uploadDifferenttypesOfAttachment() throws InterruptedException, IOException {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,750)");
        Thread.sleep(3000);
        String base = System.getProperty("user.dir");
        System.out.println(base);
        driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//dummy.pdf");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//PNGfile.png");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//picjpg.jpg");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//test.docx");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//Book1.xlsx");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//present.pptx");
        Thread.sleep(1000);
        description1 = fake.regexify("[a-z]{15}");
        waitTillElemenetVisible("Description");
        clickElement(getElementByXpath("Description"));
        sendKeysTotheElement("Description", description1);
        ExtentLogger.pass("Description is entered successfully...", true);
        waitTillElemenetVisible("Uploadthefiles");
        clickElement(getElementByXpath("Uploadthefiles"));
        ExtentLogger.pass("Uploaded the file", true);
        Thread.sleep(3000);
        return this;

    }
    public ProductPage clickOnUpload() throws InterruptedException, IOException {
    waitTillElemenetVisible("Uploadthefiles");
    clickElement(getElementByXpath("Uploadthefiles"));
        ExtentLogger.pass("Uploaded the file", true);
        Thread.sleep(3000);
        return this;

}
    public ProductPage countTheAttachmentNumberBeforeUploading() throws InterruptedException, IOException {

        waitTillElemenetVisible("attachmentCount");
        String attachmentCount = getElementText(getElementByXpath("attachmentCount"));
        System.out.println(attachmentCount);
        char c[] = attachmentCount.toCharArray();
        int length = attachmentCount.length();
        System.out.println(c[length - 2]);
        attachmentCountinInt = Integer.parseInt(String.valueOf(c[length - 2]));
        System.out.println(attachmentCountinInt);
        log.info("The obtained number of attachment is " + attachmentCountinInt);
        ExtentLogger.pass("Number of attachment before uploading" + attachmentCountinInt, true);
        return this;

    }
    public ProductPage countTheAttachmentNumberAfterSingleUploading() throws InterruptedException, IOException {
        int attachmentCountinIntafter=0;
        waitTillElemenetVisible("attachmentCount");
        String attachmentCount = getElementText(getElementByXpath("attachmentCount"));
        System.out.println(attachmentCount);
        char c[] = attachmentCount.toCharArray();
        int length = attachmentCount.length();
        System.out.println(c[length - 2]);
        attachmentCountinIntafter = Integer.parseInt(String.valueOf(c[length - 2]));
        System.out.println(attachmentCountinIntafter);
        Assert.assertEquals(attachmentCountinIntafter,attachmentCountinInt+1);
        log.info("The obtained number of attachment is " + attachmentCountinIntafter);
        ExtentLogger.pass("Number of attachment after uploading" + attachmentCountinIntafter, true);
        return this;

    }

    public ProductPage countTheAttachmentNumberAfterUploading() throws InterruptedException, IOException {
        waitTillElemenetVisible("Uploadthefiles");
        Thread.sleep(20000);
        driver.navigate().refresh();
        Thread.sleep(15000);
        waitTillElemenetVisible("attachmentCount");
        String attachmentCount = getElementText(getElementByXpath("attachmentCount"));
        System.out.println(attachmentCount);
        char c[] = attachmentCount.toCharArray();
        int length = attachmentCount.length();
        System.out.println(c[length - 2]);
        int attachmentCountinIntafterUploading = Integer.parseInt(String.valueOf(c[length - 2]));
        System.out.println(attachmentCountinIntafterUploading);
        int differnce = attachmentCountinIntafterUploading - attachmentCountinInt;
        Assert.assertTrue(differnce == 6);
        log.info("The number of attachment is " + attachmentCountinIntafterUploading);
        ExtentLogger.pass("Number of attachment after uploading" + attachmentCountinIntafterUploading, true);
        String desc1 = getElementText(getElementByXpath("DescriptionInComment"));
        Assert.assertTrue(description1.contains(desc1.trim()));
        ExtentLogger.pass("Description is visible in comments",true);
        return this;

    }

    public ProductPage deleteTheAttachmentFromTop() throws InterruptedException, IOException {
        Thread.sleep(10000);
        waitTillElemenetVisible("AttachDropdownfromTop");
        clickElement(getElementByXpath("AttachDropdownfromTop"));
        waitTillElemenetVisible("DeletebuttonfromAttachmentfromTop");
        clickElement(getElementByXpath("DeletebuttonfromAttachmentfromTop"));
        ExtentLogger.pass("Deleting the attachment", true);

        waitTillElemenetVisible("Deleteattachmentconfirmbutton");
        clickElement(getElementByXpath("Deleteattachmentconfirmbutton"));


        return this;

    }

    public ProductPage countTheAttachmentNumberAfterDeletingFromTop() throws InterruptedException, IOException {
        Thread.sleep(15000);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-750)");
        Thread.sleep(3000);
        waitTillElemenetVisible("attachmentCount");
        String attachmentCount = getElementText(getElementByXpath("attachmentCount"));
        System.out.println(attachmentCount);
        char c[] = attachmentCount.toCharArray();
        int length = attachmentCount.length();
        System.out.println(c[length - 2]);
        int attachmentCountinIntafterUploading = Integer.parseInt(String.valueOf(c[length - 2]));
        System.out.println(attachmentCountinIntafterUploading);

        Assert.assertTrue(attachmentCountinIntafterUploading == 5);
        log.info("The obtained no. of attachment is " + attachmentCountinIntafterUploading);
        ExtentLogger.pass("Number of attachment after deleting from top section- " + attachmentCountinIntafterUploading, true);

        return this;

    }

    public ProductPage countTheAttachmentNumberAfterDeletingSingleAttachmentFromTop() throws InterruptedException, IOException {
        Thread.sleep(15000);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-750)");
        Thread.sleep(3000);
        waitTillElemenetVisible("attachmentCount");
        String attachmentCount = getElementText(getElementByXpath("attachmentCount"));
        System.out.println(attachmentCount);
        char c[] = attachmentCount.toCharArray();
        int length = attachmentCount.length();
        System.out.println(c[length - 2]);
        int attachmentCountinIntafterUploading = Integer.parseInt(String.valueOf(c[length - 2]));
        System.out.println(attachmentCountinIntafterUploading);

        Assert.assertTrue(attachmentCountinIntafterUploading == 0);
        log.info("The obtained no. of attachment is " + attachmentCountinIntafterUploading);
        ExtentLogger.pass("Number of attachment after deleting from top section- " + attachmentCountinIntafterUploading, true);

        return this;

    }

    public ProductPage deleteTheAttachmentFromDown() throws InterruptedException, IOException {
        Thread.sleep(3000);
        waitTillElemenetVisible("AttachDropdownfromDown");
        clickElement(getElementByXpath("AttachDropdownfromDown"));
        waitTillElemenetVisible("DeletebuttonfromAttachmentfromDown");
        clickElement(getElementByXpath("DeletebuttonfromAttachmentfromDown"));
        ExtentLogger.pass("Deleting the attachment", true);
        waitTillElemenetVisible("Deleteattachmentconfirmbutton");
        clickElement(getElementByXpath("Deleteattachmentconfirmbutton"));


        return this;

    }

    public ProductPage countTheAttachmentNumberAfterDeletingFromDown() throws InterruptedException, IOException {
        Thread.sleep(15000);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-750)");
        Thread.sleep(3000);
        waitTillElemenetVisible("attachmentCount");
        String attachmentCount = getElementText(getElementByXpath("attachmentCount"));
        System.out.println(attachmentCount);
        char c[] = attachmentCount.toCharArray();
        int length = attachmentCount.length();
        System.out.println(c[length - 2]);
        int attachmentCountinIntafterUploading = Integer.parseInt(String.valueOf(c[length - 2]));
        System.out.println(attachmentCountinIntafterUploading);

        Assert.assertTrue(attachmentCountinIntafterUploading == 4);
        log.info("The obtained no. of attachment is " + attachmentCountinIntafterUploading);
        ExtentLogger.pass("Number of attachment after deleting from below section- " + attachmentCountinIntafterUploading, true);

        return this;

    }

    public ProductPage downloadTheAttachmentFromTop() throws InterruptedException, IOException {
        Thread.sleep(3000);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-750)");
        Thread.sleep(3000);
        waitTillElemenetVisible("DownloadArrowFromTop");
        clickElement(getElementByXpath("DownloadArrowFromTop"));
        Thread.sleep(3000);
        ExtentLogger.pass("Trying to download the attachment from top section", true);
        waitTillElemenetVisible("DownloadButtonFromTop");
        clickElement(getElementByXpath("DownloadButtonFromTop"));
        ExtentLogger.pass("Downloading the attachment", true);
        Thread.sleep(4000);
        String home = System.getProperty("user.home");
        // File file = new File(home+"/Downloads/" + fileName + ".txt");
        //System.out.println("Path "+home);
        Boolean value = isFileDownloaded(home + "\\Downloads", "picjpg");

        Assert.assertTrue(value);
        ExtentLogger.pass("Downloaded the attachment from top section and verified", true);


        return this;

    }

    public boolean isFileDownloaded(String downloadPath, String fileName) {
        File dir = new File(downloadPath);
        //System.out.println("path par "+downloadPath);
        File[] dirContents = dir.listFiles();

        for (int i = 0; i < dirContents.length; i++) {
            if (dirContents[i].getName().contains(fileName)) {
                // File has been found, it can now be deleted:
                dirContents[i].delete();
                return true;
            }
        }
        return false;
    }

    public ProductPage downloadTheAttachmentFromdown() throws InterruptedException, IOException {
        Thread.sleep(3000);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,850)");
        Thread.sleep(3000);
        waitTillElemenetVisible("DownloadArrowFromDown");
        clickElement(getElementByXpath("DownloadArrowFromDown"));
        Thread.sleep(3000);
        ExtentLogger.pass("Trying to download the attachment from below section", true);

        waitTillElemenetVisible("DownloadButtonFromDown");
        clickElement(getElementByXpath("DownloadButtonFromDown"));
        ExtentLogger.pass("Downloading the attachment", true);
        Thread.sleep(4000);
        String home = System.getProperty("user.home");
        // File file = new File(home+"/Downloads/" + fileName + ".txt");
        //System.out.println("Path "+home);
        Boolean value = isFileDownloaded(home + "\\Downloads", "test");

        Assert.assertTrue(value);
        ExtentLogger.pass("Downloaded the attachment from down section and verified", true);


        return this;

    }

    public ProductPage uploadmultipleAttachments() throws InterruptedException, IOException {
        Thread.sleep(15000);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,750)");
        Thread.sleep(3000);
        String base = System.getProperty("user.dir");
        System.out.println(base);
        driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//dummy.pdf" + "\n" + base + "//Attachments//PNGfile.png"
                + "\n" + base + "//Attachments//dummy.pdf" + "\n" + base + "//Attachments//PNGfile.png"
                + "\n" + base + "//Attachments//dummy.pdf" + "\n" + base + "//Attachments//PNGfile.png"
                + "\n" + base + "//Attachments//dummy.pdf" + "\n" + base + "//Attachments//PNGfile.png"
                + "\n" + base + "//Attachments//dummy.pdf" + "\n" + base + "//Attachments//PNGfile.png"
                + "\n" + base + "//Attachments//dummy.pdf" + "\n" + base + "//Attachments//PNGfile.png");
        // Thread.sleep(3000);

        waitTillElemenetVisible("MorethanTenAttachmentsToastMessage");

        String warning = getElementText(getElementByXpath("MorethanTenAttachmentsToastMessage"));
        Boolean b = warning.equalsIgnoreCase("You can only attach a maximum of 10 files at the time. If you have more files to send, attach them to another message.");
        Assert.assertTrue(b);
        ExtentLogger.pass("Error message appeared when uploading more than 10 files at once", true);

        return this;

    }

    public ProductPage uploadsevenmbAttachment() throws InterruptedException, IOException {
        Thread.sleep(15000);
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,750)");
        Thread.sleep(3000);
        String base = System.getProperty("user.dir");
        System.out.println(base);
        driver.findElement(By.xpath("//input[@id='filesUpload']")).
                sendKeys(base + "//Attachments//EightMBFile.pdf");
        // Thread.sleep(3000);

        waitTillElemenetVisible("MorethanTenAttachmentsToastMessage");

        String warning = getElementText(getElementByXpath("MorethanTenAttachmentsToastMessage"));
        Boolean b = warning.equalsIgnoreCase("Your total attachments can’t exceed 7 MB. Reduce your file size and try uploading again.");
        Assert.assertTrue(b);
        ExtentLogger.pass("Error message appeared when uploading file of more than 7 MB", true);

        return this;

    }

    public ProductPage validateopenticketstable() throws InterruptedException, IOException {
        Thread.sleep(3000);
        ExtentLogger.pass("navigate support page successfully", true);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(2000);

        if (getElementByXpath("OpenTicketstable").isDisplayed()) {
            ExtentLogger.pass("user is able to view open logged tickets table Successfully!", true);
            Assert.assertTrue(true, "open tickets table displayed successfully!");

        }


        return this;

    }


    public ProductPage validateopenticketstable_UnderFormatOpenTicketstab() throws InterruptedException, IOException {
        Thread.sleep(3000);
        ExtentLogger.pass("navigate support page successfully", true);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(2000);

        String subtext = getElementText(getElementByXpath("subject_openticketstab"));
        Boolean b = subtext.contains("Subject");
        Assert.assertTrue(b);
        ExtentLogger.pass("Subject text format succesfully displayed under open tickets tab", true);


        Thread.sleep(1000);
        String statustext = getElementText(getElementByXpath("status_openticketstab"));
        Boolean s = statustext.contains("Status");
        Assert.assertTrue(s);
        ExtentLogger.pass("status text format succesfully displayed under open tickets tab", true);


        Thread.sleep(1000);
        String casenumtxt = getElementText(getElementByXpath("casenumber_openticketstab"));
        Boolean c = casenumtxt.contains("Case number");
        Assert.assertTrue(c);
        ExtentLogger.pass("case number text displayed under open tickets tab", true);

        Thread.sleep(1000);
        String datesubmittedtxt = getElementText(getElementByXpath("datesubmitted_openticketstab"));
        Boolean d = datesubmittedtxt.contains("Date submitted");
        Assert.assertTrue(d);
        ExtentLogger.pass("date submitted text displayed under open tickets tab", true);


        Thread.sleep(1000);
        String ticketcategorytxt = getElementText(getElementByXpath("ticketcategory_openticketstab"));
        Boolean t = ticketcategorytxt.contains("Ticket category");
        Assert.assertTrue(t);
        ExtentLogger.pass("ticket category text displayed under open tickets tab", true);

        Thread.sleep(1000);
        String lastupdatedtxt = getElementText(getElementByXpath("lastupdated_openticketstab"));
        Boolean l = lastupdatedtxt.contains("Last updated");
        Assert.assertTrue(l);
        ExtentLogger.pass("last updated text displayed under open tickets tab", true);


        return this;

    }

    public ProductPage validatnotickets_UnderResolvedTicketstab() throws InterruptedException, IOException {

        Thread.sleep(3000);
        ExtentLogger.pass("navigate support page successfully", true);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(2000);

        waitTillElemenetVisible("resolvedticketstab");
        clickElement(getElementByXpath("resolvedticketstab"));
        Thread.sleep(2000);
        ExtentLogger.pass("clicked resolved tickets tab successfuly!", true);


        Thread.sleep(1000);
        String subtext = getElementText(getElementByXpath("youdonthavetxt_resolvedticketstab"));
        Boolean b = subtext.contains("You don’t have any resolved tickets.");
        Assert.assertTrue(b);
        ExtentLogger.pass("You don’t have any resolved tickets. displayed successfully!", true);


        return this;

    }

    public ProductPage reopenticket(String attachment) throws InterruptedException, IOException {
        String base = System.getProperty("user.dir");
        Thread.sleep(3000);
        waitTillElemenetVisible("ReopenTicket");
        clickElement(getElementByXpath("ReopenTicket"));
        waitTillElemenetVisible("ReopenTicket_Description");
        clickElement(getElementByXpath("ReopenTicket_Description"));
        sendKeysTotheElement("ReopenTicket_Description", "My issue is still not resolved.");
        ExtentLogger.pass("Added reopening comments....", true);
        if (attachment.equalsIgnoreCase("Yes")) {
            driver.findElement(By.xpath("//input[@id='filesUpload']")).sendKeys(base + "//Attachments//reopen.pdf");
            Thread.sleep(5000);
            ExtentLogger.pass("Upload the file", true);
            ExtentLogger.pass("Added attachment....", true);
            // isAttachmentVisible("Yes");

        } else {

            ExtentLogger.pass("Not added any attachment....", true);
        }
        waitTillElemenetVisible("ReopenTicket_Submission");
        clickElement(getElementByXpath("ReopenTicket_Submission"));
        Thread.sleep(3000);
        waitTillElemenetVisible("ReopenTicket_Details");
        clickElement(getElementByXpath("ReopenTicket_Details"));


        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(3000);

        boolean res = driver.findElement(By.xpath("//*[text()='My issue is still not resolved.']/parent::div")).isDisplayed();
        //boolean attachmentVisible=driver.findElement(By.xpath("//div[@title='dummy']")).isDisplayed();
        System.out.println(res);
        Assert.assertTrue(res);
        js.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(3000);

        if (attachment.equalsIgnoreCase("Yes")) {

            isAttachmentVisible("Yes");

            ExtentLogger.pass("Reopen description is visible along with Attachment!", true);
        } else {
            ExtentLogger.pass("Not added any attachment,hence no attachment is visible....", true);
        }


        return this;

    }

    public ProductPage openFirstResolvedTicketHavingResolvedStatus() throws InterruptedException, IOException {

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,1100)");
        Thread.sleep(3000);
        for (int i = 1; i <= 10; i++) {
            driver.findElement(By.xpath("((//th[text()='Subject']/ancestor::table/tbody)[2]//a)[" + i + "]")).click();
            Thread.sleep(5000);
            boolean value = false;
            try {
                value = driver.findElement(By.xpath("//*[text()='Reopen ticket']/parent::button")).isDisplayed();
                System.out.println("Value is " + value);
            } catch (Exception e) {

            }
            if (value == false) {
                driver.navigate().back();
                Thread.sleep(4000);
            } else {
                break;
            }
        }

        ExtentLogger.pass("Opening first resolved ticket which is not cancelled", true);
        // clickElement(getElementByXpath("openFirstResolvedRecord"));
        return this;

    }

    public ProductPage billingPagination() throws InterruptedException, IOException {


        jse.executeScript("window.scrollBy(0,750)");
        Thread.sleep(2000);
        String paginationValue = driver.findElement(By.xpath("//*[@class='tr-Dropdown-header']/span")).getText();
        Assert.assertEquals(paginationValue, "10");
        ExtentLogger.pass("Pagination is set to 10", true);
        clickElement(getElementByXpath("BillingPagination"));
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id='25']")).click();
        Thread.sleep(2000);
        paginationValue = driver.findElement(By.xpath("//*[@class='tr-Dropdown-header']/span")).getText();
        Assert.assertEquals(paginationValue, "25");
        ExtentLogger.pass("Pagination is set to 25", true);
        clickElement(getElementByXpath("BillingPagination"));
        Thread.sleep(1000);
        driver.findElement(By.xpath(("//*[@id='50']"))).click();
        Thread.sleep(2000);
        paginationValue = driver.findElement(By.xpath("//*[@class='tr-Dropdown-header']/span")).getText();
        Assert.assertEquals(paginationValue, "50");
        ExtentLogger.pass("Pagination is set to 50", true);
        clickElement(getElementByXpath("BillingPagination"));
        Thread.sleep(1000);
        driver.findElement(By.xpath(("//*[@id='100']"))).click();
        Thread.sleep(2000);
        paginationValue = driver.findElement(By.xpath("//*[@class='tr-Dropdown-header']/span")).getText();
        Assert.assertEquals(paginationValue, "100");
        ExtentLogger.pass("Pagination is set to 100", true);

        return this;

    }

    public ProductPage paginationSetToHundred() throws InterruptedException, IOException {
        waitTillElemenetVisible("BillingPagination");
        clickElement(getElementByXpath("BillingPagination"));
        Thread.sleep(1000);
        driver.findElement(By.xpath(("//*[@id='100']"))).click();
        Thread.sleep(2000);
        String paginationValue = driver.findElement(By.xpath("//*[@class='tr-Dropdown-header']/span")).getText();
        Assert.assertEquals(paginationValue, "100");
        ExtentLogger.pass("Pagination is set to 100", true);

        return this;
    }

    public ProductPage getrecordscount() throws InterruptedException, IOException {
        waitTillElemenetVisible("BillingPagination");
        Boolean b = true;
        while (true) {
            WebElement userNameTxt = driver.findElement(By.xpath("//div[contains(text(),'Viewing')]"));
            System.out.println(userNameTxt);
            JavascriptExecutor js = (JavascriptExecutor) driver;
            String lastRecord = js.executeScript("return arguments[0].innerHTML", userNameTxt).toString();
            System.out.println(lastRecord);
            String d[]=lastRecord.split(" – ");
            lastRecord=d[1];
            // lastRecord = lastRecord.substring(lastRecord.indexOf("-") + 1).trim();
            // lastRecordNumber = Integer.parseInt(lastRecord.substring(lastRecord.length() - 2));
            lastRecordNumber = Integer.parseInt(lastRecord);
            driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).click();
            Thread.sleep(3000);
            System.out.println("last is " + lastRecordNumber);
            if (b == false)
                break;
            b = driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).isEnabled();

        }

        //ExtentLogger.pass("Pagination is set to 100", true);

        return this;
    }

    public ProductPage addOneEbillingContact() throws InterruptedException, IOException {
        Boolean a= true;
        int i=1;
        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));
        Thread.sleep(1000);
        String firsteblillingName = fake.name().firstName();
        String lastebillingName = fake.name().lastName();
        String emailId = firsteblillingName + lastebillingName + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling");
        clearText(getElementByXpath("FirstNameEbilling"));
        sendKeysTotheElement("FirstNameEbilling", firsteblillingName);
        waitTillElemenetVisible("LastNameEbilling");
        clearText(getElementByXpath("LastNameEbilling"));
        sendKeysTotheElement("LastNameEbilling", lastebillingName);
        waitTillElemenetVisible("EmailEbilling");
        clearText(getElementByXpath("EmailEbilling"));
        sendKeysTotheElement("EmailEbilling", emailId);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("SubmitEbillingContact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("SubmitEbillingContact"));
        Thread.sleep(3000);
        waitTillElemenetVisible("ManageEbillingContact");
        ExtentLogger.pass("Click on manage ebilling contact", true);
        Thread.sleep(1000);
        boolean firstnamevalue=driver.findElement(By.xpath("//li[contains(text(),'"+firsteblillingName+"')]")).isDisplayed();
        boolean lastnamevalue=driver.findElement(By.xpath("//li[contains(text(),'"+lastebillingName+"')]")).isDisplayed();
        Assert.assertTrue(firstnamevalue);
        Assert.assertTrue(lastnamevalue);
        Thread.sleep(1000);
        clickElement(getElementByXpath("ManageEbillingContact"));
        waitTillElemenetVisible("AddEbillingContact");
        Thread.sleep(4000);
        driver.navigate().refresh();
        //  WebElement userNameTxt = driver.findElement(By.xpath("//div[contains(text(),'Viewing')]"));
        //  System.out.println(userNameTxt);
       /* JavascriptExecutor js = (JavascriptExecutor) driver;
        String lastRecord = js.executeScript("return arguments[0].innerHTML",userNameTxt).toString();
        System.out.println(lastRecord);
        lastRecord=lastRecord.substring(lastRecord.indexOf("-")+1).trim();*/
        lastRecordNumber = lastRecordNumber + 1;
        System.out.println(lastRecordNumber);
        Thread.sleep(2000);
        boolean result = false;
        while (true) {
            try {
                int size=driver.findElements(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])")).size();
                for(int j=1;j<=size;j++) {
                    WebElement ele = driver.findElement(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])[" + j + "]"));
                    String name = getElementTextbyElement(ele);
                    System.out.println(name);
                    System.out.println(ele);

                    if (name.contains(firsteblillingName) && name.contains(lastebillingName)) {
                        result = true;
                        ExtentLogger.pass("Newly added ebilling contact is present", true);
                        break;
                    }
                }
                if (a == false || result==true)
                    break;
                driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).click();

                a = driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).isEnabled();
                i++;
                System.out.println("value of i is" +i);

            } catch (Exception e) {

            }
        }
        Assert.assertTrue(result);
        firsteblillingName = firsteblillingName.toLowerCase();
        WebElement ele1 = driver.findElement(By.xpath("//tbody[@class='tr-DataGrid-tableBody']//th[contains(text(),'" + firsteblillingName + "')]/following-sibling::td[1]"));
        String email = getElementTextbyElement(ele1);
        System.out.println(ele1);
        System.out.println(email);
        Assert.assertEquals(emailId, email.trim());


   /*     for (int i = 1; i <= lastRecordNumber; i++) {
            WebElement ele = driver.findElement(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])["+i+"]"));
            String name = getElementTextbyElement(ele);
            System.out.println(name);
            System.out.println(ele);

            if (name.contains(firsteblillingName) && name.contains(lastebillingName)) {
                result=true;
                ExtentLogger.pass("Newly added ebilling contact is present", true);
                break;
            }

        }
        Assert.assertTrue(result);
        firsteblillingName=firsteblillingName.toLowerCase();
        WebElement ele1 = driver.findElement(By.xpath("//tbody[@class='tr-DataGrid-tableBody']//th[contains(text(),'"+firsteblillingName+"')]/following-sibling::td[1]"));
        String email = getElementTextbyElement(ele1);
        System.out.println(ele1);
        System.out.println(email);
        Assert.assertEquals(emailId,email.trim());*/
        return this;
    }

    String firsteblillingNameupdate="";
    String lastebillingNameupdate="";
    public ProductPage updateOneEbillingContact() throws InterruptedException, IOException {
        Boolean a= true;
        int i=1;
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        Thread.sleep(1000);
        firsteblillingNameupdate = fake.name().firstName();
        lastebillingNameupdate = fake.name().lastName();
        String emailIdupdate = firsteblillingNameupdate + lastebillingNameupdate + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling");
        clearText(getElementByXpath("FirstNameEbilling"));
        sendKeysTotheElement("FirstNameEbilling", firsteblillingNameupdate);
        waitTillElemenetVisible("LastNameEbilling");
        clearText(getElementByXpath("LastNameEbilling"));
        sendKeysTotheElement("LastNameEbilling", lastebillingNameupdate);
        waitTillElemenetVisible("EmailEbilling");
        clearText(getElementByXpath("EmailEbilling"));
        sendKeysTotheElement("EmailEbilling", emailIdupdate);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("UpdateEbilling");
        ExtentLogger.pass("Click on Update Contact button to update ebilling contact", true);
        clickElement(getElementByXpath("UpdateEbilling"));
        Thread.sleep(3000);
        driver.navigate().refresh();

        lastRecordNumber = lastRecordNumber + 1;
        System.out.println(lastRecordNumber);
        Thread.sleep(2000);
        boolean result = false;
        while (true) {
            try {
                int size=driver.findElements(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])")).size();
                for(int j=1;j<=size;j++) {
                    WebElement ele = driver.findElement(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])[" + j + "]"));
                    String name = getElementTextbyElement(ele);
                    System.out.println(name);
                    System.out.println(ele);

                    if (name.contains(firsteblillingNameupdate) && name.contains(lastebillingNameupdate)) {
                        result = true;
                        ExtentLogger.pass("Newly added ebilling contact is present", true);
                        break;
                    }
                }
                if (a == false || result==true)
                    break;
                driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).click();

                a = driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).isEnabled();
                i++;
                System.out.println("value of i is" +i);

            } catch (Exception e) {

            }
        }
        Assert.assertTrue(result);
        firsteblillingNameupdate = firsteblillingNameupdate.toLowerCase();
        WebElement ele1 = driver.findElement(By.xpath("//tbody[@class='tr-DataGrid-tableBody']//th[contains(text(),'" + firsteblillingNameupdate + "')]/following-sibling::td[1]"));
        String email = getElementTextbyElement(ele1);
        System.out.println(ele1);
        System.out.println(email);
        Assert.assertEquals(emailIdupdate, email.trim());


   /*     for (int i = 1; i <= lastRecordNumber; i++) {
            WebElement ele = driver.findElement(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])["+i+"]"));
            String name = getElementTextbyElement(ele);
            System.out.println(name);
            System.out.println(ele);

            if (name.contains(firsteblillingName) && name.contains(lastebillingName)) {
                result=true;
                ExtentLogger.pass("Newly added ebilling contact is present", true);
                break;
            }

        }
        Assert.assertTrue(result);
        firsteblillingName=firsteblillingName.toLowerCase();
        WebElement ele1 = driver.findElement(By.xpath("//tbody[@class='tr-DataGrid-tableBody']//th[contains(text(),'"+firsteblillingName+"')]/following-sibling::td[1]"));
        String email = getElementTextbyElement(ele1);
        System.out.println(ele1);
        System.out.println(email);
        Assert.assertEquals(emailId,email.trim());*/
        return this;
    }

    public void validationOfEbillingContact(String firsteblillingName, String lastebillingName, String emailId ) throws InterruptedException, IOException {
        Boolean a= true;
        int i=1;
        lastRecordNumber = lastRecordNumber + 1;
        System.out.println(lastRecordNumber);
        Thread.sleep(2000);
        boolean result = false;
        while (true) {
            try {
                int size=driver.findElements(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])")).size();
                for(int j=1;j<=size;j++) {
                    WebElement ele = driver.findElement(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])[" + j + "]"));
                    String name = getElementTextbyElement(ele);
                    System.out.println(name);
                    System.out.println(ele);

                    if (name.contains(firsteblillingName) && name.contains(lastebillingName)) {
                        result = true;
                        ExtentLogger.pass("Newly added ebilling contact is present "+firsteblillingName+" "+lastebillingName, true);
                        break;
                    }
                }
                if (a == false || result==true)
                    break;
                driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).click();

                a = driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).isEnabled();
                i++;
                System.out.println("value of i is" +i);

            } catch (Exception e) {

            }
        }
        Assert.assertTrue(result);
        firsteblillingName = firsteblillingName.toLowerCase();
        WebElement ele1 = driver.findElement(By.xpath("//tbody[@class='tr-DataGrid-tableBody']//th[contains(text(),'" + firsteblillingName + "')]/following-sibling::td[1]"));
        String email = getElementTextbyElement(ele1);
        System.out.println(ele1);
        System.out.println(email);
        Assert.assertEquals(emailId, email.trim());
        driver.navigate().refresh();
    }

    public ProductPage addfiveEbillingContact() throws InterruptedException, IOException {

        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));

        Thread.sleep(1000);
        String firsteblillingName1 = fake.name().firstName();
        String lastebillingName1 = fake.name().lastName();
        String emailId1 = firsteblillingName1 + lastebillingName1 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling");
        sendKeysTotheElement("FirstNameEbilling", firsteblillingName1);
        waitTillElemenetVisible("LastNameEbilling");
        sendKeysTotheElement("LastNameEbilling", lastebillingName1);
        waitTillElemenetVisible("EmailEbilling");
        sendKeysTotheElement("EmailEbilling", emailId1);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("Addanotherebillingcontact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("Addanotherebillingcontact"));

        Thread.sleep(1000);
        String firsteblillingName2 = fake.name().firstName();
        String lastebillingName2 = fake.name().lastName();
        String emailId2 = firsteblillingName2 + lastebillingName2 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling2");
        sendKeysTotheElement("FirstNameEbilling2", firsteblillingName2);
        waitTillElemenetVisible("LastNameEbilling2");
        sendKeysTotheElement("LastNameEbilling2", lastebillingName2);
        waitTillElemenetVisible("EmailEbilling2");
        sendKeysTotheElement("EmailEbilling2", emailId2);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("Addanotherebillingcontact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("Addanotherebillingcontact"));


        Thread.sleep(1000);
        String firsteblillingName3 = fake.name().firstName();
        String lastebillingName3 = fake.name().lastName();
        String emailId3 = firsteblillingName3 + lastebillingName3 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling3");
        sendKeysTotheElement("FirstNameEbilling3", firsteblillingName3);
        waitTillElemenetVisible("LastNameEbilling3");
        sendKeysTotheElement("LastNameEbilling3", lastebillingName3);
        waitTillElemenetVisible("EmailEbilling3");
        sendKeysTotheElement("EmailEbilling3", emailId3);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("Addanotherebillingcontact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("Addanotherebillingcontact"));


        Thread.sleep(1000);
        String firsteblillingName4 = fake.name().firstName();
        String lastebillingName4 = fake.name().lastName();
        String emailId4 = firsteblillingName4 + lastebillingName4 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling4");
        sendKeysTotheElement("FirstNameEbilling4", firsteblillingName4);
        waitTillElemenetVisible("LastNameEbilling4");
        sendKeysTotheElement("LastNameEbilling4", lastebillingName4);
        waitTillElemenetVisible("EmailEbilling4");
        sendKeysTotheElement("EmailEbilling4", emailId4);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("Addanotherebillingcontact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("Addanotherebillingcontact"));


        Thread.sleep(1000);
        String firsteblillingName5 = fake.name().firstName();
        String lastebillingName5 = fake.name().lastName();
        String emailId5 = firsteblillingName5 + lastebillingName5 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling5");
        sendKeysTotheElement("FirstNameEbilling5", firsteblillingName5);
        waitTillElemenetVisible("LastNameEbilling5");
        sendKeysTotheElement("LastNameEbilling5", lastebillingName5);
        waitTillElemenetVisible("EmailEbilling5");
        sendKeysTotheElement("EmailEbilling5", emailId5);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("Addanotherebillingcontact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("Addanotherebillingcontact"));



        waitTillElemenetVisible("SubmitEbillingContact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("SubmitEbillingContact"));
        waitTillElemenetVisible("ManageEbillingContact");
        ExtentLogger.pass("Click on manage ebilling contact", true);
        Thread.sleep(1000);
        boolean firstnamevalue1=driver.findElement(By.xpath("//li[contains(text(),'"+firsteblillingName1+"')]")).isDisplayed();
        boolean lastnamevalue1=driver.findElement(By.xpath("//li[contains(text(),'"+lastebillingName1+"')]")).isDisplayed();
        Assert.assertTrue(firstnamevalue1);
        Assert.assertTrue(lastnamevalue1);
        boolean firstnamevalue2=driver.findElement(By.xpath("//li[contains(text(),'"+firsteblillingName2+"')]")).isDisplayed();
        boolean lastnamevalue2=driver.findElement(By.xpath("//li[contains(text(),'"+lastebillingName2+"')]")).isDisplayed();
        Assert.assertTrue(firstnamevalue2);
        Assert.assertTrue(lastnamevalue2);
        boolean firstnamevalue3=driver.findElement(By.xpath("//li[contains(text(),'"+firsteblillingName3+"')]")).isDisplayed();
        boolean lastnamevalue3=driver.findElement(By.xpath("//li[contains(text(),'"+lastebillingName3+"')]")).isDisplayed();
        Assert.assertTrue(firstnamevalue3);
        Assert.assertTrue(lastnamevalue3);
        boolean firstnamevalue4=driver.findElement(By.xpath("//li[contains(text(),'"+firsteblillingName4+"')]")).isDisplayed();
        boolean lastnamevalue4=driver.findElement(By.xpath("//li[contains(text(),'"+lastebillingName4+"')]")).isDisplayed();
        Assert.assertTrue(firstnamevalue4);
        Assert.assertTrue(lastnamevalue4);
        boolean firstnamevalue5=driver.findElement(By.xpath("//li[contains(text(),'"+firsteblillingName5+"')]")).isDisplayed();
        boolean lastnamevalue5=driver.findElement(By.xpath("//li[contains(text(),'"+lastebillingName5+"')]")).isDisplayed();
        Assert.assertTrue(firstnamevalue5);
        Assert.assertTrue(lastnamevalue5);
        Thread.sleep(1000);
        clickElement(getElementByXpath("ManageEbillingContact"));
        waitTillElemenetVisible("AddEbillingContact");
        Thread.sleep(4000);
        driver.navigate().refresh();

        validationOfEbillingContact(firsteblillingName1,lastebillingName1,emailId1);
        validationOfEbillingContact(firsteblillingName2,lastebillingName2,emailId2);
        validationOfEbillingContact(firsteblillingName3,lastebillingName3,emailId3);
        validationOfEbillingContact(firsteblillingName4,lastebillingName4,emailId4);
        validationOfEbillingContact(firsteblillingName5,lastebillingName5,emailId5);



        return this;
    }

    public ProductPage addmorethanfiveEbillingContact() throws InterruptedException, IOException {

        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));

        Thread.sleep(1000);
        String firsteblillingName1 = fake.name().firstName();
        String lastebillingName1 = fake.name().lastName();
        String emailId1 = firsteblillingName1 + lastebillingName1 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling");
        sendKeysTotheElement("FirstNameEbilling", firsteblillingName1);
        waitTillElemenetVisible("LastNameEbilling");
        sendKeysTotheElement("LastNameEbilling", lastebillingName1);
        waitTillElemenetVisible("EmailEbilling");
        sendKeysTotheElement("EmailEbilling", emailId1);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("Addanotherebillingcontact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("Addanotherebillingcontact"));

        Thread.sleep(1000);
        String firsteblillingName2 = fake.name().firstName();
        String lastebillingName2 = fake.name().lastName();
        String emailId2 = firsteblillingName2 + lastebillingName2 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling2");
        sendKeysTotheElement("FirstNameEbilling2", firsteblillingName2);
        waitTillElemenetVisible("LastNameEbilling2");
        sendKeysTotheElement("LastNameEbilling2", lastebillingName2);
        waitTillElemenetVisible("EmailEbilling2");
        sendKeysTotheElement("EmailEbilling2", emailId2);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("Addanotherebillingcontact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("Addanotherebillingcontact"));


        Thread.sleep(1000);
        String firsteblillingName3 = fake.name().firstName();
        String lastebillingName3 = fake.name().lastName();
        String emailId3 = firsteblillingName3 + lastebillingName3 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling3");
        sendKeysTotheElement("FirstNameEbilling3", firsteblillingName3);
        waitTillElemenetVisible("LastNameEbilling3");
        sendKeysTotheElement("LastNameEbilling3", lastebillingName3);
        waitTillElemenetVisible("EmailEbilling3");
        sendKeysTotheElement("EmailEbilling3", emailId3);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("Addanotherebillingcontact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("Addanotherebillingcontact"));


        Thread.sleep(1000);
        String firsteblillingName4 = fake.name().firstName();
        String lastebillingName4 = fake.name().lastName();
        String emailId4 = firsteblillingName4 + lastebillingName4 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling4");
        sendKeysTotheElement("FirstNameEbilling4", firsteblillingName4);
        waitTillElemenetVisible("LastNameEbilling4");
        sendKeysTotheElement("LastNameEbilling4", lastebillingName4);
        waitTillElemenetVisible("EmailEbilling4");
        sendKeysTotheElement("EmailEbilling4", emailId4);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        waitTillElemenetVisible("Addanotherebillingcontact");
        ExtentLogger.pass("Click on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("Addanotherebillingcontact"));


        Thread.sleep(1000);
        String firsteblillingName5 = fake.name().firstName();
        String lastebillingName5 = fake.name().lastName();
        String emailId5 = firsteblillingName5 + lastebillingName5 + "@test.com";
        waitTillElemenetVisible("FirstNameEbilling5");
        sendKeysTotheElement("FirstNameEbilling5", firsteblillingName5);
        waitTillElemenetVisible("LastNameEbilling5");
        sendKeysTotheElement("LastNameEbilling5", lastebillingName5);
        waitTillElemenetVisible("EmailEbilling5");
        sendKeysTotheElement("EmailEbilling5", emailId5);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        Thread.sleep(1000);
        jse.executeScript("window.scrollBy(0,200)");
        Thread.sleep(1000);
        String result=driver.findElement(By.xpath("//button[text()='Add another contact']")).getAttribute("disabled");
        System.out.println(result);
        Assert.assertEquals(result,"true");
        ExtentLogger.pass("Add another contact button is disabled", true);
        return this;
    }


    public ProductPage addOneEbillingContactWithoutEnteringMandatoryFields() throws InterruptedException, IOException {

        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));
        Thread.sleep(1000);
        waitTillElemenetVisible("FirstNameEbilling");
        clickElement(getElementByXpath("FirstNameEbilling"));
        waitTillElemenetVisible("LastNameEbilling");
        clickElement(getElementByXpath("LastNameEbilling"));
        waitTillElemenetVisible("EmailEbilling");
        clickElement(getElementByXpath("EmailEbilling"));
        ExtentLogger.pass("Clicking on the first name, last name and Email Address text box", true);
        waitTillElemenetVisible("SubmitEbillingContact");
        ExtentLogger.pass("Try clicking on Add Contact button to Add contact", true);
        clickElement(getElementByXpath("SubmitEbillingContact"));
        Thread.sleep(1000);
        boolean firstNameError=IsElementdisplayed(getElementByXpath("EbillingFirstNameError"));
        boolean lastNameError=IsElementdisplayed(getElementByXpath("EbillinglastNameError"));
        boolean emailIDError=IsElementdisplayed(getElementByXpath("EbillingemailIDError"));
        Assert.assertTrue(firstNameError);
        Assert.assertTrue(lastNameError);
        Assert.assertTrue(emailIDError);
        ExtentLogger.pass("Error Message is displayed", true);
        return this;
    }
    public ProductPage NoMoreAndAttachment() throws InterruptedException, IOException {
        Thread.sleep(1000);
        boolean noMoreAndAttachment=IsElementdisplayed(getElementByXpath("NoMoreComment"));

        Assert.assertTrue(noMoreAndAttachment);
        ExtentLogger.pass("No more support needed message and attachment is displayed",true);
        return  this;
    }
    public ProductPage descriptionWhileClosingTicket() throws InterruptedException, IOException {
        Thread.sleep(1000);
        boolean descvalue=IsElementdisplayed(driver.findElement(By.xpath("//p['"+description+"']")));

        Assert.assertTrue(descvalue);
        jse.executeScript("window.scrollBy(0,1000)");
        Thread.sleep(3000);
        boolean noMoreAndAttachment=IsElementdisplayed(getElementByXpath("NoMoreCommentOnly"));

        Assert.assertTrue(noMoreAndAttachment);
        ExtentLogger.pass("Description is displayed and No more support needed message is displayed",true);
        return  this;
    }
    public ProductPage addOneEbillingContactwithMaxchar() throws InterruptedException, IOException {

        waitTillElemenetVisible("AddEbillingContact");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-800)");
        Thread.sleep(2000);
        ExtentLogger.pass("Click on Add Contact", true);
        clickElement(getElementByXpath("AddEbillingContact"));
        Thread.sleep(1000);
        String firsteblillingName = fake.regexify("[a-z]{40}");
        String lastebillingName = fake.regexify("[a-z]{40}");
        String emailId = fake.regexify("[a-z]{111}") + "@test.commmmm";
        waitTillElemenetVisible("FirstNameEbilling");
        sendKeysTotheElement("FirstNameEbilling", firsteblillingName);
        waitTillElemenetVisible("LastNameEbilling");
        sendKeysTotheElement("LastNameEbilling", lastebillingName);
        waitTillElemenetVisible("EmailEbilling");
        sendKeysTotheElement("EmailEbilling", emailId);
        ExtentLogger.pass("Enter the first name, last name and Email Address", true);
        String firstNameSize = driver.findElement(By.xpath("//*[text()='First name']/parent::label/following-sibling::input")).getAttribute("value");
        String lastNameNameSize = driver.findElement(By.xpath("//*[text()='Last name']/parent::label/following-sibling::input")).getAttribute("value");
        String emailSize = driver.findElement(By.xpath("//*[text()='Email']/parent::label/following-sibling::input")).getAttribute("value");
        System.out.println(firstNameSize);
        System.out.println(lastNameNameSize);
        System.out.println(emailSize);
        Assert.assertEquals(firstNameSize.length(), 35);
        Assert.assertEquals(lastNameNameSize.length(), 35);
        Assert.assertEquals(emailSize.length(), 120);
        ExtentLogger.pass("Length of First Name, last name and Email Address is correct!", true);
        return this;
    }

    public ProductPage ActionOptionsEditButton() throws InterruptedException, IOException {

        driver.navigate().refresh();
        waitTillElemenetVisible("ActionBilling");
        clickElement(getElementByXpath("ActionBilling"));
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//*[text()='Edit']/parent::button)[1]")).click();
        ExtentLogger.pass("Click On Edit Button", true);
        jse.executeScript("window.scrollBy(0,200)");
        return this;

    }

    public ProductPage ActionOptionsDeleteButton() throws InterruptedException, IOException {
        int size = driver.findElements(By.xpath("//table[@aria-labelledby='contacts-table-caption']//tr")).size();
        Assert.assertTrue(size > 1);
        Thread.sleep(1000);
        driver.navigate().refresh();
        waitTillElemenetVisible("DeletedName");
        String deletedName=getElementText("DeletedName");
        waitTillElemenetVisible("ActionBilling");
        clickElement(getElementByXpath("ActionBilling"));
        Thread.sleep(3000);
        driver.findElement(By.xpath("(//*[text()='Delete']/parent::button)[1]")).click();
        ExtentLogger.pass("Click On Delete Button", true);
        jse.executeScript("window.scrollBy(0,200)");
        waitTillElemenetVisible("ActionBillingDeleteConfirm");
        ExtentLogger.pass("Click On Yes,Delete Button", true);
        clickElement(getElementByXpath("ActionBillingDeleteConfirm"));
        Thread.sleep(3000);
        validationOfDeletedEbillingContact(deletedName);
        return this;

    }

    public void validationOfDeletedEbillingContact(String deletedName) throws InterruptedException, IOException {

        waitTillElemenetVisible("DeletedName");
        Boolean a= true;
        int i=1;
        lastRecordNumber = lastRecordNumber - 1;
        System.out.println(lastRecordNumber);
        Thread.sleep(2000);
        boolean result = false;
        while (true) {
            try {
                int size=driver.findElements(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])")).size();
                for(int j=1;j<=size;j++) {
                    WebElement ele = driver.findElement(By.xpath("(//tbody[@class='tr-DataGrid-tableBody']//th[1])[" + j + "]"));
                    String name = getElementTextbyElement(ele);
                    System.out.println(name);
                    System.out.println(ele);

                    if (name.contains(deletedName)) {
                        result = true;
                        break;
                    }
                }
                if (a == false || result==true)
                    break;
                driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).click();

                a = driver.findElement(By.xpath("//button[@class='tr-DynamicPagination-button tr-DynamicPagination-button--next']")).isEnabled();
                i++;
                System.out.println("value of i is" +i);

            } catch (Exception e) {

            }
        }
        Assert.assertFalse(result);
        ExtentLogger.pass("Deleted contact is not present "+deletedName, true);
        driver.navigate().refresh();
    }


    public ProductPage LastContactDeleteButton() throws InterruptedException, IOException {
        waitTillElemenetVisible("ActionBilling");
        jse.executeScript("window.scrollBy(0,200)");
        int size = driver.findElements(By.xpath("//table[@aria-labelledby='contacts-table-caption']//tr")).size();
        Assert.assertEquals(size, 2);
        ExtentLogger.pass("Only 1 ebilling contact is present", true);
        Thread.sleep(1000);
        waitTillElemenetVisible("ActionBilling");
        clickElement(getElementByXpath("ActionBilling"));
        Thread.sleep(3000);
        boolean result=false;
        try {
            if (driver.findElement(By.xpath("(//*[text()='Delete']/parent::button)[1]")).isDisplayed()) ;
            result = true;
        }catch(Exception e){}
        Assert.assertFalse(result);
        ExtentLogger.pass("Delete Button is not displayed for last ebilling contact", true);

        return this;

    }
    public ProductPage closeTicket() throws InterruptedException, IOException {

        waitTillElemenetVisible("CloseTicket");
        clickElement(getElementByXpath("CloseTicket"));
        return this;
    }
    public ProductPage MarkAsResolved() throws InterruptedException, IOException {

        waitTillElemenetVisible("MarkAsResolved");
        clickElement(getElementByXpath("MarkAsResolved"));
        return this;
    }
}


