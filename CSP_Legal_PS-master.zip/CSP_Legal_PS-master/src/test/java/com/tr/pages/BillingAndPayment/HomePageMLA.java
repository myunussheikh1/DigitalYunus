package com.tr.pages.BillingAndPayment;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.IOException;
import java.util.List;

public class HomePageMLA extends BasePage_PS {

	public HomePageMLA() {
		super("locatorsDefinition/BillingAndPayment/HomePageMLA.json");
		PageFactory.initElements(getDriver(), this);
	}

	public HomePageMLA calculateDue() throws InterruptedException, IOException {

		waitTillElemenetVisible("AmountDueColumn");
		boolean flag = true;
		float dollar = 0.0F;
		float euro = 0.0F;
		float pound = 0.0F;
		float usdollar=0.0F;

		while (flag) {
			List<WebElement> list = driver.findElements(By.xpath("//table[@class='tr-DataGrid-table']//td[3]/span/span"));
			System.out.println("Size is " + list.size());
			for (int i = 1; i < list.size(); i = i + 2) {
				String text = driver.findElement(By.xpath("(//table[@class='tr-DataGrid-table']//td[3]/span/span)[" + i + "]")).getText();
				System.out.println("Text is " + text);
				text = text.trim();
				ExtentLogger.pass("Text is " + text, true);
				if (text.contains("CAD $")) {
					String parts[] = text.split("\\$");
					parts[1] = parts[1].replaceAll(",", "");
					dollar = dollar + Float.parseFloat(parts[1]);
					System.out.println("Dollar amount is " + dollar);
					ExtentLogger.pass("Dollar amount is " + dollar, true);
				} else if (text.contains("EUR €")) {
					String parts[] = text.split("\\€");
					parts[1] = parts[1].replaceAll(",", "");
					euro = euro + Float.parseFloat(parts[1]);
					System.out.println("Euro amount is " + euro);
					ExtentLogger.pass("Euro amount is " + euro, true);

				} else if (text.contains("GBP £")) {
					String parts[] = text.split("\\£");
					parts[1] = parts[1].replaceAll(",", "");
					pound = pound + Float.parseFloat(parts[1]);
					System.out.println("Pound amount is " + pound);
					ExtentLogger.pass("Pound amount is " + pound, true);
				}
				else if (text.contains("USD $")) {
					String parts[] = text.split("\\$");
					parts[1] = parts[1].replaceAll(",", "");
					usdollar = usdollar + Float.parseFloat(parts[1]);
					System.out.println("Us dollar amount is " + usdollar);
					ExtentLogger.pass("US dollar amount is " + usdollar, true);
				}
			}
				try {
					if (driver.findElement(By.xpath("//span[text()='Next']")).getCssValue("color").equalsIgnoreCase("rgba(136, 136, 136, 1)")) {
						break;
					} else {
						driver.findElement(By.xpath("//span[text()='Next']")).click();
					}
				} catch (NoSuchElementException e) {
					System.out.println("next button is not visible " + e.getMessage());
					break;
				}

		}
		System.out.println("Dollar total amount is " + dollar);
		ExtentLogger.pass("Dollar total amount is " + dollar, true);

		System.out.println("Euro total amount is " + euro);
		ExtentLogger.pass("Euro total amount is " + euro, true);

		System.out.println("Pound total amount is " + pound);
		ExtentLogger.pass("Pound total amount is " + pound, true);

		System.out.println("US dollar total amount is " + usdollar);
		ExtentLogger.pass("US dollar total amount is " + usdollar, true);

		waitTillElemenetVisible("HeaderAmount");
		List<WebElement> list1 = driver.findElements(By.xpath("//*[@class='tr-Typography tr-Typography--m tr-Typography--left']"));
		System.out.println("Header size is " + list1.size());
		for(int i=1;i<=list1.size();i++){
			String headertext=driver.findElement(By.xpath("(//*[@class='tr-Typography tr-Typography--m tr-Typography--left'])["+i+"]")).getText();
			System.out.println("Header is "+headertext);
			ExtentLogger.pass("Header is "+headertext,true);
			if(headertext.contains("Amount due (CAD)")){
				String headeramount=driver.findElement(By.xpath("(//*[@class='tr-Typography tr-Typography--m tr-Typography--left'])["+i+"]/parent::div/p[2]/b")).getText();
				String parts[] = headeramount.split("\\$");
				parts[1] = parts[1].replaceAll(",", "");
				float f=Float.parseFloat(parts[1]);
				System.out.println("Header dollar total amount is " + f);
				ExtentLogger.pass("Header dollar total amount is " + f, true);
				Assert.assertEquals(dollar,f);
				headeramount=driver.findElement(By.xpath("(//*[@class='tr-Typography tr-Typography--m tr-Typography--left'])["+i+"]/parent::div/p[3]/b")).getText();
				String parts1[] = headeramount.split("\\$");
				parts1[1] = parts1[1].replaceAll(",", "");
				 f=Float.parseFloat(parts1[1]);
				System.out.println("Header dollar total amount in red is " + f);
				ExtentLogger.pass("Header dollar total amount in red is " + f, true);
				Assert.assertEquals(dollar,f);
			}
			else if(headertext.contains("Amount due (EUR)")){
				String headeramount=driver.findElement(By.xpath("(//*[@class='tr-Typography tr-Typography--m tr-Typography--left'])["+i+"]/parent::div/p[2]/b")).getText();
				String parts[] = headeramount.split("\\€");
				parts[1] = parts[1].replaceAll(",", "");
				float f=Float.parseFloat(parts[1]);
				System.out.println("Header euro total amount is " + f);
				ExtentLogger.pass("Header euro total amount is " + f, true);
				Assert.assertEquals(euro,f);
				headeramount=driver.findElement(By.xpath("(//*[@class='tr-Typography tr-Typography--m tr-Typography--left'])["+i+"]/parent::div/p[3]/b")).getText();
				String parts1[] = headeramount.split("\\€");
				parts1[1] = parts1[1].replaceAll(",", "");
				f=Float.parseFloat(parts1[1]);
				System.out.println("Header euro total amount in red is " + f);
				ExtentLogger.pass("Header euro total amount in red is " + f, true);
				Assert.assertEquals(euro,f);
			}
			else if(headertext.contains("Amount due (GBP)")){
				String headeramount=driver.findElement(By.xpath("(//*[@class='tr-Typography tr-Typography--m tr-Typography--left'])["+i+"]/parent::div/p[2]/b")).getText();
				String parts[] = headeramount.split("\\£");
				parts[1] = parts[1].replaceAll(",", "");
				float f=Float.parseFloat(parts[1]);
				System.out.println("Header pound total amount is " + f);
				ExtentLogger.pass("Header pound total amount is " + f, true);
				Assert.assertEquals(pound,f);
				headeramount=driver.findElement(By.xpath("(//*[@class='tr-Typography tr-Typography--m tr-Typography--left'])["+i+"]/parent::div/p[3]/b")).getText();
				String parts1[] = headeramount.split("\\£");
				parts1[1] = parts1[1].replaceAll(",", "");
				f=Float.parseFloat(parts1[1]);
				System.out.println("Header pound total amount in red is " + f);
				ExtentLogger.pass("Header pound total amount in red is " + f, true);
				Assert.assertEquals(pound,f);
			}
			else if(headertext.contains("Amount due (USD)")){
				String headeramount=driver.findElement(By.xpath("(//*[@class='tr-Typography tr-Typography--m tr-Typography--left'])["+i+"]/parent::div/p[2]/b")).getText();
				String parts[] = headeramount.split("\\$");
				parts[1] = parts[1].replaceAll(",", "");
				float f=Float.parseFloat(parts[1]);
				System.out.println("Header US dollar total amount is " + f);
				ExtentLogger.pass("Header US dollar total amount is " + f, true);
				Assert.assertEquals(usdollar,f);
				headeramount=driver.findElement(By.xpath("(//*[@class='tr-Typography tr-Typography--m tr-Typography--left'])["+i+"]/parent::div/p[3]/b")).getText();
				String parts1[] = headeramount.split("\\$");
				parts1[1] = parts1[1].replaceAll(",", "");
				f=Float.parseFloat(parts1[1]);
				System.out.println("Header US dollar total amount in red is " + f);
				ExtentLogger.pass("Header US dollar total amount in red is " + f, true);
				Assert.assertEquals(usdollar,f);
			}
			Thread.sleep(1000);
			try{
				driver.findElement(By.xpath("//button[@aria-label='Next']//span[@class='Svg-inner']//*[name()='svg']")).click();
				Thread.sleep(2000);
			}catch (NoSuchElementException e){
				System.out.println(e.getMessage());
				System.out.println("No arrow is present");
				ExtentLogger.pass("No arrow is present",true);
			}
		}
		return this;

	}
}