package com.tr.pages.BillingAndPayment;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class Login_UnAuth  extends BasePage_PS
    {
    public Login_UnAuth() {
        super("locatorsDefinition/BillingAndPayment/LoginPageUnAuth.json");
        PageFactory.initElements(getDriver(), this);
    }
    public Login_UnAuth openURL(String url) throws InterruptedException, IOException {

        driver.get(url);
        ExtentLogger.pass("opening the URL "+url, true);


        return this;
    }

        public Login_UnAuth enterAccountNumber(String accNum) throws InterruptedException, IOException {
            //Thread.sleep(3000);

           waitTillElemenetVisible("AccountNumberTextBox");
            clickElement(getElementByXpath("AccountNumberTextBox"));
            sendKeysTotheElement("AccountNumberTextBox", accNum);
            ExtentLogger.pass("Entering the Account number "+accNum, true);
            return  this;
    }
        public Login_UnAuth enterPostalCode(String code) throws InterruptedException, IOException {
            //Thread.sleep(3000);

            waitTillElemenetVisible("PostalCodeTextBox");
            clickElement(getElementByXpath("PostalCodeTextBox"));
            sendKeysTotheElement("PostalCodeTextBox", code);
            ExtentLogger.pass("Entering the Postal Code "+code, true);
            return  this;
        }
        public Login_UnAuth clickOnLookUp() throws InterruptedException, IOException {
            //Thread.sleep(3000);

           // waitTillElemenetVisible("LookUp");
           // clickElement(getElementByXpath("LookUp"));
            waitTillElemenetVisible("Search");
            clickElement(getElementByXpath("Search"));

            ExtentLogger.pass("Clicking on Searchp for Account", true);
            return  this;
        }
        public Login_UnAuth clickOnAcceptCookies() throws InterruptedException {
            try {
                Thread.sleep(3000);
                waitTillElemenetVisible("AcceptCookies");
                clickElement(getElementByXpath("AcceptCookies"));
                ExtentLogger.pass("Click on Accept Cookies", true);
                return this;
            }
            catch(Exception e){
                System.out.println(e.getMessage());

                return this;

            }
        }
}
