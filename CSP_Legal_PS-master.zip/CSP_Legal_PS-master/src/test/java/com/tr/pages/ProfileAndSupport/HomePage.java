package com.tr.pages.ProfileAndSupport;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.io.IOException;
//import java.sql.Driver;

public class HomePage extends BasePage_PS {

	public HomePage() {
		super("locatorsDefinition/ProfileAndSupport/HomePage.json");
		PageFactory.initElements(getDriver(), this);
	}

	public HomePage clickOnProfile() throws InterruptedException, IOException {
		Thread.sleep(4000);
		waitTillElemenetVisible("ProfileButton");
		clickElement(getElementByXpath("ProfileButton"));
		waitTillElemenetVisible("ProfileLink");
		clickElement(getElementByXpath("ProfileLink"));

		ExtentLogger.pass("Clicking on Profile Button", true);
		return this;
	}
	public HomePage clickOnIagree() throws InterruptedException, IOException {
		Thread.sleep(4000);
		waitTillElemenetVisible("Iagreebutton");
		clickElement(getElementByXpath("Iagreebutton"));


		ExtentLogger.pass("Clicking on I agree button in T&C", true);
		return this;
	}
	
	public HomePage clickOnTermsAndAgree() throws InterruptedException, IOException {
		Thread.sleep(4000);
		waitTillElemenetVisible("TermsAndConditions");
		clickElement(getElementByXpath("TermsAndConditions"));
		ExtentLogger.pass("Clicked terms and conditiond button first time", true);
		return this;
	}

	public HomePage ValidateTermsAndConditions(String expectedValue) throws InterruptedException, IOException {
		Thread.sleep(4000);
		waitTillElemenetVisible("TermsAndConditonsHeader");
		boolean TermsAndCondition=IsElementdisplayed(getElementByXpath("TermsAndConditonsHeader"));
		Assert.assertTrue(TermsAndCondition);
		String value=driver.findElement(By.xpath("//div[@class='tr-ContentFragment-content']//p")).getText();
		Assert.assertEquals(value, expectedValue);
		ExtentLogger.pass("Validated the Terms and Conditions on the user", true);
		return this;
	}
	public HomePage ValidationFirsttimeUser_TermsAndAgree() throws InterruptedException, IOException {
		Thread.sleep(4000);
		driver.navigate().refresh();
		ExtentLogger.pass("refreshed page succesfully", true);
		if(getElementByXpath("TermsAndConditions").isDisplayed())
		{
			ExtentLogger.fail("Terms And Conditions Pop up displayed second time", true);
			Assert.assertTrue(false, "Pop up displayed second time");
		}
	
		return this;
	}

	public HomePage verifyBillingAndUserTab() throws InterruptedException, IOException {
		waitForPageLoad();
		waitTillElemenetVisible("BillingTab");
		boolean billing=IsElementdisplayed(getElementByXpath("BillingTab"));
		Assert.assertTrue(billing);
		boolean UserAccessTab=IsElementdisplayed(getElementByXpath("UserAccessTab"));
		Assert.assertTrue(UserAccessTab);
		//boolean SubscriptionTab=IsElementdisplayed(getElementByXpath("SubscriptionTab"));
		//Assert.assertTrue(SubscriptionTab);
		//boolean ReportsTab=IsElementdisplayed(getElementByXpath("ReportsTab"));
		//Assert.assertTrue(ReportsTab);
		//boolean SupportTab=IsElementdisplayed(getElementByXpath("SupportTab"));
		//Assert.assertTrue(SupportTab);
		ExtentLogger.pass("Billing, User Access tab is visible", true);



		return this;
	}

	public HomePage verifyBillingTab() throws InterruptedException, IOException {
		waitForPageLoad();
		waitTillElemenetVisible("BillingTab");
		boolean billing=IsElementdisplayed(getElementByXpath("BillingTab"));
		Assert.assertTrue(billing);
		//boolean SubscriptionTab=IsElementdisplayed(getElementByXpath("SubscriptionTab"));
		//Assert.assertTrue(SubscriptionTab);
		//boolean ReportsTab=IsElementdisplayed(getElementByXpath("ReportsTab"));
		//Assert.assertTrue(ReportsTab);
		//boolean SupportTab=IsElementdisplayed(getElementByXpath("SupportTab"));
		//Assert.assertTrue(SupportTab);
		ExtentLogger.pass("Billing tab is visible", true);



		return this;
	}

	public HomePage verifyUserTab() throws InterruptedException, IOException {
		waitForPageLoad();
		waitTillElemenetVisible("UserAccessTab");
		boolean UserAccessTab=IsElementdisplayed(getElementByXpath("UserAccessTab"));
		Assert.assertTrue(UserAccessTab);
		//boolean SubscriptionTab=IsElementdisplayed(getElementByXpath("SubscriptionTab"));
		//Assert.assertTrue(SubscriptionTab);
		//boolean ReportsTab=IsElementdisplayed(getElementByXpath("ReportsTab"));
		//Assert.assertTrue(ReportsTab);
		//boolean SupportTab=IsElementdisplayed(getElementByXpath("SupportTab"));
		//Assert.assertTrue(SupportTab);
		ExtentLogger.pass("User Access tab is visible", true);



		return this;
	}
	public HomePage languagaeDropdown() throws InterruptedException {
		waitTillElemenetVisible("languageDropdown");
		clickElement(getElementByXpath("languageDropdown"));
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//button[@class='tr-GlobalHeaderNavItem-link'])[2]")).click();
		return null;
	}

	public HomePage verifyEnglishLang() throws InterruptedException, IOException {
		waitForPageLoad();
		String eng=driver.findElement(By.xpath("//button[@class='tr-GlobalHeaderBaseItem-link']/span[2]/span")).getText().trim();
		boolean res=false;
		if(eng.contains("English"))
			res=true;
		Assert.assertTrue(res);
		eng=driver.findElement(By.xpath("//button[@class='tr-GlobalHeaderBaseItem-link']/span[2]/span/abbr")).getText().trim();
		res=false;
		if(eng.contains("(") && eng.contains("US") && eng.contains(")") )
			res=true;
		Assert.assertTrue(res);
		ExtentLogger.pass("English(US) is selected by default", true);

		driver.findElement(By.xpath("//div[@class='tr-GlobalHeaderBaseItem-linkChevron']/span/span")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//abbr[@title='United Kingdom']")).click();
		Thread.sleep(1000);
		ExtentLogger.pass("English(GB) is selected", true);

		eng=driver.findElement(By.xpath("//button[@class='tr-GlobalHeaderBaseItem-link']/span[2]/span")).getText().trim();
		 res=false;
		if(eng.contains("English"))
			res=true;
		Assert.assertTrue(res);
		eng=driver.findElement(By.xpath("//button[@class='tr-GlobalHeaderBaseItem-link']/span[2]/span/abbr")).getText().trim();
		res=false;
		if(eng.contains("(") && eng.contains("GB") && eng.contains(")") )
			res=true;
		Assert.assertTrue(res);
		ExtentLogger.pass("Verified that English(GB) is selected", true);

		driver.findElement(By.xpath("//div[@class='tr-GlobalHeaderBaseItem-linkChevron']/span/span")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//abbr[@title='Canada']")).click();
		Thread.sleep(1000);
		ExtentLogger.pass("Francais (CA) is selected", true);

		eng=driver.findElement(By.xpath("//button[@class='tr-GlobalHeaderBaseItem-link']/span[2]/span")).getText().trim();
		res=false;
		if(eng.contains("Francais"))
			res=true;
		Assert.assertTrue(res);
		eng=driver.findElement(By.xpath("//button[@class='tr-GlobalHeaderBaseItem-link']/span[2]/span/abbr")).getText().trim();
		res=false;
		if(eng.contains("(") && eng.contains("CA") && eng.contains(")") )
			res=true;
		Assert.assertTrue(res);
		ExtentLogger.pass("Verified that Francais (CA) is selected", true);
		waitTillElemenetVisible("BillingFrench");
		boolean billingfrench=IsElementdisplayed(getElementByXpath("BillingFrench"));
		Assert.assertTrue(billingfrench);
		ExtentLogger.pass("Translation in french is verified", true);
		return this;
	}


}
