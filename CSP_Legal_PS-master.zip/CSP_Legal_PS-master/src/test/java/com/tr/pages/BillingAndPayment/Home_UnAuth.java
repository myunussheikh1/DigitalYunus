package com.tr.pages.BillingAndPayment;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;

public class Home_UnAuth extends BasePage_PS
    {
    public Home_UnAuth() {
        super("locatorsDefinition/BillingAndPayment/HomePageUnAuth.json");
        PageFactory.initElements(getDriver(), this);
    }


        public Home_UnAuth HomePageVerification() throws InterruptedException, IOException {
            //Thread.sleep(3000);

           waitTillElemenetVisible("SignInButton");
           Boolean flag= IsElementdisplayed(getElementByXpath("SignInButton"));
           Assert.assertTrue(flag);
           ExtentLogger.pass("Sign in button is visible", true);
           Thread.sleep(2000);

            waitTillElemenetVisible("SetUpAutoPay");
            flag= IsElementdisplayed(getElementByXpath("SetUpAutoPay"));
            Assert.assertTrue(flag);
            ExtentLogger.pass("SetUp Autopay button is visible", true);

           // flag= IsElementdisplayed(getElementByXpath("MakeAPayment"));
           // Assert.assertTrue(flag);
          //  ExtentLogger.pass("Make a Payment button is visible", true);

            waitTillElemenetVisible("AccountOverView");
            flag= IsElementdisplayed(getElementByXpath("AccountOverView"));
            Assert.assertTrue(flag);
            ExtentLogger.pass("Account OverView text is visible", true);

            return  this;
    }

        public Home_UnAuth clickOnSetUpAutoPay() throws InterruptedException, IOException {


            waitTillElemenetVisible("SetUpAutoPay");
            clickElement(getElementByXpath("SetUpAutoPay"));
            ExtentLogger.pass("Click on Setup Autopay", true);

            return this;
        }

        public Home_UnAuth clickOnMakeAPayment() throws InterruptedException, IOException {


            waitTillElemenetVisible("MakeAPayment");
            clickElement(getElementByXpath("MakeAPayment"));
            ExtentLogger.pass("Click on Make a payment", true);

            return this;
        }

        public Home_UnAuth getPastDueVerify(HomePage homePage) throws InterruptedException, IOException {
            waitForPageLoad();
            waitTillElemenetVisible("PastDueHomeUnAuth");

            String text = driver.findElement(By.xpath("//*[contains(text(),'Past due')]")).getText();
            String pastDueAmountverify = text.split(":")[1].trim();

            System.out.println(pastDueAmountverify);
            Assert.assertEquals(pastDueAmountverify,homePage.pastDueAmount);
            ExtentLogger.pass("Past due amount is verified", true);
            return this;
        }
        String pastDueAmountverify="";
        public Home_UnAuth getPastDueWithoutVerification_USL() throws InterruptedException, IOException {
            waitForPageLoad();
            waitTillElemenetVisible("PastDueHomeUnAuth");

            String text = driver.findElement(By.xpath("//*[contains(text(),'Past due')]")).getText();
             pastDueAmountverify = text.split(":")[1].trim();

            System.out.println(pastDueAmountverify);

            ExtentLogger.pass("Past due amount is "+pastDueAmountverify, true);
            return this;
        }

        public Home_UnAuth getTotalDueVerify(HomePage homePage) throws InterruptedException, IOException {
            waitForPageLoad();
            waitTillElemenetVisible("TotalDueHomeUnAuth");

            String text = driver.findElement(By.xpath("//*[contains(text(),'Total balance due')]/strong")).getText();
            String pastDueAmountverify = text.trim();

            System.out.println(pastDueAmountverify);
            Assert.assertEquals(pastDueAmountverify,homePage.totalDueAmount);
            ExtentLogger.pass("Total due amount is verified", true);
            return this;
        }



        }
