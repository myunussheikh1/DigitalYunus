package com.tr.pages.ProfileAndSupport;

import com.tr.commons.extentListeners.ExtentLogger;
import com.tr.commons.utils.BasePage_PS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.io.IOException;

public class ProfilePage extends BasePage_PS {

	public ProfilePage() {
		super("locatorsDefinition/ProfileAndSupport/ProfilePage.json");
		PageFactory.initElements(getDriver(), this);
	}

	public ProfilePage Validatingtitle() throws InterruptedException
	 {
		ValidatingTitle("Profilepage");
	     reloadPage();
	     return this;
	 }
	 
	 public ProfilePage ClickOnProfile() throws InterruptedException {
	        waitForPageLoad();
	        //Thread.sleep(10000);
	        //driver.navigate().refresh();
	        waitUntilVisible("Profile_icon","xpath",30);
	        clickElement(getElementByXpath("Profile_icon"));
	        System.out.println("Profile icon is clicked successfully!!");
	        waitUntilVisible("Profile_dropdown","xpath",30);
	        clickElement(getElementByXpath("Profile_dropdown"));
	        System.out.println("Profile dropdown is clicked successfully!!");
	        Thread.sleep(1000);
	        return this;
	 }
	 
	 public ProfilePage ProfilePageValidate() throws InterruptedException {
 	  	
	        Thread.sleep(2000);
	        ValidatingTitle("Profilepage");
	        System.out.println("submit_ticket_page is validated successfully!!");
	        return this;
	    }
	
	public ProfilePage clickOnEditButton() throws InterruptedException, IOException {

		waitTillElemenetVisible("EditButton");
		clickElement(getElementByXpath("EditButton"));


		ExtentLogger.pass("Clicking on Edit Button", true);
		return this;
	}
	public ProfilePage validateFirstNameCannotBeEdited() throws InterruptedException, IOException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript( "window.scrollBy(0,500)");
		String firstNameCannotBeEdited = getElementText(getElementByXpath("firstNameCannotBeEdited"));
		Boolean b = firstNameCannotBeEdited.contains("First name can’t be edited");
		Assert.assertTrue(b);

		ExtentLogger.pass("First Name cannot be Edited", true);
		return this;
	}
	public ProfilePage validateLastNameCannotBeEdited() throws InterruptedException, IOException {
		String lastNameCannotBeEdited = getElementText(getElementByXpath("lastNameCannotBeEdited"));
		Boolean b = lastNameCannotBeEdited.contains("Last name can’t be edited");
		Assert.assertTrue(b);

		ExtentLogger.pass("Last Name cannot be Edited", true);
		return this;
	}
	public ProfilePage validateLastName(String Lastname) throws InterruptedException, IOException {
		clickElement(getElementByXpath("lastNameEdited"));


		WebElement LastName=driver.findElement(By.xpath("//input[@id='lastName']"));
		JavascriptExecutor js = (JavascriptExecutor)driver;
		Thread.sleep(1000);
		LastName.sendKeys(Keys.CONTROL, Keys.chord("a")); //select all text in textbox
		LastName.sendKeys(Keys.BACK_SPACE); //delete it
		LastName.sendKeys(Lastname);


		js.executeScript( "window.scrollBy(0,500)");
		Thread.sleep(2000);
		ExtentLogger.pass("Updated the LastName", true);
		
		return this;
		
	}
	public ProfilePage validateEmailCannotBeEdited() throws InterruptedException, IOException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript( "window.scrollBy(0,500)");
		Thread.sleep(2000);
		String emailCannotBeEdited = getElementText(getElementByXpath("emailCannotBeEdited"));
		Boolean b = emailCannotBeEdited.contains("Email can’t be edited");
		Assert.assertTrue(b);

		ExtentLogger.pass("Email cannot be Edited", true);
		return this;
	}

	public ProfilePage editPhoneNumber(String number) throws InterruptedException, IOException {
		clickElement(getElementByXpath("PhoneNumberTextBox"));


		WebElement phoneNumberTextBox=driver.findElement(By.xpath("//input[@id='phone']"));
		JavascriptExecutor js = (JavascriptExecutor)driver;
		Thread.sleep(1000);
		phoneNumberTextBox.sendKeys(Keys.CONTROL, Keys.chord("a")); //select all text in textbox
		phoneNumberTextBox.sendKeys(Keys.BACK_SPACE); //delete it
		phoneNumberTextBox.sendKeys(number);


		js.executeScript( "window.scrollBy(0,500)");
		Thread.sleep(2000);
		ExtentLogger.pass("Updated the phone number", true);
		return this;
	}

	public ProfilePage buttonIsEnabled() throws InterruptedException, IOException {
		try {
			Thread.sleep(2000);
			Boolean b = driver.findElement(By.xpath("//span[text()='Save']/ancestor::button")).isEnabled();
			Assert.assertTrue(b);
			ExtentLogger.pass("Save Button is Enabled", true);

		}
		catch(Exception e)
		{
			ExtentLogger.pass("Validation failed for save button", true);
			log.error(e);
		}
		return this;
	}
	public ProfilePage buttonIsDisabled() throws InterruptedException, IOException {
		try {

			Boolean b = driver.findElement(By.xpath("//span[text()='Save']/ancestor::button")).isEnabled();
			Assert.assertFalse(b);
			ExtentLogger.pass("Save Button is Disabled", true);

		}
		catch(Exception e)
		{
			ExtentLogger.pass("Validation failed for save button", true);
			log.error(e);
		}
		return this;
	}
	public ProfilePage clickOnSaveButton() throws InterruptedException, IOException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript( "window.scrollBy(0,500)");
		Thread.sleep(2000);
		clickElement(getElementByXpath("SaveButton"));

		ExtentLogger.pass("Clicked on Save Button", true);
		return this;
	}
	public ProfilePage validateTheMessage() throws InterruptedException, IOException {
		try {
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript( "window.scrollBy(0,500)");
			Thread.sleep(2000);
			Boolean b = driver.findElement(By.xpath("//*[text()='Profile updated']")).isDisplayed();
			Assert.assertTrue(b);
			ExtentLogger.pass("Update profile message appeared", true);

		}
		catch(Exception e)
		{
			ExtentLogger.pass("Validation failed for update profile message", true);
			log.error(e);
		}
		return this;
	}

	public ProfilePage validateUpdatedPhoneNumber(String number) throws IOException {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript( "window.scrollBy(0,500)");
			Thread.sleep(2000);
			String phoneNumber = driver.findElement(By.xpath("//input[@id='phone']")).getAttribute("value");
			System.out.println("Value visible in UI "+phoneNumber);
			System.out.println("Value which is passed "+number);
			Boolean b = phoneNumber.contains(number);
			Assert.assertTrue(b);
			ExtentLogger.pass("Phone Number updation is validated", true);
			log.info("The obtained phoneNumber is "+phoneNumber);
		}
		catch(Exception e)
		{
			ExtentLogger.pass("Phone Number updation is failed", true);
			log.error(e);
		}
		return this;
	}
}
