package com.tr.commons.utils;

import java.util.function.Function;


import com.tr.commons.*;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import static com.tr.commons.utils.BasePage.getLocator;

public class BasePage_PS extends BasePage {


	public BasePage_PS(String jsonPath) {
		super(jsonPath);
		PageFactory.initElements(getDriver(), this);

	}

	public static void clearText(WebElement element) {
		try {
			element.clear();
		} catch (ElementClickInterceptedException error) {
			log.info(error);
		}
	}

	public static void clickElement(WebElement element) {
		try {
			element.click();
		} catch (ElementClickInterceptedException error) {
			System.out.println(error);
		} catch (NoSuchElementException er) {
			throw new RuntimeException(er);
		}
	}

	public String getElementText(String locator) {
		WebElement element;
		String locatorId = getLocator(locator, "xpath");


		element = driver.findElement(By.xpath(locatorId));

		if (platformType.equalsIgnoreCase("android"))
			return element.getAttribute("text");
		else
			return element.getText();
	}

	public static String getElementTextbyElement(WebElement element) {

		return element.getText();
	}

	public void waitForPageLoad() {

		Wait<WebDriver> wait = new WebDriverWait(driver, 30);
		wait.until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver driver) {
				log.info("Current Window State       : "
						+ String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")));
				return String
						.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
						.equals("complete");
			}
		});
	}


	public  String getTitle() {
		String title = "Title";
		try {
			title = driver.getTitle();
		} catch (ElementClickInterceptedException error) {
			log.error(error);
		}
		return title;
	}

	public static Boolean isElementDisplayed(WebElement element) {
		Boolean Elementdisplayed = false;
		try {
			Elementdisplayed = element.isDisplayed();
		} catch (ElementClickInterceptedException error) {
			log.error(error);
		}
		return Elementdisplayed;
	}

	public void waitTillElemenetVisible(String locator) {

		Wait<WebDriver> wait = new WebDriverWait(driver, 30);
		String locatorId = getLocator(locator, "xpath");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locatorId)));
	}

	public void waitTillElemenetVisibleByxpath(String locator) {

		Wait<WebDriver> wait = new WebDriverWait(driver, 40);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(locator)));
	}

	public  void selectElement(String locator, String text) {

		WebElement element;
		String locatorId = getLocator(locator, "xpath");
		element = driver.findElement(By.xpath(locatorId));
		Select sel = new Select(element);
		sel.selectByVisibleText(text);

	}
	public  void switchFrame(String locator) {

		driver.switchTo().frame(locator);

	}

	public  void doubleClick(WebElement element) {
		try {
			Actions act = new Actions(driver);
			act.contextClick(element).perform();
		} catch (ElementClickInterceptedException error) {
			log.error(error);
		} catch (NoSuchElementException er) {
			throw new RuntimeException(er);
		}
	}

	public static Boolean IsElementdisplayed(WebElement element) {
		Boolean Elementdisplayed= false;
		try {
			Elementdisplayed = element.isDisplayed();
		} catch (ElementClickInterceptedException error) {
			System.out.println(error);
		}
		return Elementdisplayed;
	}
	
	public void ValidatingTitle (String title) {
		waitForPageLoad();
		title = getTitle();
		if (title.equals(ReadProperties.getConfig(title))) {
			System.out.println("Validation of Title on product landing page is successfull" + " " + title);
		}
		else{
			Assert.assertTrue(false);
			System.out.println("Validation of Title on product landing page is unsuccessfull" + " " + title);
		}
	}
	
	public void reloadPage()
	{
		driver.navigate().refresh();
	}


	}
